@echo off
chcp 65001 >nul
rem Product matching screen - opens http://127.0.0.1:8765 in the browser. Close this window to stop.
"%LOCALAPPDATA%\Programs\Python\Python313\python.exe" -X utf8 "%~dp0scripts\matching_app.py"
pause
