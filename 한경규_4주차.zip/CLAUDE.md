# 주문 → 발주 자동화 에이전트

쿠팡·토스에서 판매된 주문 데이터를 받아 **발주처(업체)별로 분류**하고, 업체별 발주 양식 파일을 만들어 **각 업체 발주 사이트에 업로드**하는 작업 폴더.
작업자: 행정사 사무소 겸 온라인 판매 운영자. 모든 응답·로그는 **한국어**.

## 매일 아침 자동 실행 (2026-11-25 등록)
- 예약 작업 `daily-order-prep` (Claude 앱 예약, 매일 08:00 → 실제 08:12경): `python scripts/daily_run.py` → 보고서 `reports/날짜_발주준비.html` 를 Gmail([가림])로 **[가림]** 에 발송 + 앱 알림. 앱이 꺼져 있으면 다음 실행 때 돌고, PC·어사이드(쿠팡 Wing 로그인) 필요
- daily_run 순서: 쿠팡 수집(어사이드, 상품준비중 파일 + 결제완료 건수) → 토스 수집(API) → 공급상품 점검(업체 4곳 목록, 실패 시 1회 재시도) → 분류 → 업체별 양식 작성 → **교차 검증 `scripts/verify_upload.py`** → 보고서·로그. 실측 약 2분
  - 옵션: `--skip-supply`(목록 점검 생략), `--skip-collect`(이미 받은 파일로 분류·작성·검증·보고만)
- 교차 검증: 파일 지문(생성 후 변경), 행 수·주문번호 일치, 줄별 수령인·연락처·주소·우편번호·수량·업체상품코드·주문자·메모가 분류 결과와 일치, 업체 상품명 = 매칭표·업체 목록에 있고 판매중, [필수] 빈칸·양식 예시 문구·보내는 사람 빈칸, 발주완료 장부·이전 날짜 미완료 파일과 중복, 발주 대상 누락. 결과 `upload/업체/날짜/_검증.json`
- 보고서·메일에는 **고객 이름·연락처·주소 없음** (주문번호·상품·건수·사유만). 발주 파일 첨부 금지
- 자동 실행은 **업로드·승인·완료처리·마켓 상태 변경을 하지 않는다** — 보고 후 사용자가 "업로드 진행: 업체" 라고 승인해야 진행

## 업무 흐름 (매일 반복)
1. **수집**: 쿠팡·토스 판매관리 사이트에서 신규 주문 엑셀을 다운로드 → `orders/YYYY-MM-DD/원본/{coupang|toss}/`
   - 실행: `powershell -ExecutionPolicy Bypass -File scripts\aside\run_download.ps1 coupang` / `... toss` (날짜 생략 시 오늘)
   - **쿠팡** (`coupang_download.js`): Wing 주문/배송 > 배송 관리 > **상품준비중** 탭 > 엑셀 다운 > 택배사 '선택하지 않음' + 사유 "발주처 발주서 작성용" > 다운로드 → `DeliveryList(날짜).xlsx` (상품준비중 전체, 페이지 무관)
     - 엑셀은 **상품준비중만** 받을 수 있음. 결제완료 주문은 '발주확인 처리'(→상품준비중, 고객에게 상태 노출)가 먼저 필요.
     - **발주확인 처리 (2026-11-25 사용자 요청: 결제완료 → 발주확인 → 다운로드 순서)**: `scripts/aside/coupang_confirm.js` — 결제완료 탭 → 50개씩 보기 → 전체 선택(선택 수 = 행 수 확인) → `#confirmOrder` → 확인창 승인 → 결제완료 감소 확인, 반복. 출력 `CONFIRMED=N`
       - `run_download.ps1 coupang` 이 `config/automation.yaml` 의 **`coupang_auto_confirm: true`** 일 때만(또는 `-ConfirmOrders`) 다운로드 전에 실행. **현재 false — 첫 실제 처리를 사용자와 함께 확인(확인창 문구·결과) 후 사용자가 켬**
       - 탐색 중 [발주확인 처리] 클릭(취소 목적이라도)은 자동 안전장치가 차단함 → 실제 처리는 사용자 승인으로만
   - **토스** (`toss_download.js`): shopping-seller.toss.im/orders/order-management > **결제완료·상품준비중** 탭별 > 엑셀 다운로드 > 목적 "상품 배송을 하기 위함" > 다운로드 받기 (기본 기간 1개월). 0건이면 파일이 안 나오므로 건너뜀. 판매자센터는 business.toss.im 홈의 '쇼핑' 링크로 로그인 연동.
     - '상품준비중 처리'·'발송처리'·'주문취소' 버튼은 누르지 않는다.
   - **중복 주의**: 상품준비중은 송장 입력 전까지 계속 남으므로, 어제 발주한 주문도 오늘 파일에 다시 들어온다 → 분류·발주 전 `done/`·`logs/` 주문번호 대조 필수.
   - 파일 전달 방식: 일회성 REPL 폴더(`~/.aside/u/0/sessions/...`)는 종료 시 삭제되고 프로젝트 폴더에 직접 쓸 수 없음 → JS가 base64로 출력, ps1이 받아 `orders/`에 기록(화면 출력 안 함). `.ps1`은 한글 때문에 **UTF-8 BOM**으로 저장.
2. **분류**: `python scripts/classify_orders.py YYYY-MM-DD` → **품목 매칭표 `config/상품매칭.xlsx`** 로 발주처·발주처품명·수량 결정
   - 매칭 구조: [마켓상품] 마켓+마켓옵션ID(쿠팡 옵션ID / 토스 옵션 ID) → 품목코드(P0001…) → [공급처매칭] 우선순위별 발주처·발주처품명·발주처상품코드·발주수량배수·사용(Y/N)
   - 사용=Y 중 우선순위가 가장 작은 업체로 발주. **품절이면 사용=N** → 자동으로 다음 순위 업체(검토 화면에 '대체공급' 경고)
   - **매칭 화면(주 사용)**: `상품매칭 열기.cmd` 더블클릭 또는 `python scripts/matching_app.py` → http://127.0.0.1:8765 (이 PC 전용). [가림] 파트너스 '상품 매핑 관리'와 같은 방식: 판매 옵션 줄마다 1·2순위 공급 상품 검색 선택, 배수, 사용 ON/OFF, [변경사항 저장] → 상품매칭.xlsx. [가림] 파트너스 매핑은 '참고' 열에만 표시(클릭 시 검색어로만 사용, 자동 적용 안 함)
   - **운영 원칙 (2026-11-25 사용자 결정)**: [가림] 등 업체는 상품 공급만. **[가림] 파트너스 자동발주는 쓰지 않고** 주문 수집→발주는 이 시스템이 한다.
   - 매칭 화면 버튼:
     - **⬇ 토스/쿠팡 상품 가져오기**: 마켓 판매상품 엑셀(`scripts\aside\get_market_products.js` → `market_products/{마켓}/`) → `python scripts/market_sync.py import {마켓}` → '마켓상품'에 새 옵션 추가, 판매가·정상가·재고·판매상태 갱신, 마켓에서 사라진 옵션은 '마켓에없음'
       - 토스: 내 상품 > 엑셀 다운로드 > '상품 전체 정보(상품 정보 일괄 수정용)' ('상품 옵션 정보 수정' 시트의 옵션 ID = 주문서 옵션 ID)
       - 쿠팡: Wing > 상품 조회/수정(`/vendor-inventory/list`) > **엑셀 대량 수정** 메뉴 (Step 1 다운로드 요청 / Step 2 수정 파일 업로드 / 다운로드 내역 / 업로드 내역). 엑셀은 **요청 → 생성(최대 1시간) → 다운로드 내역에서 받기**
         - `get_market_products.js`(coupang): 내역에 오늘 파일 완료 → 받기 / 생성 중 → PENDING / 없음 → 새 요청 후 PENDING
         - 요청 전 확인: 목록 필터를 '전체 N'으로(기본 필터 '아이템위너 아님'이 걸려 있음), 확인창 '전체상품(N개)' = 전체 수, 변경 항목 = '가격/재고/판매상태/배송 준비 시간'. **'상품삭제' 항목은 절대 선택 금지**
         - 받은 파일 `price_inventory_YYMMDD.xlsx`: 시트 data, 3행 헤더, 4행~ 데이터. 앞 15열 현재값(업체상품 ID, 옵션 ID=주문 옵션ID, 쿠팡 노출 상품명, 업체 등록 상품명, 등록 옵션명, 판매가격, 할인율기준가, 판매상태, 잔여수량(재고)…), 뒤 4열(P~S) '*변경/수정 요청'(판매가격·할인율기준가·판매상태·잔여수량). **openpyxl read_only 로 읽으면 3행에서 멈춤 → 일반 모드**. 생성 시간 실측 약 9분
         - 판매가 변경: 공급변동알림 '승인' → 매칭 화면 [쿠팡 판매가 수정파일 만들기] → `price_updates/coupang_판매가수정_날짜.xlsx`(승인 옵션 행만, P열 판매가격만, 할인율기준가 초과는 보류) → Wing 엑셀 대량 수정 > **Step 2 업로드는 아직 수동 — 첫 회 사용자와 함께**
         - 화면 정보(snapshot tree)는 16KB에서 잘림 → 메뉴·창은 diff 또는 페이지 DOM에서 찾기. position:fixed 창은 offsetParent 가 null 이므로 getBoundingClientRect 로 판단
     - **🔍 공급상품 점검**: 업체 4곳 상품목록 재다운로드 → `matching.py catalog` → `market_sync.py monitor`: 매칭된 공급상품마다 현재공급가·공급상태(판매중/품절·중지/목록에없음) 갱신, 변동은 '공급변동알림' 시트·'공급 변동 알림' 탭에. 품절·목록에없음 공급상품은 발주에서 자동 제외(2순위로)
     - **공급 변동 알림**: 공급가 인상/인하 시 `config/pricing.yaml` 규칙(기본 마진 금액 유지, 100원 올림)으로 **제안판매가**. 처리: 제안가 승인 / 기준만 확정 / 무시 (같은 내용은 다시 알리지 않음)
     - **승인된 판매가로 토스 수정파일 만들기** → `price_updates/toss_판매가수정_날짜.xlsx` (승인 옵션의 판매가만 변경, 같은 상품의 다른 옵션은 원래 값 유지) → 알림 '파일생성'
       - **토스 '상품 일괄 수정' 업로드는 아직 자동화 안 함 — 첫 회는 사용자와 함께 업로드·결과 확인 후 자동화.** 판매가 변경은 항상 사용자 승인 후에만.
   - [가림] 매핑 참고 갱신: `scripts\aside\read_[가림]_mapping.js` 출력 MAP_JSON → `python scripts/matching.py import-[가림] <json>` ('[가림]매핑참고' 시트, 새 쿠팡 옵션은 마켓상품에 품목코드 없이 추가)
   - ⚠ **[가림] 파트너스는 매핑·활성화(ON)된 쿠팡 상품을 월~금 07:30 수합, 09:00까지 자동 발주**(일 10시경, 토 없음). 우리 시스템과 같은 상품을 둘 다 발주하면 중복 → 상품별로 발주 주체를 하나로 정해야 함 (2026-11-25 기준 쿠팡 옵션 63개 중 활성화 ON 46개, 오늘 쿠팡 주문 12건 모두 [가림] 활성화 상품)
   - 매칭표에 없는 새 옵션(매칭없음)·업체 품명을 아직 안 고른 품목(품명미매칭)은 **발주 제외**. 업체 자동 매핑([가림] 파트너스 등)에 맡기지 않고 **사용자가 한 번 직접 매칭**한다 (매칭 화면 또는 아래 엑셀 '매칭작업' 시트):
     1. 분류 시 자동으로 '매칭작업' 시트 생성 (`python scripts/matching.py work`): 마켓 옵션별 1순위/2순위 발주처·발주처품명 드롭다운(업체 상품목록) + 비슷한 후보 5개
     2. 사용자가 엑셀에서 노란 칸 입력(또는 후보 번호) → 저장·닫기
     3. `python scripts/matching.py apply` → 마켓상품·품목·공급처매칭 반영(상품코드·공급가는 목록에서 자동) → 다시 분류
     - Claude는 후보를 보여주고 설명할 수 있지만, **매칭 선택 자체는 사용자가 한다** (사용자가 채팅으로 지정하면 그대로 입력 가능)
   - 업체 상품목록: `catalogs/{업체}/` ← `scripts\aside\get_catalogs.js` (run_repl_files.ps1, GC_VENDOR=업체) → `python scripts/matching.py catalog` 로 '발주처상품' 시트·드롭다운 갱신. [가림] 목록의 판매상태가 품절/중지면 자동으로 다음 순위 업체 발주. ([가림] 다운로드 창의 '보안 확인'은 자동 통과될 때까지 기다리기만 함, 우회 금지)
   - 매칭표 점검: `python scripts/matching.py check` (품목코드 누락, 발주처명 오타, 공급처 없음, 발주처품명 빈칸)
   - 결과: `orders/YYYY-MM-DD/분류/전체_분류결과.xlsx`, `미분류.xlsx`. 수량 0·음수·50 초과, 주소 누락도 제외.
   - 매칭표가 엑셀에서 열려 있으면 신규 옵션 저장 실패 → 닫고 다시 실행
3. **업로드 파일 생성**: `python scripts/build_upload_files.py YYYY-MM-DD` → 업체별 양식에 맞춰 `upload/{업체}/YYYY-MM-DD/`에 생성 (+ `_요약.json`)
   - 양식 예시 행 자동 삭제, `done/_발주완료목록.csv`(발주 완료 장부)에 있는 주문은 자동 제외
   - 파일을 다시 만들면 이전 승인(APPROVED.json)은 자동 삭제
4. **사용자 검토·승인**: `python scripts/upload_manager.py review YYYY-MM-DD` 출력(업체별 건수·상품·주문번호·가린 수취인 샘플·경고)을 보여주고 **업체별로 "업로드 진행" 승인을 받는다.**
   - 승인받은 업체만: `python scripts/upload_manager.py approve YYYY-MM-DD 업체 [업체..]` → APPROVED.json(파일 sha256 포함). **사용자 승인 없이 approve 실행 금지.**
5. **업로드**: `powershell -ExecutionPolicy Bypass -File scripts\aside\run_upload.ps1 -Vendor 업체 -Date YYYY-MM-DD -Mode preview|submit`
   - 실행 전 `upload_manager.py check` 자동 실행: 미승인·승인 후 파일 변경·중복 주문이면 **어사이드 실행 전에 차단**
   - preview: 사이트에 파일 올리고 확인 화면까지만 → 화면 요약(표 행 수·안내·오류·버튼) 출력, 최종 버튼 안 누름
   - submit: `upload_vendor.js`의 `UV_CONFIRMED[업체]`가 true일 때만 최종 제출. **4개 업체 모두 현재 false(최종 단계 미확정)** → 첫 실제 주문 때 사용자와 preview로 화면 확인 후 최종 단계 작성·확정
   - 결과 기록: 성공 `upload_manager.py done YYYY-MM-DD 업체 "성공 N / 실패 M"` (장부 기록 → `done/` 이동 → 로그) / 실패 `... fail YYYY-MM-DD 업체 "사유"` (파일은 upload/ 유지)
   - 발주처 정보·양식·절차: `config/vendors.yaml`, `vendors/{업체}.md`, 양식 재다운로드 `scripts\aside\get_templates.js` (run_repl_files.ps1 로 실행)
6. (후속) 발주처 송장번호 → 쿠팡·토스 송장 입력, CS는 별도 작업

## 폴더 트리
```
주문 발주 자동화 에이전트/
├─ CLAUDE.md                      ← 이 파일 (규칙·절차)
├─ config/
│  ├─ markets.yaml                ← 쿠팡/토스 다운로드 파일 컬럼 → 표준 컬럼 매핑
│  ├─ vendors.yaml                ← 업체별 양식 파일·컬럼 매핑·업로드 URL
│  ├─ 상품매칭.xlsx               ← ★ 마켓옵션 → 품목코드 → 발주처(우선순위·품절·발주처품명) 매칭표
│  └─ product_vendor_map.csv      ← 키워드 → 추천 발주처 (새 옵션 등록 시 '추천'에만 사용)
├─ templates/발주양식/{업체}/       ← 업체에서 내려받은 빈 발주 양식 (get_templates.js)
├─ catalogs/{업체}/                ← 업체 상품목록 엑셀 (get_catalogs.js) → 상품매칭.xlsx '발주처상품'
├─ market_products/{toss|coupang}/ ← 마켓 판매상품 엑셀 (get_market_products.js) → '마켓상품'
├─ price_updates/                  ← 승인된 판매가 변경 일괄수정 파일 (업로드 전)
├─ config/pricing.yaml            ← 공급가 변동 시 제안판매가 규칙
├─ vendors/{업체}.md               ← 업체별 업로드 절차·주의사항 (사이트마다 다름)
├─ orders/YYYY-MM-DD/
│  ├─ 원본/coupang, 원본/toss      ← 다운로드한 원본 (수정 금지)
│  └─ 분류/                        ← 분류 결과, 미분류 목록
├─ upload/{업체}/YYYY-MM-DD/       ← 업로드 대기 파일
├─ done/{업체}/YYYY-MM-DD/         ← 업로드 완료 파일
├─ scripts/                       ← classify_orders.py, build_upload_files.py
└─ logs/YYYY-MM-DD.md             ← 일자별 작업 로그
```

## 표준 컬럼 (마켓 파일을 이 이름으로 통일)
`market, order_no, order_date, product_code, product_name, option, qty, buyer_name, buyer_phone, receiver_name, receiver_phone, zip, address, memo, vendor, vendor_product, vendor_code`
- Python: `%LOCALAPPDATA%\Programs\Python\Python313\python.exe` (3.13.17). 한글 출력은 `-X utf8`.
- 쿠팡 수취인 전화번호는 전부 안심번호(050x). [가림]은 '010 등 표준형식'만 받는다고 안내 → 수용 여부 첫 업로드 때 확인.

## 안전 규칙 (반드시 지킬 것)
- **원본은 절대 수정하지 않는다.** 가공은 항상 `분류/`, `upload/`에서.
- **업로드(발주 제출) 전에는 항상 사용자 승인.** 업체별 건수·상품·수취인 샘플을 보여준 뒤 진행. 승인 없이 최종 제출 버튼을 누르지 않는다.
- 로그인·비밀번호·OTP·CAPTCHA는 **사용자가 직접** 처리. 계정 정보를 파일에 저장하거나 입력하지 않는다.
- 같은 주문을 **중복 발주하지 않는다.** 업로드 전 `done/`과 `logs/`에서 주문번호 중복 확인.
- 미분류·수량 이상(0, 음수, 비정상적으로 큼)·주소 누락 건은 발주에서 제외하고 사용자에게 보고.
- 개인정보(수취인 이름·전화·주소)는 이 폴더 밖으로 내보내지 않고, 로그에는 주문번호만 남긴다(이름·전화 기재 금지).
- 업로드 후 사이트의 결과 화면(성공/실패 건수)을 확인해 로그에 기록. 실패 건은 `upload/` 에 남긴다.

## 토스쇼핑 API (2026-11-25 결정: 토스만 API, 쿠팡·발주처는 어사이드)
- 코드: `scripts/toss_api.py` (check / probe / products / orders [날짜] / prices [--apply]). 문서: https://shopping-docs.toss.im/dev
- 키: `config/secrets.env` 의 TOSS_ACCESS_KEY / TOSS_SECRET_KEY (**사용자가 직접 입력**, Claude는 키 값을 입력·출력·전송하지 않음). 토큰 캐시 `config/.toss_token.json`(약 1년, 401 시 자동 재발급) — 둘 다 이 폴더 밖으로 내보내지 않음
- 키 발급: 토스쇼핑 파트너스 > 상점 이름 > 가맹점·계정 관리 > 자체 개발 > 키 발급. **등록한 IP에서만 호출 가능** (이 PC 공인 IP 2026-11-25 기준 [가림] — 바뀌면 키 화면에서 IP 갱신)
- 키가 있으면 자동으로 API 사용: 주문 수집(`run_download.ps1 toss` → `toss_api.py orders`, 결제완료·상품준비중 최근 31일 → `orders/날짜/원본/toss/toss_api_날짜.xlsx`, 열 이름은 토스 엑셀과 동일), 매칭 화면 [토스 상품 가져오기]
- 판매가 반영: 공급변동알림 '승인' 건만 → 매칭 화면 [승인된 판매가 토스에 반영 (API)] (반영 목록 미리보기 → 확인 창 → 반영). `PUT /product-items/{옵션ID}/sale-price {productId, salePrice}`. **정상가 초과는 반영하지 않고 보류**. 결과는 알림 '반영'/'반영실패'
- **2026-11-25 실연결 확인**: check 정상, probe 구조 = 코드와 일치(products/v2: products·nextToken·hasNext / v3 items: productItemId·regularSalePrice·originPrice·quantity·salesOptions / orders/v2: results·nextCursor), products 6초에 옵션 30개(API productItemId = 엑셀 옵션 ID, 새로 추가 0), orders 결제완료·상품준비중 0건, 지난 주문으로 칸 매핑 확인. v3 productManagementCode 는 비어 올 수 있음(새 옵션은 노출상품명으로 등록됨)
- **판매가 API 반영은 실제 1건 미시험** (승인된 알림이 생기면 첫 반영을 사용자와 함께 확인)

## 브라우저 자동화
- 사용자가 먼저 각 발주 사이트에 **로그인해 둔 브라우저 세션**을 사용한다. (도구: 어사이드 CLI — 정확한 명령어는 `config/vendors.yaml`의 `automation` 항목과 `vendors/{업체}.md`에 확정 후 기록. **확정 전에는 추측으로 실행하지 않는다.**)
- **어사이드 CLI 세팅 (2026-11-25 설치·제어 확인)**
  - 실행 파일: `%LOCALAPPDATA%\Aside\CLI\current\aside.exe` (사용자 PATH 등록됨, 새 터미널에서 `aside`로 실행). 버전 1.26.1121.1917, 계정 u0, 로컬 프로필 1개 연결됨.
  - 사용법 원문: `aside guide`, `aside guide repl`, `aside <명령> --help`
  - **정해진 절차(업로드 등)는 `aside repl --file scripts/aside/xxx.js`** 로 실행한다 (Playwright식 JS: `openTab`, `snapshot`, `closeTab`, `listBrowserTabs`, `attachBrowserTab`). 클릭 전후 `snapshot`으로 상태 확인.
  - PowerShell 5.1에서는 `aside repl "코드"` 로 직접 넘기면 큰따옴표·한글이 깨진다 → **항상 `--file` 사용**, 출력 한글은 `[Console]::OutputEncoding = [Text.Encoding]::UTF8` 후 실행.
  - `aside exec "..."`(어사이드 AI 에이전트 위임)은 탐색·조사용. **발주 제출처럼 되돌릴 수 없는 동작은 exec에 맡기지 않고 repl 스크립트 + 사용자 승인으로만** 진행.
  - 연결 확인: `aside repl --file scripts/aside/smoke_test.js` / 로그인 상태 확인: `scripts/aside/login_check.js` (URL·제목만 출력)
  - **로그인 세션 공유 확인됨 (2026-11-25)**: 사용자가 어사이드 브라우저에서 로그인해 두면 `aside repl` 탭도 그 로그인 상태를 그대로 쓴다 (쿠팡 Wing `https://wing.coupang.com/`, 토스 비즈니스 `https://business.toss.im/dashboard/home` 확인). 로그인 화면이 나오면 사용자에게 어사이드에서 직접 로그인해 달라고 요청한다.
- 업체별로 파일 업로드 화면 위치·버튼·성공 판정 방식이 다르므로, 새 업체는 `vendors/_template.md`를 복사해 절차를 먼저 정리하고 **첫 1회는 사용자와 함께 시험 업로드(1~2건)** 한다.

## 새 업체 추가 절차
1. 빈 양식 파일을 `templates/발주양식/{업체}/`에 넣는다.
2. `config/vendors.yaml`에 업체 항목 추가 (양식 파일명, 헤더 행, 컬럼 매핑).
3. `config/product_vendor_map.csv`에 해당 업체 상품 키워드 규칙 추가.
4. `vendors/{업체}.md` 작성 (업로드 URL, 클릭 순서, 성공 확인 방법).
5. 시험 업로드 1회 후 정상 확인.

## 작업 로그 형식 (`logs/YYYY-MM-DD.md`)
```
## 2026-11-25
- 수집: 쿠팡 N건, 토스 N건
- 분류: 업체A N건 / 업체B N건 / 미분류 N건
- 업로드: 업체A 성공 N / 실패 N (사유)
- 메모: ...
```
