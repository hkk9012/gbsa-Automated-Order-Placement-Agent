날짜 폴더(YYYY-MM-DD)가 여기에 생깁니다. 원본은 orders/날짜/원본/coupang, toss 에 넣으세요.
