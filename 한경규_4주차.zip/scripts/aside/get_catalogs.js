// 발주처 상품목록(카탈로그) 엑셀 다운로드
// 실행: powershell -ExecutionPolicy Bypass -File scripts\aside\run_repl_files.ps1 -Js scripts\aside\get_catalogs.js -Dest "catalogs\<업체>" -Prelude "globalThis.GC_VENDOR='<업체>';"
// 업체: [가림] | [가림] | [가림] | [가림]   (상태 변경 동작 없음, 다운로드만)
const gcVendor = globalThis.GC_VENDOR;
const GC = {
  [가림]: { url: "[가림]/product", btn: "전체 데이터 엑셀 다운로드" },
  [가림]: { url: "[가림]/", btn: "상품 엑셀 다운로드" },
  [가림]: { url: "[가림]/partner-app/#/product", btn: "전체제품 엑셀 다운로드" },
  [가림]: { url: "[가림]/partner-app/#/product", btn: "전체제품 엑셀 다운로드" },
}[gcVendor];
if (!GC) throw new Error("GC_VENDOR 지정 필요 ([가림]|[가림]|[가림]|[가림])");
const gcEmit = (name, buf) => { console.log("FILE_NAME=" + name); console.log("FILE_SIZE=" + buf.length); console.log("FILE_B64=" + buf.toString("base64")); };

const gp = await openTab(GC.url);
try {
  gp.on("dialog", async (d) => { console.log("알림창:", d.message()); try { await d.dismiss(); } catch {} });
  await sleep(4000);
  // 공지 창 닫기 ([가림]: dialog '공지사항' Close / adminplus: '닫기' 버튼들)
  for (let i = 0; i < 6; i++) {
    const s = await snapshot(gp, { interactive: true });
    const r = s.tree.match(/dialog "공지사항"[\s\S]*?button "Close" \[ref=(\w+)\]/)?.[1];
    if (r) { await gp.locator(r).click(); await sleep(700); continue; }
    if (/dialog "공지사항"/.test(s.tree)) { await gp.keyboard.press("Escape"); await sleep(700); continue; }
    break;
  }
  // 브라우저 안에서 만들어지는 파일(blob)도 받기
  await gp.evaluate(() => {
    window.__cap = { file: null, name: null };
    const b64 = (b) => { let s = ""; const u = new Uint8Array(b); for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return btoa(s); };
    const oco = URL.createObjectURL;
    URL.createObjectURL = function (obj) { const u = oco.apply(this, arguments); if (obj instanceof Blob) obj.arrayBuffer().then((b) => { window.__cap.file = b64(b); }); return u; };
    document.addEventListener("click", (e) => { const a = e.target.closest && e.target.closest("a[download]"); if (a) window.__cap.name = a.download; }, true);
  });
  const mark = await gp.evaluate((t) => {
    const b = [...document.querySelectorAll("button, a, span")].find((x) => x.offsetParent !== null && x.innerText.trim() === t);
    if (!b) return false;
    (b.closest("button, a") || b).setAttribute("data-agent", "gc-btn");
    return true;
  }, GC.btn);
  if (!mark) throw new Error(`'${GC.btn}' 버튼 없음`);
  let w = gp.waitForEvent("download", { timeout: 60000 }).catch(() => null);
  await gp.locator('[data-agent="gc-btn"]').click();
  if (gcVendor === "[가림]") {
    // 다운로드 창: '보안 확인 중…' 이 스스로 끝날 때까지 대기(우회하지 않음, 최대 30초) → 활성화된 다운로드 버튼 클릭
    await sleep(1500);
    let ok = null;
    for (let i = 0; i < 15 && !ok; i++) {
      const s = await snapshot(gp, { interactive: true, selector: '[role="dialog"]' });
      const btns = [...s.tree.matchAll(/button "([^"]+)" \[ref=(\w+)\](?! \[disabled\])/g)].filter((m) => !/닫기|취소/.test(m[1]));
      if (btns.length) ok = btns[0]; else await sleep(2000);
    }
    if (!ok) throw new Error("[가림] '보안 확인'이 자동으로 끝나지 않음 → 사용자가 어사이드 화면에서 직접 확인 필요");
    console.log("다운로드 버튼:", ok[1]);
    await gp.locator(ok[2]).click();
  }
  let d = await w;
  if (d) gcEmit(d.suggestedFilename(), await fs.readFile(await d.path()));
  else {
    await sleep(2000);
    const cap = await gp.evaluate(() => window.__cap);
    if (cap.file) gcEmit(cap.name || `${gcVendor}_상품목록.xlsx`, Buffer.from(cap.file, "base64"));
    else { const s = await snapshot(gp, { interactive: true }); console.log("--- 클릭 후 변경분\n" + s.diff); throw new Error("상품목록 파일을 받지 못함"); }
  }
} finally { await closeTab(gp); }
