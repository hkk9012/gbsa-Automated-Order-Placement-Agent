﻿# 발주처 업로드 실행기 (승인된 파일만)
# 사용: powershell -ExecutionPolicy Bypass -File scripts\aside\run_upload.ps1 -Vendor [가림] -Date 2026-11-25 [-Mode preview|submit]
#  1) upload_manager.py check  → 승인(APPROVED.json)·파일 해시·중복 검사. 실패 시 중단
#  2) aside repl 로 upload_vendor.js 실행 (파일은 base64로 전달, 화면에 출력 안 함)
#  3) 결과 판정은 출력된 화면 요약을 보고 Claude/사용자가 done/fail 기록
param(
  [Parameter(Mandatory)][string]$Vendor,
  [Parameter(Mandatory)][string]$Date,
  [ValidateSet('preview','submit')][string]$Mode = 'preview'
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$root = Split-Path (Split-Path $PSScriptRoot)
$py = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'
$aside = Join-Path $env:LOCALAPPDATA 'Aside\CLI\current\aside.exe'

& $py -X utf8 (Join-Path $root 'scripts\upload_manager.py') check $Date $Vendor
if ($LASTEXITCODE -ne 0) { throw '승인 검사 통과 못함 - 업로드 중단' }

$dir = Join-Path $root "upload\$Vendor\$Date"
$summary = Get-Content (Join-Path $dir '_요약.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$file = Join-Path $dir $summary.file
$b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($file))
$prelude = "globalThis.UV_VENDOR=" + (ConvertTo-Json $Vendor) + ";globalThis.UV_MODE='$Mode';globalThis.UV_EXPECT=$($summary.rows);" +
           "globalThis.UV_FILE_NAME=" + (ConvertTo-Json $summary.file) + ";globalThis.UV_FILE_B64='$b64';`n"
$tmp = Join-Path ([IO.Path]::GetTempPath()) ("aside_up_" + [guid]::NewGuid().ToString('N') + ".js")
try {
  [IO.File]::WriteAllText($tmp, $prelude + [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'upload_vendor.js'), [Text.Encoding]::UTF8), [Text.UTF8Encoding]::new($false))
  & $aside repl --file $tmp
  $code = $LASTEXITCODE
} finally { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
if ($code -ne 0) { Write-Output "[$Vendor] 업로드 스크립트 중단 (exit $code) - 위 메시지 확인"; exit $code }
