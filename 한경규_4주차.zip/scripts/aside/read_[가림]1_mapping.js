// [가림] 파트너스 '상품 매핑 관리' 표 읽기 (열려 있는 탭에 붙어 읽기만, 클릭·저장 없음)
// 출력: MAP_JSON=[{no, name, optionId, option, active, manual, mapped, price}] (상품 정보만, 개인정보 없음)
const rmTabs = await listBrowserTabs();
const rmT = rmTabs.find((t) => t.url.includes("[가림]/partners/manage-product-mapping"));
let rmPage;
if (rmT) { await attachBrowserTab(rmT.targetId); rmPage = page; }
else { rmPage = await openTab("[가림]/partners/manage-product-mapping"); await sleep(4000); }
const rm = await rmPage.evaluate(() => {
  const heads = [...document.querySelectorAll("thead th")].map((th) => th.innerText.trim().replace(/\s+/g, " "));
  const rows = [...document.querySelectorAll("tbody tr")].map((tr) => [...tr.querySelectorAll("td")].map((td) => {
    const btns = [...td.querySelectorAll("button")].map((b) => b.innerText.trim());
    return { t: td.innerText.trim().replace(/\s+/g, " "), b: btns };
  }));
  const pager = [...document.querySelectorAll("button, a")].filter((e) => e.offsetParent !== null && /^\d+$|다음|이전|next|prev/i.test(e.innerText.trim())).map((e) => e.innerText.trim()).slice(0, 20);
  return { heads, rows, pager, total: document.body.innerText.match(/총\s*[\d,]+\s*(개|건)/)?.[0] || "" };
});
console.log("헤더:", JSON.stringify(rm.heads));
console.log("행 수:", rm.rows.length, "| 총계 표기:", rm.total, "| 페이지 버튼:", JSON.stringify(rm.pager));
console.log("샘플 행:", JSON.stringify(rm.rows.slice(0, 2)));
console.log("MAP_JSON=" + JSON.stringify(rm.rows));
