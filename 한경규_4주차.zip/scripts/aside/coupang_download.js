// 쿠팡 Wing: '상품준비중' 주문 엑셀 다운로드
// 실행: powershell -ExecutionPolicy Bypass -File scripts\aside\run_download.ps1 coupang
// 주의: '발주확인 처리' 버튼은 누르지 않는다 (결제완료 → 상품준비중 상태 변경은 사용자 승인 후 별도 진행)
// 출력: 파일명·크기 + base64(run_download.ps1이 받아 orders/에 저장, 화면에는 출력 안 함). 주문 내용은 출력하지 않는다.
const cpUrl = "https://wing.coupang.com/tenants/sfl-portal/delivery/management";
const cpPage = await openTab(cpUrl);
try {
  await sleep(3000);
  if (/xauth|login/i.test(cpPage.url())) throw new Error("쿠팡 Wing 로그인 필요: 어사이드에서 로그인 후 다시 실행");
  // 상태 탭별 건수 (표 행 수만 셈, 내용은 읽지 않음). '총 N건' 표기가 있으면 그 값
  const cpCount = async (st) => {
    await cpPage.getByText(st, { exact: true }).first().click();
    await sleep(2500);
    return cpPage.evaluate(() => {
      const tot = (document.body.innerText.match(/총\s*([\d,]+)\s*건/) || [])[1];
      const rows = [...document.querySelectorAll("tbody tr")].filter((r) => r.offsetParent !== null && !/없습니다|조회된/.test(r.innerText)).length;
      return tot ? Number(tot.replace(/,/g, "")) : rows;
    });
  };
  const cpPaid = await cpCount("결제완료");
  console.log(`STATUS 결제완료: ${cpPaid}건`);   // 발주확인 처리 전이라 엑셀로 못 받음 → 보고서에 안내
  const cpReady = await cpCount("상품준비중");
  console.log(`STATUS 상품준비중: ${cpReady}건`);
  if (cpReady === 0) throw new Error("__NO_ORDERS__");
  await cpPage.getByText("엑셀 다운", { exact: true }).first().click();
  await sleep(1500);
  // 기본 택배사 선택 창: '선택하지 않음' 유지 후 [다운로드]
  const cpMarked = await cpPage.evaluate(() => {
    const vis = (e) => e && e.offsetParent !== null;
    const guide = [...document.querySelectorAll("span, p, div")].find((e) => vis(e) && e.children.length === 0 && (e.innerText || "").includes("기본으로 설정할 배송 택배사"));
    if (!guide) return "택배사 선택 창 없음";
    let box = guide;
    while (box && !([...box.querySelectorAll("button")].some((b) => vis(b) && b.innerText.trim() === "다운로드"))) box = box.parentElement;
    if (!box) return "창 안 다운로드 버튼 없음";
    [...box.querySelectorAll("button")].find((b) => vis(b) && b.innerText.trim() === "다운로드").setAttribute("data-agent", "cp-download");
    return "ok";
  });
  if (cpMarked !== "ok") throw new Error("쿠팡 화면 구조 변경 의심: " + cpMarked);
  // 개인정보 다운로드 사유(5자 이상 필수). 택배사 선택은 '선택하지 않음' 그대로 둔다.
  await cpPage.locator('textarea[placeholder="상세사유를 기재해주세요"]').fill("발주처 발주서 작성용");
  await sleep(500);
  const cpDlWait = cpPage.waitForEvent("download", { timeout: 60000 });
  await cpPage.locator('[data-agent="cp-download"]').click();
  const cpDl = await cpDlWait;
  // 일회성 REPL 세션 폴더는 종료 시 삭제되므로, 파일을 base64로 출력해 run_download.ps1이 orders/에 직접 기록
  const cpPath = await cpDl.path();
  const cpBuf = await fs.readFile(cpPath);
  console.log("FILE_NAME=coupang_" + cpDl.suggestedFilename());
  console.log("FILE_SIZE=" + cpBuf.length);
  console.log("FILE_B64=" + cpBuf.toString("base64"));
} catch (e) {
  if (e.message !== "__NO_ORDERS__") throw e;   // 상품준비중 0건: 파일 없이 정상 종료
} finally {
  await closeTab(cpPage);
}
