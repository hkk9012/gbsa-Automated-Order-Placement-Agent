// 열린 어사이드 탭의 도메인·경로·제목만 출력 (쿼리스트링 제외)
const ltTabs = await listBrowserTabs();
console.log("탭 수:", ltTabs.length);
for (const t of ltTabs) {
  let u = t.url;
  try { const x = new URL(t.url); u = x.origin + x.pathname; } catch {}
  console.log(u, "|", t.title);
}
