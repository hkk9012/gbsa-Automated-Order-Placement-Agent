// 마켓 판매상품 목록 엑셀 다운로드 (상태 변경 없음, 다운로드만)
// 실행: run_repl_files.ps1 -Js scripts\aside\get_market_products.js -Dest market_products\<toss|coupang> -Prelude "globalThis.MP_MARKET='toss';"
const mpMarket = globalThis.MP_MARKET;
const mpEmit = (name, buf) => { console.log("FILE_NAME=" + name); console.log("FILE_SIZE=" + buf.length); console.log("FILE_B64=" + buf.toString("base64")); };
const mpGrab = async (p, clickFn, timeout = 90000) => {
  const w = p.waitForEvent("download", { timeout }).catch(() => null);
  await clickFn();
  const d = await w;
  if (!d) throw new Error("파일을 받지 못함");
  mpEmit(d.suggestedFilename(), await fs.readFile(await d.path()));
};
if (mpMarket === "toss") {
  // 토스쇼핑 파트너스 > 내 상품 > 엑셀 다운로드 > '상품 전체 정보 (상품 정보 일괄 수정용)'
  const p = await openTab("https://shopping-seller.toss.im/products");
  try {
    await sleep(4000);
    if (!/shopping-seller\.toss\.im\/products/.test(p.url())) throw new Error("토스 판매자센터 로그인 필요");
    await p.getByText("엑셀 다운로드", { exact: true }).first().click();
    await sleep(1500);
    const s = await snapshot(p, { interactive: true });
    const ref = s.tree.match(/menuitem "상품 전체 정보[^"]*" \[ref=(\w+)\]/)?.[1];
    if (!ref) throw new Error("'상품 전체 정보' 메뉴 없음");
    await mpGrab(p, () => p.locator(ref).click());
  } finally { await closeTab(p); }
} else if (mpMarket === "coupang") {
  // 쿠팡 Wing > 상품 조회/수정 > 엑셀 대량 수정. 엑셀은 '요청 → 생성(최대 1시간) → 다운로드 내역에서 받기' 방식
  //  1) 다운로드 내역에 오늘 요청한 '가격/재고/판매상태' 파일이 완료돼 있으면 받는다
  //  2) 진행 중이면 PENDING, 없으면 새로 요청(전체 상품, 변경항목=가격/재고/판매상태) 후 PENDING
  // 안전: '상품삭제' 항목은 절대 선택하지 않음. 요청 대상 수 = 전체 상품 수일 때만 요청
  const shownJs = "(e)=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0}";
  const today = new Date(); const ymd = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  const p = await openTab("https://wing.coupang.com/vendor-inventory/list");
  try {
    let s, allRef;
    for (let i = 0; i < 15; i++) {
      s = await snapshot(p, { interactive: true });
      if (/xauth|login/i.test(p.url())) throw new Error("쿠팡 Wing 로그인 필요");
      allRef = s.tree.match(/generic "전체 (\d+)" \[ref=(\w+)\]/);
      if (allRef && +allRef[1] > 0) break;
      await sleep(1500);
    }
    if (!allRef) throw new Error("상품 목록을 읽지 못함");
    const openMenu = async (item) => {
      const t = await snapshot(p, { interactive: true });
      await p.locator(t.tree.match(/button[^\n]*\[ref=(\w+)\][^\n]*엑셀 대량 수정/)[1]).click();
      await sleep(1500);
      const t2 = await snapshot(p, { interactive: true });
      const re = new RegExp(item.replace(/[()]/g, "\\$&") + '[^\\n]*?\\[ref=(\\w+)\\]');
      await p.locator((t2.diff + t2.tree).match(re)[1]).click();
      await sleep(3000);
    };
    // 1) 다운로드 내역 확인
    await openMenu('"다운로드 내역"');
    const hist = await p.evaluate(({ shownSrc, ymd }) => {
      const shown = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const rows = [...document.querySelectorAll("tr")].filter(shown).map((tr) => ({ tr, t: [...tr.querySelectorAll("td")].map((td) => td.textContent.trim().replace(/\s+/g, " ")) }))
        .filter((r) => r.t.some((x) => /price_inventory/.test(x)) && r.t.some((x) => x.startsWith(ymd)));
      if (!rows.length) return { state: "none" };
      const r = rows[0];
      const btn = [...r.tr.querySelectorAll("button, a")].find((b) => shown(b) && /다운로드/.test(b.textContent));
      if (btn) { btn.setAttribute("data-agent", "cp-hist-dl"); return { state: "ready", row: r.t.join(" | ") }; }
      return { state: "pending", row: r.t.join(" | ") };
    }, { shownSrc: shownJs, ymd });
    console.log("다운로드 내역:", hist.state, hist.row || "");
    if (hist.state === "ready") {
      await mpGrab(p, () => p.locator('[data-agent="cp-hist-dl"]').click());
    } else if (hist.state === "pending") {
      console.log("PENDING=쿠팡 엑셀 생성 중 (잠시 후 다시 가져오기)");
    } else {
      // 2) 새 요청: 닫고 목록 '전체' → Step 1
      await p.keyboard.press("Escape"); await sleep(800);
      await p.goto("https://wing.coupang.com/vendor-inventory/list"); await sleep(3000);
      for (let i = 0; i < 15; i++) { s = await snapshot(p, { interactive: true }); allRef = s.tree.match(/generic "전체 (\d+)" \[ref=(\w+)\]/); if (allRef && +allRef[1] > 0) break; await sleep(1500); }
      await p.locator(allRef[2]).click(); await sleep(3000);
      await openMenu("Step 1");
      const conf = await p.evaluate((shownSrc) => {
        const shown = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
        const t = [...document.querySelectorAll("body *")].filter((e) => shown(e) && /전체상품\s*\(\s*\d+\s*개\s*\)/.test(e.textContent || "")).sort((a, b) => a.textContent.length - b.textContent.length)[0];
        if (!t) return "";
        let box = t; while (box && ![...box.querySelectorAll("button")].some((b) => b.textContent.trim() === "확인")) box = box.parentElement;
        const b = box && [...box.querySelectorAll("button")].find((b) => b.textContent.trim() === "확인" && shown(b));
        if (b) b.setAttribute("data-agent", "cp-xl-ok");
        return t.textContent.replace(/\s+/g, " ").trim();
      }, shownJs);
      const cnt = +(conf.match(/전체상품\s*\(\s*(\d+)\s*개/) || [])[1];
      if (cnt !== +allRef[1]) throw new Error(`요청 대상 수(${cnt})가 전체(${allRef[1]})와 달라 중단`);
      await p.locator('[data-agent="cp-xl-ok"]').click(); await sleep(2500);
      const form = await p.evaluate((shownSrc) => {
        const shown = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
        const radios = [...document.querySelectorAll('input[type="radio"]')].map((r) => ({ r, label: (r.closest("label") || r.parentElement).textContent.trim().replace(/\s+/g, " ") }));
        const want = radios.find((x) => /가격\/재고\/판매상태/.test(x.label));
        const del = radios.find((x) => /상품삭제/.test(x.label));
        if (!want) return "가격/재고 항목 없음";
        if (!want.r.checked) (want.r.closest("label") || want.r).click();
        if (del && del.r.checked) return "상품삭제가 선택됨 - 중단";
        if (!want.r.checked) return "가격/재고 항목 선택 실패";
        const box = want.r.closest("form") || want.r.closest("[class*=modal], [role=dialog]") || document.body;
        const b = [...box.querySelectorAll("button")].find((b) => b.textContent.trim() === "요청" && shown(b));
        if (!b) return "요청 버튼 없음";
        b.setAttribute("data-agent", "cp-req");
        return "ok";
      }, shownJs);
      if (form !== "ok") throw new Error("쿠팡 요청 창 확인 실패: " + form);
      await p.locator('[data-agent="cp-req"]').click(); await sleep(2500);
      console.log(`요청함: 전체 ${cnt}개 상품, 가격/재고/판매상태`);
      console.log("PENDING=쿠팡 엑셀 생성 요청함 (보통 수 분, 최대 1시간 → 잠시 후 다시 가져오기)");
    }
  } finally { await closeTab(p); }
} else {
  throw new Error("MP_MARKET 지정 필요 (toss|coupang)");
}
