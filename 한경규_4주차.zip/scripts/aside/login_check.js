// 판매 사이트 로그인 세션 공유 여부 확인 (URL·제목만 출력, 페이지 내용은 읽지 않음)
// 실행: aside repl --file scripts/aside/login_check.js
const loginTargets = [
  ["쿠팡 Wing", "https://wing.coupang.com/"],
  ["토스 비즈니스", "https://business.toss.im/dashboard/home"],
];
for (const [loginName, loginUrl] of loginTargets) {
  const loginPage = await openTab(loginUrl);
  await sleep(2500);
  const loginNow = loginPage.url();
  const looksLoggedOut = /login|signin|auth|xauth/i.test(loginNow);
  console.log(`${loginName}: ${looksLoggedOut ? "로그인 필요(로그인 화면으로 이동)" : "로그인 상태로 보임"} | ${loginNow} | ${await loginPage.title()}`);
  await closeTab(loginPage);
}
