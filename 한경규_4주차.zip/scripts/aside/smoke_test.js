// 어사이드 브라우저 연결 확인용 시험 스크립트 (개인정보·로그인 사이트 접근 없음)
// 실행: aside repl --file scripts/aside/smoke_test.js
const smokeTabs = await listBrowserTabs();
console.log("열린 탭 수:", smokeTabs.length);
const smokePage = await openTab("https://example.com");
console.log("제목:", await smokePage.title(), "| URL:", smokePage.url());
const smokeSnap = await snapshot(smokePage, { interactive: true });
console.log(smokeSnap.tree);
await closeTab(smokePage);
console.log("시험 탭 닫기 완료 - 어사이드 브라우저 제어 정상");
