// 토스쇼핑 파트너스: '결제완료' + '상품준비중' 주문 엑셀 다운로드 (상태별 파일 1개씩, 0건이면 건너뜀)
// 실행: powershell -ExecutionPolicy Bypass -File scripts\aside\run_download.ps1 toss
// 주의: '상품준비중 처리'·'발송처리'·'주문취소' 버튼은 누르지 않는다 (상태 변경 금지)
// 출력: 상태별 건수, 파일명·크기 + base64(run_download.ps1이 받아 orders/에 저장, 화면에는 출력 안 함)
const TS_STATUSES = globalThis.TS_STATUSES || ["결제완료", "상품준비중"]; // 시험 시에만 덮어씀
const TS_INCLUDE_EMPTY = globalThis.TS_INCLUDE_EMPTY === true; // 열 구성 확인용(0건도 다운로드)
const tsPage = await openTab("https://shopping-seller.toss.im/orders/order-management");
try {
  await sleep(4000);
  if (!/shopping-seller\.toss\.im\/orders/.test(tsPage.url())) throw new Error("토스 판매자센터 로그인 필요: 어사이드에서 토스 비즈니스 > 쇼핑으로 로그인 후 다시 실행 (" + tsPage.url().split("?")[0] + ")");
  for (const st of TS_STATUSES) {
    const tsCount = await tsPage.evaluate((s) => {
      const b = [...document.querySelectorAll("button")].find((x) => x.offsetParent !== null && new RegExp("^" + s + "\\s*\\d+건$").test(x.innerText.trim().replace(/\s+/g, " ")));
      if (!b) return -1;
      b.setAttribute("data-agent", "ts-status");
      return Number(b.innerText.replace(/[^\d]/g, ""));
    }, st);
    console.log(`STATUS ${st}: ${tsCount < 0 ? "탭 없음" : tsCount + "건"}`);
    if (tsCount < 0) throw new Error("토스 화면 구조 변경 의심: '" + st + "' 탭 없음");
    if (tsCount === 0 && !TS_INCLUDE_EMPTY) continue;
    await tsPage.locator('[data-agent="ts-status"]').click();
    await sleep(2500);
    await tsPage.evaluate(() => document.querySelector('[data-agent="ts-status"]')?.removeAttribute("data-agent"));
    await tsPage.getByText("엑셀 다운로드", { exact: true }).first().click();
    await sleep(2000);
    // 다운로드 창: 목적 기본값 '상품 배송을 하기 위함' 확인 후 [다운로드 받기]
    const tsPurpose = await tsPage.evaluate(() => {
      const d = [...document.querySelectorAll("[role=dialog], [aria-modal=true]")].filter((e) => e.offsetParent !== null).find((e) => /다운로드 받기/.test(e.innerText));
      if (!d) return "창 없음";
      const cb = d.querySelector("[role=combobox]");
      d.querySelector("button[type=submit]")?.setAttribute("data-agent", "ts-submit");
      return cb ? cb.innerText.trim() : "목적 없음";
    });
    if (tsPurpose !== "상품 배송을 하기 위함") throw new Error("다운로드 목적 확인 필요: " + tsPurpose);
    const tsDlWait = tsPage.waitForEvent("download", { timeout: 60000 });
    await tsPage.locator('[data-agent="ts-submit"]').click();
    const tsDl = await tsDlWait;
    const tsBuf = await fs.readFile(await tsDl.path());
    console.log("FILE_NAME=toss_" + st + "_" + tsDl.suggestedFilename());
    console.log("FILE_SIZE=" + tsBuf.length);
    console.log("FILE_B64=" + tsBuf.toString("base64"));
    await sleep(1500);
  }
} finally {
  await closeTab(tsPage);
}
