// 발주처 빈 발주 양식 다운로드
// 실행: powershell -ExecutionPolicy Bypass -File scripts\aside\run_repl_files.ps1 -Js scripts\aside\get_templates.js -Dest "templates\발주양식\<업체>" -Prelude "globalThis.GT_VENDOR='<업체>';"
// 업체: [가림] | [가림] | [가림] | [가림]
const gtVendor = globalThis.GT_VENDOR;
const gtEmit = (name, buf) => { console.log("FILE_NAME=" + name); console.log("FILE_SIZE=" + buf.length); console.log("FILE_B64=" + buf.toString("base64")); };

// 브라우저 안에서 만들어지는 파일(blob)도 받을 수 있게 가로채기 설치
const gtHook = (p) => p.evaluate(() => {
  window.__cap = { file: null, name: null };
  const b64 = (b) => { let s = ""; const u = new Uint8Array(b); for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return btoa(s); };
  const oco = URL.createObjectURL;
  URL.createObjectURL = function (obj) { const u = oco.apply(this, arguments); if (obj instanceof Blob) obj.arrayBuffer().then((b) => { window.__cap.file = b64(b); }); return u; };
  document.addEventListener("click", (e) => { const a = e.target.closest && e.target.closest("a[download]"); if (a) window.__cap.name = a.download; }, true);
});
// 클릭 후 download 이벤트 또는 blob 중 먼저 오는 것으로 파일 확보
const gtGrab = async (p, clickFn, fallbackName) => {
  const w = p.waitForEvent("download", { timeout: 15000 }).catch(() => null);
  await clickFn();
  const d = await w;
  if (d) return gtEmit(d.suggestedFilename(), await fs.readFile(await d.path()));
  const cap = await p.evaluate(() => window.__cap);
  if (cap && cap.file) return gtEmit(cap.name || fallbackName, Buffer.from(cap.file, "base64"));
  throw new Error("양식 파일을 받지 못함");
};
// 공지/팝업 닫기 (role=dialog 공지 또는 '닫기' 버튼 반복)
const gtClosePopups = async (p) => {
  for (let i = 0; i < 6; i++) {
    const s = await snapshot(p, { interactive: true });
    const r = s.tree.match(/dialog "공지사항"[\s\S]*?button "Close" \[ref=(\w+)\]/)?.[1];
    if (r) { await p.locator(r).click(); await sleep(800); continue; }
    if (/dialog "공지사항"/.test(s.tree)) { await p.keyboard.press("Escape"); await sleep(800); continue; }
    break;
  }
};

const gtPage = await openTab(
  gtVendor === "[가림]" ? "[가림]/order/new-order" :
  gtVendor === "[가림]" ? "[가림]/orders/new" :
  gtVendor === "[가림]" ? "[가림]/partner-app/#/excel" :
  gtVendor === "[가림]" ? "[가림]/partner-app/#/excel" : "about:blank");
try {
  if (!["[가림]", "[가림]", "[가림]", "[가림]"].includes(gtVendor)) throw new Error("GT_VENDOR 지정 필요");
  gtPage.on("dialog", async (d) => { console.log("알림창:", d.message()); try { await d.dismiss(); } catch {} });
  await sleep(3500);
  await gtHook(gtPage);
  if (gtVendor === "[가림]") {
    // 템플릿 다운로드 버튼 → 펼침 메뉴 '[가림] 발주서'
    await gtClosePopups(gtPage);
    const s1 = await snapshot(gtPage, { interactive: true });
    const tpl = s1.tree.match(/button "템플릿 다운로드" \[ref=(\w+)\]/)?.[1];
    if (!tpl) throw new Error("템플릿 다운로드 버튼 없음");
    await gtPage.locator(tpl).click();
    await sleep(1000);
    const s2 = await snapshot(gtPage, { interactive: true });
    const item = s2.tree.match(/menuitem "[가림] 발주서" \[ref=(\w+)\]/)?.[1];
    if (!item) throw new Error("'[가림] 발주서' 메뉴 없음");
    await gtGrab(gtPage, () => gtPage.locator(item).click(), "[가림]_발주서_템플릿.xlsx");
  } else if (gtVendor === "[가림]") {
    await gtGrab(gtPage, () => gtPage.getByText("📥 기본 엑셀 양식 다운로드", { exact: true }).first().click(), "[가림] 기본 엑셀 양식.xlsx");
  } else {
    // adminplus: 업로드 방식 '공통 엑셀파일' 상태에서 [양식다운로드]
    const s1 = await snapshot(gtPage, { interactive: true });
    const common = s1.tree.match(/radio "공통 엑셀파일[^"]*" \[ref=(\w+)\]/)?.[1];
    if (common && !/radio "공통 엑셀파일[^"]*" \[ref=\w+\] \[checked\]/.test(s1.tree)) { await gtPage.locator(common).click(); await sleep(600); }
    const btn = s1.tree.match(/button "양식다운로드" \[ref=(\w+)\]/)?.[1];
    if (!btn) throw new Error("양식다운로드 버튼 없음");
    await gtGrab(gtPage, () => gtPage.locator(btn).click(), gtVendor + "_대량발주양식.xlsx");
  }
} finally { await closeTab(gtPage); }
