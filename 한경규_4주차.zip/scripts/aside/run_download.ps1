﻿# 마켓 주문 엑셀 다운로드 실행기
# 사용: powershell -ExecutionPolicy Bypass -File scripts\aside\run_download.ps1 coupang [YYYY-MM-DD]
#       (coupang | toss)
# 1) aside repl 로 {market}_download.js 실행 → 어사이드 세션 폴더에 파일 저장
# 2) 그 파일을 orders\날짜\원본\{market}\ 로 '이동' (개인정보가 프로젝트 폴더 밖에 남지 않도록)
#  쿠팡: config\automation.yaml 의 coupang_auto_confirm: true 이거나 -ConfirmOrders 를 붙이면
#        다운로드 전에 결제완료 주문을 '발주확인 처리'(coupang_confirm.js)
param(
  [Parameter(Mandatory)][ValidateSet('coupang','toss')][string]$Market,
  [string]$Date = (Get-Date -Format 'yyyy-MM-dd'),
  [switch]$ConfirmOrders
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$root = Split-Path (Split-Path $PSScriptRoot)
$aside = Join-Path $env:LOCALAPPDATA 'Aside\CLI\current\aside.exe'
$js = Join-Path $PSScriptRoot "$($Market)_download.js"
$dest = Join-Path $root "orders\$Date\원본\$Market"
New-Item -ItemType Directory -Force $dest | Out-Null

# 토스: API 키(config\secrets.env)가 있으면 API로 수집 (어사이드 미사용)
if ($Market -eq 'toss') {
  $sec = Join-Path $root 'config\secrets.env'
  if ((Test-Path $sec) -and ((Get-Content $sec -Encoding UTF8) -match '^TOSS_ACCESS_KEY=\S+') -and ((Get-Content $sec -Encoding UTF8) -match '^TOSS_SECRET_KEY=\S+')) {
    $py = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'
    & $py -X utf8 (Join-Path $root 'scripts\toss_api.py') orders $Date
    exit $LASTEXITCODE
  }
}

# 쿠팡: 결제완료 → 발주확인 처리 (설정이 켜져 있거나 -ConfirmOrders 일 때만)
if ($Market -eq 'coupang') {
  $auto = Join-Path $root 'config\automation.yaml'
  $on = $ConfirmOrders -or ((Test-Path $auto) -and ((Get-Content $auto -Encoding UTF8) -match '^\s*coupang_auto_confirm:\s*true'))
  if ($on) {
    $cout = @(& $aside repl --file (Join-Path $PSScriptRoot 'coupang_confirm.js'))
    $cout | ForEach-Object { Write-Output $_ }
    if ($LASTEXITCODE -ne 0) { Write-Output "[coupang] 발주확인 처리 실패 - 다운로드는 계속 (상품준비중 건만 수집)" }
  } else {
    Write-Output "[coupang] 발주확인 자동 처리 꺼짐 (config\automation.yaml) - 결제완료 건은 수집되지 않음"
  }
}

$out = @(& $aside repl --file $js)
$code = $LASTEXITCODE
# 파일 내용(base64) 줄은 화면에 출력하지 않는다 (개인정보)
$out | Where-Object { $_ -notlike 'FILE_B64=*' } | ForEach-Object { Write-Output $_ }
if ($code -ne 0) { throw "어사이드 실행 실패 (exit $code)" }

$names = @($out | Where-Object { $_ -like 'FILE_NAME=*' } | ForEach-Object { $_.Substring(10).Trim() })
$sizes = @($out | Where-Object { $_ -like 'FILE_SIZE=*' } | ForEach-Object { [int]$_.Substring(10).Trim() })
$b64s  = @($out | Where-Object { $_ -like 'FILE_B64=*' }  | ForEach-Object { $_.Substring(9).Trim() })
if ($b64s.Count -eq 0) {
  $st = @($out | Where-Object { $_ -like 'STATUS *' })
  if ($st.Count -gt 0 -and -not ($st | Where-Object { $_ -notmatch ': 0건$' })) { Write-Output "[$Market] 신규 주문 없음 (0건) - 다운로드 생략"; exit 0 }
  if ($Market -eq 'coupang' -and ($st -match '상품준비중: 0건')) { Write-Output "[coupang] 상품준비중 0건 - 다운로드 생략"; exit 0 }
  throw '다운로드된 파일이 없습니다.'
}
for ($i = 0; $i -lt $b64s.Count; $i++) {
  $bytes = [Convert]::FromBase64String($b64s[$i])
  if ($bytes.Length -ne $sizes[$i]) { throw "파일 크기 불일치: $($names[$i])" }
  $name = $names[$i] -replace '[\\/:*?"<>|]', '_'
  $target = Join-Path $dest $name
  if (Test-Path $target) { $target = Join-Path $dest ("{0}_{1}{2}" -f [IO.Path]::GetFileNameWithoutExtension($name), (Get-Date -Format 'HHmmss'), [IO.Path]::GetExtension($name)) }
  [IO.File]::WriteAllBytes($target, $bytes)
  Write-Output "저장: $target ($($bytes.Length) bytes)"
}
