// 탐색용: 쿠팡 엑셀 대량 수정 > 다운로드 내역 창 내용 (보기만)
const ep = await openTab("https://wing.coupang.com/vendor-inventory/list");
try {
  let s;
  for (let i = 0; i < 15; i++) { s = await snapshot(ep, { interactive: true }); if (/엑셀 대량 수정/.test(s.tree)) break; await sleep(1500); }
  await ep.locator(s.tree.match(/button[^\n]*\[ref=(\w+)\][^\n]*엑셀 대량 수정/)[1]).click();
  await sleep(1500);
  s = await snapshot(ep, { interactive: true });
  await ep.locator((s.diff + s.tree).match(/"다운로드 내역"[^\n]*?\[ref=(\w+)\]/)[1]).click();
  await sleep(4000);
  const info = await ep.evaluate(() => {
    const shown = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const h = [...document.querySelectorAll("body *")].filter((e) => shown(e) && /다운로드 내역/.test(e.textContent || "") && e.querySelector("table, button"))
      .sort((a, b) => a.textContent.length - b.textContent.length)[0];
    if (!h) return "창 없음";
    const btns = [...h.querySelectorAll("button, a")].filter(shown).map((b) => b.textContent.trim().replace(/\s+/g, " ")).filter(Boolean);
    return h.innerText.replace(/\n{2,}/g, "\n").slice(0, 1500) + "\n[버튼] " + [...new Set(btns)].join(" | ");
  });
  console.log(info);
} finally { await closeTab(ep); }
