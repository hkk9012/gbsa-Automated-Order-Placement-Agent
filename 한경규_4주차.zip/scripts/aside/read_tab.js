// 사용자가 열어 둔 탭(URL 일부로 찾음)에 붙어 화면 구조만 읽기 (클릭·입력 없음)
// globalThis.RT_MATCH = 'manage-product-mapping'
const rtMatch = globalThis.RT_MATCH || "";
const rtTabs = await listBrowserTabs();
const rtT = rtTabs.find((t) => t.url.includes(rtMatch));
if (!rtT) throw new Error("탭 없음: " + rtMatch);
await attachBrowserTab(rtT.targetId);
const rtS = await snapshot(page);
console.log(rtS.tree);
