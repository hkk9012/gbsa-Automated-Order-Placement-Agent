// 쿠팡 Wing: 결제완료 주문 '발주확인 처리' (→ 상품준비중) — 주문 엑셀 다운로드 전에 실행
// 실행: run_download.ps1 coupang 이 config/automation.yaml 의 coupang_auto_confirm: true 일 때만 호출
// 동작: 결제완료 탭 → 50개씩 보기 → 전체 선택(선택 수 = 행 수 확인) → [발주확인 처리] → 확인창 승인 → 건수 감소 확인 → 반복
// 출력: CONFIRMED=처리 건수, STATUS 줄. 주문 내용(이름·주소 등)은 출력하지 않음
const cf = await openTab("https://wing.coupang.com/tenants/sfl-portal/delivery/management");
let cfDone = 0;
const cfMsgs = [];
try {
  cf.on("dialog", async (d) => { cfMsgs.push(d.message().replace(/\s+/g, " ").slice(0, 120)); await d.accept(); });  // 브라우저 확인창 = 승인
  await sleep(3500);
  if (/xauth|login/i.test(cf.url())) throw new Error("쿠팡 Wing 로그인 필요");
  const shownJs = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const rowsNow = () => cf.evaluate(() => [...document.querySelectorAll("tbody tr")]
    .filter((r) => { const b = r.getBoundingClientRect(); return b.width > 0 && b.height > 0; })
    .filter((r) => r.querySelector("input[type=checkbox]")).length);
  await cf.getByText("결제완료", { exact: true }).first().click();
  await sleep(3000);
  // 50개씩 보기
  await cf.evaluate(() => {
    const s = [...document.querySelectorAll("select")].find((x) => [...x.options].some((o) => /50개씩/.test(o.text)));
    if (s) { s.value = [...s.options].find((o) => /50개씩/.test(o.text)).value; s.dispatchEvent(new Event("change", { bubbles: true })); }
  });
  await sleep(3000);
  for (let round = 1; round <= 10; round++) {
    const before = await rowsNow();
    console.log(`STATUS 결제완료(처리 전 ${round}회차): ${before}건`);
    if (!before) break;
    const sel = await cf.evaluate(() => {
      const shown = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const head = [...document.querySelectorAll("thead input[type=checkbox], th input[type=checkbox]")].find(shown);
      if (!head) return -1;
      if (!head.checked) head.click();
      return [...document.querySelectorAll("tbody input[type=checkbox]")].filter((c) => shown(c) && c.checked).length;
    });
    if (sel !== before) throw new Error(`선택 수(${sel})가 결제완료 행 수(${before})와 달라 중단`);
    await cf.locator("#confirmOrder").click();
    await sleep(2000);
    // 화면 안 확인창이면 그 안의 '확인'/'발주확인' 버튼 (취소·닫기 제외)
    const modal = await cf.evaluate(() => {
      const shown = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const m = [...document.querySelectorAll("body *")].filter((e) => shown(e) && /발주확인|상품준비중|처리하시겠|진행하시겠/.test(e.textContent || "") && e.querySelector("button") && !e.closest("table"))
        .sort((a, b) => a.textContent.length - b.textContent.length)[0];
      if (!m) return null;
      const ok = [...m.querySelectorAll("button")].filter(shown).find((b) => /^(확인|발주확인|예|처리)$/.test(b.textContent.trim()));
      if (ok) ok.setAttribute("data-agent", "cf-ok");
      return { text: m.innerText.replace(/\s+/g, " ").slice(0, 200), ok: !!ok };
    });
    if (modal) {
      cfMsgs.push(modal.text);
      if (!modal.ok) throw new Error("발주확인 확인창의 승인 버튼을 찾지 못함: " + modal.text);
      await cf.locator('[data-agent="cf-ok"]').click();
    }
    await sleep(3500);
    const after = await rowsNow();
    if (after >= before) throw new Error(`발주확인 후에도 결제완료 건수가 줄지 않음 (${before} → ${after})`);
    cfDone += before - after;
  }
  console.log("확인창 문구:", JSON.stringify(cfMsgs));
  console.log(`CONFIRMED=${cfDone}`);
} finally {
  await closeTab(cf);
}
