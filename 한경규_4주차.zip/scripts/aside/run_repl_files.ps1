﻿# aside repl 스크립트를 실행하고, 스크립트가 출력한 FILE_NAME/FILE_SIZE/FILE_B64 를 받아 지정 폴더에 저장
# 사용: powershell -ExecutionPolicy Bypass -File scripts\aside\run_repl_files.ps1 -Js <js파일> -Dest <저장폴더> [-Prelude "globalThis.X=...;"]
param(
  [Parameter(Mandatory)][string]$Js,
  [Parameter(Mandatory)][string]$Dest,
  [string]$Prelude = ''
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$aside = Join-Path $env:LOCALAPPDATA 'Aside\CLI\current\aside.exe'
New-Item -ItemType Directory -Force $Dest | Out-Null
$runJs = $Js
if ($Prelude) {
  $runJs = Join-Path ([IO.Path]::GetTempPath()) ("aside_" + [guid]::NewGuid().ToString('N') + ".js")
  [IO.File]::WriteAllText($runJs, $Prelude + "`n" + [IO.File]::ReadAllText((Resolve-Path $Js), [Text.Encoding]::UTF8), [Text.UTF8Encoding]::new($false))
}
try {
  $out = @(& $aside repl --file $runJs)
  $code = $LASTEXITCODE
} finally { if ($Prelude) { Remove-Item -LiteralPath $runJs -Force -ErrorAction SilentlyContinue } }
$out | Where-Object { $_ -notlike 'FILE_B64=*' } | ForEach-Object { Write-Output $_ }
if ($code -ne 0) { throw "어사이드 실행 실패 (exit $code)" }
$names = @($out | Where-Object { $_ -like 'FILE_NAME=*' } | ForEach-Object { $_.Substring(10).Trim() })
$sizes = @($out | Where-Object { $_ -like 'FILE_SIZE=*' } | ForEach-Object { [int]$_.Substring(10).Trim() })
$b64s  = @($out | Where-Object { $_ -like 'FILE_B64=*' }  | ForEach-Object { $_.Substring(9).Trim() })
for ($i = 0; $i -lt $b64s.Count; $i++) {
  $bytes = [Convert]::FromBase64String($b64s[$i])
  if ($bytes.Length -ne $sizes[$i]) { throw "파일 크기 불일치: $($names[$i])" }
  $target = Join-Path (Resolve-Path $Dest) ($names[$i] -replace '[\\/:*?"<>|]', '_')
  [IO.File]::WriteAllBytes($target, $bytes)
  Write-Output "저장: $target ($($bytes.Length) bytes)"
}
