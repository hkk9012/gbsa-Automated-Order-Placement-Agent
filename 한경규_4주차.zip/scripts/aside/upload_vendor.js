// 발주처 사이트에 발주 파일 업로드 (run_upload.ps1 이 승인 검사 후 실행)
// 입력(prelude): UV_VENDOR([가림]|[가림]|[가림]|[가림]), UV_MODE(preview|submit), UV_EXPECT(행 수), UV_FILE_NAME, UV_FILE_B64
// preview : 파일 올리고 사이트 확인 화면까지 진행 → 화면 요약 출력, 최종 버튼 누르지 않음
// submit  : preview 와 같게 진행 후, 업체 최종 제출 절차가 '확정'된 경우에만 최종 버튼 클릭 + 결과 화면 요약
// 출력: 표(주문 행) 내용은 출력하지 않음. 제목·안내·오류 문구·버튼·행 개수만.

// ★ 업체별 최종 제출 절차 확정 여부. 첫 시험 업로드(사용자와 함께)로 화면 확인 후 true + finalSteps 작성
const UV_CONFIRMED = { [가림]: false, [가림]: false, [가림]: false, [가림]: false };

const uvVendor = globalThis.UV_VENDOR, uvMode = globalThis.UV_MODE || "preview";
const uvExpect = Number(globalThis.UV_EXPECT || 0);
const uvFile = { name: globalThis.UV_FILE_NAME, mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", buffer: Buffer.from(globalThis.UV_FILE_B64 || "", "base64") };
if (!uvFile.name || !uvFile.buffer.length) throw new Error("업로드 파일 없음");

const UV_URL = {
  [가림]: "[가림]/order/new-order",
  [가림]: "[가림]/orders/new",
  [가림]: "[가림]/partner-app/#/excel",
  [가림]: "[가림]/partner-app/#/excel",
}[uvVendor];
if (!UV_URL) throw new Error("알 수 없는 업체: " + uvVendor);

// 화면 요약: 표 밖의 제목·안내·경고·버튼 + 표 행 개수
const uvSummary = async (p, label) => {
  const r = await p.evaluate(() => {
    const vis = (e) => e.offsetParent !== null;
    const outTable = (e) => !e.closest("table, tbody, [role=grid], [role=table], nav, header, footer, aside");
    const texts = [...document.querySelectorAll("h1,h2,h3,h4,p,strong,em,[role=alert],[role=status],.error,.alert,.toast,[class*=error],[class*=Error],[class*=warn]")]
      .filter((e) => vis(e) && outTable(e) && e.children.length <= 2)
      .map((e) => e.innerText.trim().replace(/\s+/g, " ").slice(0, 120)).filter(Boolean);
    const buttons = [...document.querySelectorAll("button, [role=button], input[type=submit]")]
      .filter((e) => vis(e) && outTable(e)).map((e) => (e.innerText || e.value || "").trim().replace(/\s+/g, " ").slice(0, 30)).filter(Boolean);
    const rows = [...document.querySelectorAll("tbody tr, [role=row]")].filter(vis).length;
    return { url: location.href.split("?")[0], texts: [...new Set(texts)], buttons: [...new Set(buttons)], rows };
  });
  console.log(`\n--- ${label}  (${r.url})\n표 행 수: ${r.rows}\n[문구]\n ${r.texts.join("\n ")}\n[버튼] ${r.buttons.join(" | ")}`);
  return r;
};
const uvClosePopups = async (p) => {
  for (let i = 0; i < 6; i++) {
    const s = await snapshot(p, { interactive: true });
    const r = s.tree.match(/dialog "공지사항"[\s\S]*?button "Close" \[ref=(\w+)\]/)?.[1];
    if (r) { await p.locator(r).click(); await sleep(700); continue; }
    if (/dialog "공지사항"/.test(s.tree)) { await p.keyboard.press("Escape"); await sleep(700); continue; }
    break;
  }
};
const uvRef = (tree, re) => tree.match(re)?.[1];

const up = await openTab(UV_URL);
const uvDialogs = [];
try {
  up.on("dialog", async (d) => { uvDialogs.push(d.message()); console.log("알림창:", d.message()); try { await d.dismiss(); } catch {} });
  await sleep(3500);
  if (/login|signin|auth/i.test(up.url())) throw new Error(uvVendor + " 로그인 필요: 어사이드에서 로그인 후 다시 실행");

  if (uvVendor === "[가림]") {
    await uvClosePopups(up);
    const s = await snapshot(up, { interactive: true });
    const radio = uvRef(s.tree, /radio "[가림] 기본 엑셀양식" \[ref=(\w+)\]/);
    if (radio && !/radio "[가림] 기본 엑셀양식" \[ref=\w+\] \[checked\]/.test(s.tree)) await up.locator(radio).click();
    await up.locator('input[type="file"]').first().setInputFiles(uvFile);
    await sleep(4000);
  } else if (uvVendor === "[가림]") {
    const s = await snapshot(up, { interactive: true });
    const radio = uvRef(s.tree, /radio "공통 엑셀 \(기본 양식\)" \[ref=(\w+)\]/);
    if (radio && !/radio "공통 엑셀 \(기본 양식\)" \[ref=\w+\] \[checked\]/.test(s.tree)) await up.locator(radio).click();
    await up.locator('input[type="file"]').first().setInputFiles(uvFile);
    await sleep(2500);
    const s2 = await snapshot(up, { interactive: true });
    const next = uvRef(s2.tree, /button "다음" \[ref=(\w+)\]/);
    if (!next) throw new Error("[가림] '다음' 버튼 없음");
    await up.locator(next).click();
    await sleep(4000);
  } else {
    // adminplus ([가림]·[가림]): 업로드 방식 '공통 엑셀파일' → 파일 → '다음: 엑셀 내용 확인'
    const s = await snapshot(up, { interactive: true });
    const radio = uvRef(s.tree, /radio "공통 엑셀파일[^"]*" \[ref=(\w+)\]/);
    if (radio && !/radio "공통 엑셀파일[^"]*" \[ref=\w+\] \[checked\]/.test(s.tree)) await up.locator(radio).click();
    await up.locator('input[type="file"]').first().setInputFiles(uvFile);
    await sleep(2500);
    const s2 = await snapshot(up, { interactive: true });
    const next = uvRef(s2.tree, /button "다음: 엑셀 내용 확인" \[ref=(\w+)\]/);
    if (!next) throw new Error("adminplus '다음: 엑셀 내용 확인' 버튼 없음");
    await up.locator(next).click();
    await sleep(4000);
  }

  const pv = await uvSummary(up, "업로드 후 확인 화면");
  console.log(`PREVIEW_ROWS=${pv.rows} EXPECT=${uvExpect}`);
  if (uvMode !== "submit") {
    console.log("RESULT=PREVIEW_ONLY (최종 버튼 누르지 않음)");
  } else {
    if (!UV_CONFIRMED[uvVendor]) throw new Error(`${uvVendor} 최종 제출 절차 미확정 → 첫 시험 업로드에서 화면 확인 후 upload_vendor.js 에 확정 필요. 최종 버튼 누르지 않음`);
    // (확정 후 업체별 최종 단계 작성 위치)
    throw new Error("최종 제출 단계 미작성");
  }
} finally {
  await closeTab(up);
}
