"""분류 결과를 업체별 발주 양식에 채워 upload/{업체}/DATE/ 에 만든다.

사용: python scripts/build_upload_files.py YYYY-MM-DD
입력: orders/DATE/분류/전체_분류결과.xlsx, config/vendors.yaml, templates/발주양식/{업체}/양식
출력: upload/{업체}/DATE/발주_{업체}_{DATE}.xlsx  +  _요약.json (승인 단계에서 사용)

- 양식의 헤더 아래 예시 행은 모두 지우고 주문만 채운다.
- done/_발주완료목록.csv 에 있는 주문(market+order_no+product_code+option)은 제외(중복 발주 방지).
- 화면 출력은 건수·상품·주문번호만 (수취인 이름·전화·주소 출력 금지).
"""
import hashlib
import json
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd
import yaml
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parent.parent
LEDGER = ROOT / "done" / "_발주완료목록.csv"
KEY = ["market", "order_no", "product_code", "option"]
PHONE_OK = re.compile(r"^01[0]-?\d{3,4}-?\d{4}$")


def load_ledger():
    if LEDGER.exists():
        return pd.read_csv(LEDGER, dtype=str, encoding="utf-8-sig").fillna("")
    return pd.DataFrame(columns=KEY + ["vendor", "date", "file"])


def resolve(src, row, sender):
    """vendors.yaml columns 의 값 지정 방식을 실제 값으로 바꾼다."""
    s = str(src)
    if s.startswith("fixed:"):
        return s[6:]
    if s.startswith("sender:"):
        return (sender or {}).get(s[7:], "") or ""
    if s.startswith("fmt:"):
        return s[4:].format(**row).strip()
    if s == "vendor_product":
        vp = str(row.get("vendor_product", "")).strip()
        return vp or f"{row.get('product_name', '')} {row.get('option', '')}".strip()
    if s == "qty":
        try:
            return int(float(row.get("qty", "")))
        except ValueError:
            return row.get("qty", "")
    return row.get(s, "")


def build_vendor(vendor, rows, v, sender, out):
    """한 업체의 발주 파일을 만든다. 반환: 경고 목록"""
    tpl = ROOT / "templates" / "발주양식" / v["template"]
    if not tpl.exists():
        sys.exit(f"[오류] {vendor}: 양식 파일 없음 → {tpl.relative_to(ROOT)}")
    hr = int(v.get("header_row", 1))
    shutil.copy(tpl, out)
    wb = load_workbook(out)
    ws = wb.worksheets[0]
    headers = {str(ws.cell(hr, c).value).strip(): c for c in range(1, ws.max_column + 1)
               if ws.cell(hr, c).value is not None}
    miss = [h for h in v["columns"] if h not in headers]
    if miss:
        sys.exit(f"[오류] {vendor}: 양식에 없는 헤더 {miss} → vendors.yaml 확인")
    # 헤더 아래 예시 행 삭제
    if ws.max_row > hr:
        ws.delete_rows(hr + 1, ws.max_row - hr)

    warns = []
    if any(str(s).startswith("sender:") for s in v["columns"].values()) and not all((sender or {}).get(k) for k in ("name", "phone", "address")):
        warns.append("보내는사람 정보(vendors.yaml sender) 비어 있음")
    non010 = []
    for i, (_, row) in enumerate(rows.iterrows(), start=hr + 1):
        rd = row.to_dict()
        for h, src in v["columns"].items():
            ws.cell(i, headers[h], resolve(src, rd, sender))
        if not PHONE_OK.match(str(rd.get("receiver_phone", "")).strip()):
            non010.append(str(rd["order_no"]))
    if "vendor_product" in v["columns"].values() and "vendor_product" in rows.columns:
        n_blank = int((rows["vendor_product"].fillna("").str.strip() == "").sum())
        if n_blank:
            warns.append(f"발주처품명 미입력 {n_blank}건 → 마켓 상품명+옵션으로 기입됨 (상품매칭.xlsx '공급처매칭' 발주처품명 입력 권장)")
    if "match_note" in rows.columns:
        alt = rows[rows["match_note"].fillna("").str.startswith("대체공급")]
        if len(alt):
            warns.append(f"대체공급 {len(alt)}건 (1순위 품절로 이 업체로 전환): {', '.join(alt['order_no'])}")
    if non010 and vendor == "[가림]":
        warns.append(f"받는분 전화번호가 010 형식이 아닌 주문 {len(non010)}건(쿠팡 안심번호 050x 등) - [가림] 안내: '010 등 표준형식, 011·+82 거부' → 안심번호 수용 여부 첫 업로드 때 확인")
    wb.save(out)
    return warns


def main(date):
    vcfg = yaml.safe_load((ROOT / "config/vendors.yaml").read_text(encoding="utf-8"))
    cfg, sender = vcfg["vendors"], vcfg.get("sender", {})
    df = pd.read_excel(ROOT / "orders" / date / "분류" / "전체_분류결과.xlsx", dtype=str).fillna("")
    df = df[df["check"] == ""]
    # 같은 날짜로 예전에 만든 업로드 대기 파일 정리 (업로드 전 생성물만; 업로드 완료분은 done/ 에 있음)
    for vendor in cfg:
        od = ROOT / "upload" / vendor / date
        if od.exists():
            for f in list(od.glob("발주_*.xlsx")) + list(od.glob("_요약.json")) + list(od.glob("APPROVED*.json")):
                f.unlink()
    if df.empty:
        sys.exit("[알림] 발주 가능한 건이 없습니다.")

    ledger = load_ledger()
    done_keys = set(map(tuple, ledger[KEY].values.tolist()))
    for vendor, rows in df.groupby("vendor"):
        if vendor not in cfg:
            print(f"[건너뜀] {vendor}: config/vendors.yaml에 업체 설정 없음 ({len(rows)}건)")
            continue
        is_dup = rows[KEY].apply(tuple, axis=1).isin(done_keys)
        if is_dup.any():
            print(f"[{vendor}] 이미 발주 완료된 {is_dup.sum()}건 제외: {', '.join(rows.loc[is_dup, 'order_no'])}")
        rows = rows[~is_dup]
        outdir = ROOT / "upload" / vendor / date
        if rows.empty:
            print(f"[{vendor}] 새로 발주할 건 없음")
            continue
        outdir.mkdir(parents=True, exist_ok=True)
        for old in outdir.glob("APPROVED*.json"):  # 파일을 새로 만들면 이전 승인은 무효
            old.unlink()
        out = outdir / f"발주_{vendor}_{date}.xlsx"
        warns = build_vendor(vendor, rows, cfg[vendor], sender, out)

        qty = pd.to_numeric(rows["qty"], errors="coerce").fillna(0)
        label = rows.apply(lambda r: (str(r.get("vendor_product", "")).strip()
                                      or f"{r['product_name']} / {r['option']}".strip(" /")), axis=1)
        products = (rows.assign(q=qty, label=label).groupby("label")["q"].sum()
                    .reset_index().sort_values("q", ascending=False))
        summary = {
            "vendor": vendor, "date": date, "file": out.name,
            "sha256": hashlib.sha256(out.read_bytes()).hexdigest(),
            "orders": int(rows["order_no"].nunique()), "rows": int(len(rows)), "qty_total": int(qty.sum()),
            "markets": rows["market"].value_counts().to_dict(),
            "products": [{"product": p, "qty": int(q)} for p, q in products.values.tolist()],
            "order_nos": rows["order_no"].tolist(),
            "keys": rows[KEY].values.tolist(),
            "warnings": warns,
            "built_at": datetime.now().isoformat(timespec="seconds"),
        }
        (outdir / "_요약.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"[{vendor}] {summary['orders']}주문 / {summary['rows']}행 / 수량 {summary['qty_total']} → {out.relative_to(ROOT)}"
              + (f"  ⚠ 경고 {len(warns)}건" if warns else ""))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("사용법: python scripts/build_upload_files.py YYYY-MM-DD")
    main(sys.argv[1])
