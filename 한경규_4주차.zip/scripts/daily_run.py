"""매일 아침 발주 준비 (업로드·최종 발주는 하지 않음 — 사용자 승인 후 별도)

사용: python scripts/daily_run.py [YYYY-MM-DD] [--skip-supply]
 1) 주문 수집: 쿠팡(어사이드, 상품준비중 엑셀 + 결제완료 건수) / 토스(API 키 있으면 API)
 2) 공급상품 점검: 업체 4곳 상품목록 재다운로드 → 품절·가격변동 알림  (--skip-supply 로 생략)
 3) 분류(매칭표 기준) → 4) 업체별 발주 양식 작성 → 5) 교차 검증
 6) 보고서: reports/DATE_발주준비.html / .txt / .json  (고객 이름·전화·주소 없음 — 주문번호·상품·건수만)
마지막 줄: REPORT_HTML=경로 / REPORT_STATUS=통과|확인 필요|오류
"""
import html
import json
import re
import subprocess
import sys
import time
from datetime import date, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
ROOT = Path(__file__).resolve().parent.parent
PY = sys.executable
PS = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File"]
REPORTS = ROOT / "reports"


def run(cmd, timeout=900):
    t = time.time()
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout, cwd=str(ROOT))
        out = (p.stdout or "") + ("\n" + p.stderr if p.stderr else "")
        out = "\n".join(l for l in out.splitlines() if not l.startswith("FILE_B64=") and not re.match(r"^\s*(\+ |At |CategoryInfo|FullyQualified)", l))
        return p.returncode, out.strip(), int(time.time() - t)
    except subprocess.TimeoutExpired:
        return -1, f"시간 초과 ({timeout}초)", timeout


def pick(out, pat):
    return [l.strip() for l in out.splitlines() if re.search(pat, l)]


def main(day, skip_supply=False, skip_collect=False):
    R = {"date": day, "started": datetime.now().strftime("%Y-%m-%d %H:%M"), "steps": [], "errors": []}

    def step(name, code, out, sec, ok_codes=(0,), keep=r"."):
        ok = code in ok_codes
        R["steps"].append({"name": name, "ok": ok, "sec": sec, "lines": pick(out, keep)[:15]})
        if not ok:
            R["errors"].append(f"{name}: " + " / ".join(pick(out, r"Error|오류|실패|필요|초과|차단")[:3] or out.splitlines()[-2:]))
        return ok

    # 1) 주문 수집  (--skip-collect: 이미 받은 파일로 분류·작성·검증·보고만 다시)
    if skip_collect:
        prev = REPORTS / f"{day}_발주준비.json"
        pj = json.loads(prev.read_text(encoding="utf-8")) if prev.exists() else {}
        import pandas as pd
        files = sorted((ROOT / "orders" / day / "원본" / "coupang").glob("*.xlsx"))
        R["coupang_ready"] = int(pd.concat([pd.read_excel(f, dtype=str) for f in files])["주문번호"].drop_duplicates().notna().sum()) if files else 0
        R["coupang_paid"] = pj.get("coupang_paid", 0)
        R["toss_line"] = pj.get("toss_line", "")
        R["steps"].append({"name": "주문 수집", "ok": True, "sec": 0, "lines": ["생략(이미 받은 파일 사용)"]})
    c, o, s = (0, "", 0) if skip_collect else run(PS + [str(ROOT / "scripts/aside/run_download.ps1"), "coupang", day])
    if not skip_collect:
        step("쿠팡 주문 수집", c, o, s, keep=r"STATUS|저장:|생략|Error|필요|발주확인|CONFIRMED")
        m = re.search(r"CONFIRMED=(\d+)", o)
        R["coupang_confirmed"] = int(m[1]) if m else None          # None = 발주확인 단계 미실행
        R["coupang_confirm_off"] = "발주확인 자동 처리 꺼짐" in o
        if "발주확인 처리 실패" in o:
            R["errors"].append("쿠팡 발주확인 처리 실패: " + " / ".join(pick(o, r"Error|중단|못함")[:2]))
        R["coupang_paid"] = int((re.search(r"STATUS 결제완료: (\d+)건", o) or [0, 0])[1])
        R["coupang_ready"] = int((re.search(r"STATUS 상품준비중: (\d+)건", o) or [0, 0])[1])
    saved = re.search(r"저장: (.+?\.xlsx)", o)
    if saved:   # 화면은 한 페이지만 보이므로 실제 건수는 받은 파일의 행 수로
        try:
            import pandas as pd
            R["coupang_ready"] = int(pd.read_excel(saved[1].strip(), dtype=str)["주문번호"].notna().sum())
        except Exception:  # noqa: BLE001
            pass
    if not skip_collect:
        c, o, s = run(PS + [str(ROOT / "scripts/aside/run_download.ps1"), "toss", day])
        step("토스 주문 수집", c, o, s, keep=r"토스 주문|STATUS|저장:|생략|Error|오류|필요")
        R["toss_line"] = (pick(o, r"토스 주문\(API\)|STATUS") or [""])[0]

    # 2) 공급상품 점검
    if not skip_supply:
        import matching
        lines = []
        for v in matching.vendor_names():
            for attempt in (1, 2):   # [가림] '보안 확인' 등 일시 실패 → 한 번 더
                c, o, s = run(PS + [str(ROOT / "scripts/aside/run_repl_files.ps1"), "-Js", str(ROOT / "scripts/aside/get_catalogs.js"),
                                    "-Dest", str(ROOT / "catalogs" / v), "-Prelude", f"globalThis.GC_VENDOR='{v}';"], timeout=300)
                if c == 0 and "저장:" in o:
                    break
            lines.append(f"{v}: {'목록 받음' if c == 0 and '저장:' in o else '받기 실패(2회) → 이전 목록 사용'}")
            if not (c == 0 and "저장:" in o):
                R.setdefault("warnings", []).append(f"{v} 상품목록 받기 실패 → 이전 목록으로 품절·가격 점검")
        c1, o1, s1 = run([PY, "-X", "utf8", "-W", "ignore", str(ROOT / "scripts/matching.py"), "catalog"])
        c2, o2, s2 = run([PY, "-X", "utf8", "-W", "ignore", str(ROOT / "scripts/market_sync.py"), "monitor"])
        R["steps"].append({"name": "공급상품 점검", "ok": c1 == 0 and c2 == 0, "sec": s1 + s2, "lines": lines + pick(o2, r"점검")})
        m = re.search(r"새 알림 (\d+)건", o2)
        R["new_alerts"] = int(m[1]) if m else 0
        if c2 != 0:
            R["errors"].append("공급상품 점검: " + o2[-200:])

    # 3) 분류
    c, o, s = run([PY, "-X", "utf8", "-W", "ignore", str(ROOT / "scripts/classify_orders.py"), day])
    no_orders = "주문 파일이 없습니다" in o
    step("분류", 0 if no_orders else c, o, s, keep=r".")
    # 4) 업체별 양식 작성
    if not no_orders:
        c, o, s = run([PY, "-X", "utf8", "-W", "ignore", str(ROOT / "scripts/build_upload_files.py"), day])
        step("업체별 발주 파일 작성", 0 if "발주 가능한 건이 없습니다" in o else c, o, s, keep=r".")
    # 5) 교차 검증
    import verify_upload
    V = verify_upload.verify(day) if not no_orders else {"global": [], "vendors": {}, "excluded": []}
    R["verify"] = V
    # 업체별 요약
    R["vendors"] = []
    for sj in sorted((ROOT / "upload").glob(f"*/{day}/_요약.json")):
        s = json.loads(sj.read_text(encoding="utf-8"))
        R["vendors"].append({**{k: s[k] for k in ("vendor", "orders", "rows", "qty_total", "markets", "products", "order_nos", "warnings", "file")},
                             "verify": V["vendors"].get(s["vendor"], {})})
    # 공급 변동 알림(대기)
    try:
        import market_sync
        R["pending_alerts"] = [{k: a[k] for k in ("유형", "마켓", "판매상품명", "옵션명", "발주처", "발주처품명", "기준공급가", "현재공급가", "현재판매가", "제안판매가")}
                               for a in market_sync.alerts() if a.get("처리") == "대기"]
    except Exception as e:  # noqa: BLE001
        R["pending_alerts"] = []
        R["errors"].append(f"알림 읽기: {e}")

    # 상태 판정
    vstat = [x.get("verify", {}).get("status") for x in R["vendors"]]
    if R["errors"] or "오류" in vstat:
        status = "오류"
    elif V.get("excluded") or V.get("global") or "확인 필요" in vstat or R.get("coupang_paid") or R["pending_alerts"]:
        status = "확인 필요"
    else:
        status = "통과"
    R["status"] = status
    R["finished"] = datetime.now().strftime("%H:%M")
    write_report(R)
    return R


def write_report(R):
    REPORTS.mkdir(exist_ok=True)
    d = R["date"]
    e = html.escape
    icon = {"통과": "✅", "확인 필요": "⚠️", "오류": "❌"}[R["status"]]
    total_orders = sum(v["orders"] for v in R["vendors"])
    H = [f"""<div style="font-family:'Malgun Gothic',sans-serif;font-size:14px;color:#1f2328;max-width:760px">
<h2 style="margin:0 0 4px">{icon} 발주 준비 보고 — {e(d)}</h2>
<div style="color:#6b7280;font-size:12.5px">실행 {e(R['started'])} ~ {e(R['finished'])} · 상태: <b>{e(R['status'])}</b> · 업체 사이트 업로드(최종 발주)는 승인 후 진행됩니다</div>"""]
    # 요약
    H.append("<h3 style='margin:18px 0 6px'>1. 주문 수집</h3><ul style='margin:0'>")
    if R.get("coupang_confirmed") is not None:
        H.append(f"<li>쿠팡 발주확인 처리: 결제완료 <b>{R['coupang_confirmed']}</b>건 → 상품준비중</li>")
    elif R.get("coupang_confirm_off"):
        H.append("<li style='color:#b45309'>쿠팡 발주확인 자동 처리: 꺼짐 (config/automation.yaml)</li>")
    H.append(f"<li>쿠팡: 상품준비중 <b>{R.get('coupang_ready', 0)}</b>건 수집"
             + (f" · <span style='color:#b45309'>결제완료 <b>{R['coupang_paid']}</b>건은 Wing '발주확인 처리' 후에 수집됩니다</span>" if R.get("coupang_paid") else "") + "</li>")
    H.append(f"<li>토스: {e(R.get('toss_line') or '-')}</li></ul>")
    # 업체별
    H.append(f"<h3 style='margin:18px 0 6px'>2. 업체별 발주 파일 ({len(R['vendors'])}곳 · 주문 {total_orders}건)</h3>")
    if not R["vendors"]:
        H.append("<p style='margin:0'>오늘 발주할 파일이 없습니다.</p>")
    for v in R["vendors"]:
        vf = v["verify"]
        st = vf.get("status", "-")
        col = {"통과": "#1a7f37", "확인 필요": "#b45309", "오류": "#c0392b"}.get(st, "#6b7280")
        H.append(f"""<div style="border:1px solid #e3e6ea;border-radius:8px;padding:10px 12px;margin:8px 0">
<div><b style="font-size:15px">{e(v['vendor'])}</b> · 주문 {v['orders']}건 / 총수량 {v['qty_total']} · 검증 <b style="color:{col}">{e(st)}</b> ({vf.get('checks', 0)}항목 대조)</div>
<div style="color:#6b7280;font-size:12px">{e(v['file'])} · 마켓 {e(', '.join(f'{k} {n}' for k, n in v['markets'].items()))}</div><ul style="margin:6px 0 0">""")
        for p in v["products"][:20]:
            H.append(f"<li>{e(p['product'])} × {p['qty']}</li>")
        H.append("</ul>")
        H.append(f"<div style='font-size:12px;color:#6b7280;margin-top:4px'>주문번호: {e(', '.join(v['order_nos']))}</div>")
        for w in v["warnings"]:
            H.append(f"<div style='color:#b45309;font-size:12.5px'>⚠ {e(w)}</div>")
        for i in vf.get("issues", []):
            H.append(f"<div style='color:#c0392b;font-size:12.5px'>✖ {e(i)}</div>")
        H.append("</div>")
    # 제외
    ex = R["verify"].get("excluded", [])
    H.append(f"<h3 style='margin:18px 0 6px'>3. 발주에서 제외된 주문 ({len(ex)}건)</h3>")
    if ex:
        H.append("<table style='border-collapse:collapse;font-size:12.5px'><tr style='background:#eef1f5'><th style='padding:4px 8px;text-align:left'>주문번호</th><th style='padding:4px 8px;text-align:left'>마켓</th><th style='padding:4px 8px;text-align:left'>상품</th><th style='padding:4px 8px;text-align:left'>사유</th></tr>")
        for x in ex:
            H.append(f"<tr><td style='padding:4px 8px'>{e(x['order_no'])}</td><td style='padding:4px 8px'>{e(x['market'])}</td><td style='padding:4px 8px'>{e(x['product'])}</td><td style='padding:4px 8px;color:#c0392b'>{e(x['reason'])}</td></tr>")
        H.append("</table><div style='font-size:12px;color:#6b7280'>매칭없음·품명미매칭 → 매칭 화면(상품매칭 열기.cmd)에서 공급 상품을 고른 뒤 다시 실행</div>")
    else:
        H.append("<p style='margin:0'>없음</p>")
    for g in R["verify"].get("global", []) + R.get("warnings", []):
        H.append(f"<div style='color:#b45309;font-size:12.5px'>⚠ {e(g)}</div>")
    # 공급 변동
    al = R.get("pending_alerts", [])
    H.append(f"<h3 style='margin:18px 0 6px'>4. 공급 변동 알림 (처리 대기 {len(al)}건)</h3>")
    if al:
        H.append("<ul style='margin:0'>")
        for a in al[:30]:
            H.append(f"<li>[{e(a['유형'])}] {e(a['판매상품명'])} {e(a['옵션명'])} ← {e(a['발주처'])} {e(a['발주처품명'])}: "
                     f"{e(a['기준공급가'] or '-')} → {e(a['현재공급가'] or '-')}원"
                     + (f" · 제안 판매가 {e(a['제안판매가'])}원 (현재 {e(a['현재판매가'])})" if a.get("제안판매가") else "") + "</li>")
        H.append("</ul>")
    else:
        H.append("<p style='margin:0'>없음</p>")
    # 실행 단계
    H.append("<h3 style='margin:18px 0 6px'>5. 실행 단계</h3><ul style='margin:0;font-size:12.5px'>")
    for s in R["steps"]:
        H.append(f"<li>{'✅' if s['ok'] else '❌'} {e(s['name'])} ({s['sec']}초)" + (f" — {e(' / '.join(s['lines'][:4]))}" if s["lines"] else "") + "</li>")
    H.append("</ul>")
    for er in R["errors"]:
        H.append(f"<div style='color:#c0392b'>❌ {e(er)}</div>")
    # 다음 할 일
    H.append("<h3 style='margin:18px 0 6px'>6. 다음 할 일</h3><ul style='margin:0'>")
    if R["vendors"]:
        names = ", ".join(v["vendor"] for v in R["vendors"] if v["verify"].get("status") != "오류")
        H.append(f"<li>검증 통과 업체 업로드: Claude에게 <b>“업로드 진행: {e(names)}”</b>라고 승인해 주세요.</li>" if names else "")
        if any(v["verify"].get("status") == "오류" for v in R["vendors"]):
            H.append("<li style='color:#c0392b'>검증 오류가 있는 업체는 원인 확인 후 다시 작성해야 합니다.</li>")
    if R.get("coupang_paid"):
        H.append(f"<li>쿠팡 결제완료 {R['coupang_paid']}건: Wing에서 '발주확인 처리' 후 다시 수집</li>")
    if ex:
        H.append("<li>제외된 주문: 매칭 후 재실행</li>")
    if al:
        H.append("<li>공급 변동 알림: 매칭 화면 '공급 변동 알림' 탭에서 승인/무시</li>")
    H.append("</ul><p style='color:#9ca3af;font-size:11.5px;margin-top:16px'>이 메일에는 고객 이름·연락처·주소를 넣지 않습니다. 상세 파일은 PC의 upload/ 폴더에 있습니다.</p></div>")
    html_text = "\n".join(h for h in H if h)
    (REPORTS / f"{d}_발주준비.html").write_text(html_text, encoding="utf-8")
    (REPORTS / f"{d}_발주준비.json").write_text(json.dumps(R, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    # 로그 (주문번호만)
    log = ROOT / "logs" / f"{d}.md"
    log.parent.mkdir(exist_ok=True)
    if not log.exists():
        log.write_text(f"## {d}\n", encoding="utf-8")
    with log.open("a", encoding="utf-8") as fp:
        fp.write(f"- [자동 {R['started'][-5:]}] 발주 준비 {R['status']}: 쿠팡 발주확인 {R.get('coupang_confirmed') if R.get('coupang_confirmed') is not None else '미실행'} / 상품준비중 {R.get('coupang_ready', 0)}·결제완료 {R.get('coupang_paid', 0)} / 토스 {R.get('toss_line', '')} / "
                 + ", ".join(f"{v['vendor']} {v['orders']}건({v['verify'].get('status', '-')})" for v in R["vendors"])
                 + f" / 제외 {len(ex)}건 / 알림 대기 {len(al)}건\n")
    print(f"REPORT_HTML={REPORTS / f'{d}_발주준비.html'}")
    print(f"REPORT_STATUS={R['status']}")


if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    main(a[0] if a else date.today().isoformat(), skip_supply="--skip-supply" in sys.argv, skip_collect="--skip-collect" in sys.argv)
