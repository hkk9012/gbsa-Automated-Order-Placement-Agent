"""발주 업로드 승인·완료 관리.

  python scripts/upload_manager.py review  YYYY-MM-DD            업체별 검토 요약 (승인 전에 사용자에게 보여줌)
  python scripts/upload_manager.py approve YYYY-MM-DD 업체 [업체..] 사용자가 채팅에서 "업로드 진행" 승인한 업체만 승인 기록
  python scripts/upload_manager.py check   YYYY-MM-DD 업체          업로드 직전 검사 (승인·파일 변경·중복). 통과 시 exit 0
  python scripts/upload_manager.py done    YYYY-MM-DD 업체 "결과"   업로드 성공 처리: 장부 기록, done/ 이동, 로그
  python scripts/upload_manager.py fail    YYYY-MM-DD 업체 "사유"   업로드 실패 기록 (파일은 upload/ 에 남김)

승인(APPROVED.json)에는 파일의 sha256이 들어간다. 승인 후 파일이 바뀌면 check 가 막는다.
화면·로그에는 주문번호·건수·상품만 남기고, 수취인 이름은 가려서(홍*동) 샘플로만 보여준다.
"""
import hashlib
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parent.parent
LEDGER = ROOT / "done" / "_발주완료목록.csv"
KEY = ["market", "order_no", "product_code", "option"]


def vdir(date, vendor):
    return ROOT / "upload" / vendor / date


def load_summary(date, vendor):
    p = vdir(date, vendor) / "_요약.json"
    if not p.exists():
        sys.exit(f"[오류] {vendor} {date}: 업로드 파일 요약 없음 → build_upload_files.py 먼저 실행")
    return json.loads(p.read_text(encoding="utf-8"))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def mask(name):
    n = str(name).strip()
    if len(n) <= 1:
        return "*"
    if len(n) == 2:
        return n[0] + "*"
    return n[0] + "*" * (len(n) - 2) + n[-1]


def ledger():
    if LEDGER.exists():
        return pd.read_csv(LEDGER, dtype=str, encoding="utf-8-sig").fillna("")
    return pd.DataFrame(columns=KEY + ["vendor", "date", "file"])


def receiver_samples(date, vendor, s, k=3):
    cfg = yaml.safe_load((ROOT / "config/vendors.yaml").read_text(encoding="utf-8"))["vendors"][vendor]
    col = next((h for h, src in cfg["columns"].items() if src == "receiver_name"), None)
    oc = next((h for h, src in cfg["columns"].items() if src == "order_no"), None)
    if not col:
        return []
    df = pd.read_excel(vdir(date, vendor) / s["file"], dtype=str, header=int(cfg.get("header_row", 1)) - 1).fillna("")
    return [f"{r.get(oc, '')} {mask(r[col])}" for _, r in df.head(k).iterrows()]


def approval_state(date, vendor, s):
    ap = vdir(date, vendor) / "APPROVED.json"
    f = vdir(date, vendor) / s["file"]
    if not ap.exists():
        return "미승인"
    a = json.loads(ap.read_text(encoding="utf-8"))
    return "승인됨" if f.exists() and a.get("sha256") == sha(f) else "승인 무효(파일 변경됨)"


def review(date):
    found = sorted((ROOT / "upload").glob(f"*/{date}/_요약.json"))
    if not found:
        print(f"[{date}] 업로드 대기 파일 없음")
        return
    led = ledger()
    done_keys = set(map(tuple, led[KEY].values.tolist()))
    for p in found:
        vendor = p.parent.parent.name
        s = json.loads(p.read_text(encoding="utf-8"))
        dup = [k[1] for k in s["keys"] if tuple(k) in done_keys]
        print(f"\n■ {vendor}  [{approval_state(date, vendor, s)}]")
        print(f"  파일: upload/{vendor}/{date}/{s['file']}")
        print(f"  주문 {s['orders']}건 / {s['rows']}행 / 총수량 {s['qty_total']}  (마켓: {', '.join(f'{k} {v}' for k, v in s['markets'].items())})")
        for pr in s["products"][:15]:
            print(f"   - {pr['product']} × {pr['qty']}")
        if len(s["products"]) > 15:
            print(f"   ... 외 {len(s['products']) - 15}종")
        print(f"  주문번호: {', '.join(s['order_nos'][:10])}{' ...' if len(s['order_nos']) > 10 else ''}")
        print(f"  수취인 샘플: {' / '.join(receiver_samples(date, vendor, s))}")
        for w in s["warnings"]:
            print(f"  ⚠ {w}")
        if dup:
            print(f"  ⛔ 이미 발주 완료된 주문 포함: {', '.join(dup)} → 파일 다시 생성 필요")


def approve(date, vendors):
    for vendor in vendors:
        s = load_summary(date, vendor)
        f = vdir(date, vendor) / s["file"]
        rec = {"vendor": vendor, "date": date, "file": s["file"], "sha256": sha(f),
               "orders": s["orders"], "qty_total": s["qty_total"],
               "approved_at": datetime.now().isoformat(timespec="seconds"), "approved_by": "사용자(채팅 승인)"}
        (vdir(date, vendor) / "APPROVED.json").write_text(json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"[승인 기록] {vendor} {date}: {s['orders']}건, 파일 {s['file']}")


def check(date, vendor):
    s = load_summary(date, vendor)
    st = approval_state(date, vendor, s)
    if st != "승인됨":
        sys.exit(f"[차단] {vendor} {date}: {st} → 사용자 승인 후 approve 실행 필요")
    led = ledger()
    done_keys = set(map(tuple, led[KEY].values.tolist()))
    dup = [k[1] for k in s["keys"] if tuple(k) in done_keys]
    if dup:
        sys.exit(f"[차단] {vendor} {date}: 이미 발주 완료된 주문 포함 {dup}")
    print(f"[통과] {vendor} {date}: {s['orders']}건 → {vdir(date, vendor) / s['file']}")


def append_log(date, line):
    log = ROOT / "logs" / f"{date}.md"
    log.parent.mkdir(parents=True, exist_ok=True)
    if not log.exists():
        log.write_text(f"## {date}\n", encoding="utf-8")
    with log.open("a", encoding="utf-8") as fp:
        fp.write(line.rstrip() + "\n")


def done(date, vendor, result):
    s = load_summary(date, vendor)
    check(date, vendor)
    led = ledger()
    add = pd.DataFrame(s["keys"], columns=KEY).assign(vendor=vendor, date=date, file=s["file"])
    LEDGER.parent.mkdir(parents=True, exist_ok=True)
    pd.concat([led, add], ignore_index=True).to_csv(LEDGER, index=False, encoding="utf-8-sig")
    dest = ROOT / "done" / vendor / date
    dest.mkdir(parents=True, exist_ok=True)
    for f in vdir(date, vendor).iterdir():
        target = dest / f.name
        if target.exists():
            target = dest / f"{f.stem}_{datetime.now():%H%M%S}{f.suffix}"
        shutil.move(str(f), str(target))
    now = datetime.now().strftime("%H:%M")
    append_log(date, f"- 업로드: {vendor} {now} {result} / 주문번호 {', '.join(s['order_nos'])}")
    print(f"[완료] {vendor} {date}: 장부 {len(add)}행 추가, done/{vendor}/{date}/ 로 이동, 로그 기록")


def fail(date, vendor, reason):
    append_log(date, f"- 업로드 실패: {vendor} {datetime.now():%H:%M} ({reason}) - 파일은 upload/ 에 유지")
    print(f"[실패 기록] {vendor} {date}: {reason}")


if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) >= 2 and a[0] == "review":
        review(a[1])
    elif len(a) >= 3 and a[0] == "approve":
        approve(a[1], a[2:])
    elif len(a) == 3 and a[0] == "check":
        check(a[1], a[2])
    elif len(a) == 4 and a[0] == "done":
        done(a[1], a[2], a[3])
    elif len(a) == 4 and a[0] == "fail":
        fail(a[1], a[2], a[3])
    else:
        sys.exit(__doc__)
