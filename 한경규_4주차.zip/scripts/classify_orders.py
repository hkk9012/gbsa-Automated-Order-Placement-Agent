"""주문 원본(쿠팡/토스)을 읽어 발주처별로 분류한다.

사용: python scripts/classify_orders.py YYYY-MM-DD
입력: orders/DATE/원본/{coupang,toss}/*.xlsx|xls|csv
출력: orders/DATE/분류/전체_분류결과.xlsx, 미분류.xlsx
"""
import sys
from pathlib import Path

import pandas as pd
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import matching  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
STD = ["market", "order_no", "order_date", "product_code", "product_name", "option",
       "qty", "receiver_name", "receiver_phone", "zip", "address", "memo"]


def read_any(path, header_row):
    if path.suffix.lower() == ".csv":
        for enc in ("utf-8-sig", "cp949"):
            try:
                return pd.read_csv(path, header=header_row, dtype=str, encoding=enc)
            except UnicodeDecodeError:
                continue
        raise
    return pd.read_excel(path, header=header_row, dtype=str)


def load_market(date, market, cfg):
    folder = ROOT / "orders" / date / "원본" / cfg["folder"]
    frames = []
    for f in sorted(folder.glob("*")) if folder.exists() else []:
        if f.suffix.lower() not in (".xlsx", ".xls", ".csv") or f.name.startswith("~$"):
            continue
        df = read_any(f, cfg.get("header_row", 0))
        missing = [v for v in cfg["columns"].values() if v not in df.columns]
        if missing:
            sys.exit(f"[오류] {f.name}: markets.yaml의 컬럼명이 파일에 없음 → {missing}\n"
                     f"       파일의 실제 헤더: {list(df.columns)}")
        out = pd.DataFrame({std: df[src] for std, src in cfg["columns"].items()})
        out.insert(0, "market", market)
        out["source_file"] = f.name
        frames.append(out)
    return frames


def keyword_suggest(rules):
    """키워드 규칙(product_vendor_map.csv) → 추천 발주처. 매칭표에 없는 새 옵션의 '추천'에만 쓰인다."""
    rules = rules.fillna("")
    rules["_p"] = pd.to_numeric(rules["priority"], errors="coerce").fillna(9999)
    rules = rules.sort_values("_p")

    def _f(df):
        text = (df["product_name"].fillna("") + " " + df["option"].fillna(""))
        out = pd.Series("", index=df.index)
        for _, r in rules.iterrows():
            if str(r["keyword"]).strip():
                out[(out == "") & text.str.contains(str(r["keyword"]), regex=False)] = r["vendor"]
        return out
    return _f


def main(date):
    markets = yaml.safe_load((ROOT / "config/markets.yaml").read_text(encoding="utf-8"))
    rules = pd.read_csv(ROOT / "config/product_vendor_map.csv", dtype=str, encoding="utf-8-sig")
    frames = []
    for m, cfg in markets.items():
        frames += load_market(date, m, cfg)
    if not frames:
        sys.exit(f"[알림] orders/{date}/원본/ 에 주문 파일이 없습니다.")
    df = pd.concat(frames, ignore_index=True)

    # 같은 주문번호+상품+옵션이 여러 파일에 중복되면 제거
    before = len(df)
    df = df.drop_duplicates(subset=["market", "order_no", "product_code", "option"])
    # 품목 매칭표(config/상품매칭.xlsx)로 품목코드 → 발주처(우선순위·품절 반영) 결정
    df, n_new = matching.apply(df.fillna(""), suggest=keyword_suggest(rules))
    df["qty_num"] = pd.to_numeric(df["qty"], errors="coerce")
    df["check"] = ""
    blocked = df["match_note"].isin(["매칭없음", "품명미매칭", "공급처없음", "전체품절(사용 N)"])
    df.loc[blocked, "check"] = df.loc[blocked, "match_note"]
    df.loc[(df["qty_num"].isna()) | (df["qty_num"] <= 0) | (df["qty_num"] > 50), "check"] += " 수량이상"
    df.loc[df["address"].fillna("").str.strip() == "", "check"] += " 주소누락"
    df["check"] = df["check"].str.strip()

    outdir = ROOT / "orders" / date / "분류"
    outdir.mkdir(parents=True, exist_ok=True)
    df.to_excel(outdir / "전체_분류결과.xlsx", index=False)
    bad = df[df["check"] != ""]
    bad.to_excel(outdir / "미분류.xlsx", index=False)

    print(f"[{date}] 총 {len(df)}건 (중복 제거 {before - len(df)}건)")
    ok_counts = df[df["check"] == ""].groupby("vendor").size()
    print(ok_counts.to_string() if len(ok_counts) else "  (발주 가능 건 없음)")
    alt = df[(df["check"] == "") & df["match_note"].str.startswith("대체공급")]
    if len(alt):
        print(f"대체공급(1순위 품절로 다른 업체): {len(alt)}건")
    print(f"확인 필요(매칭없음/품절/수량/주소): {len(bad)}건 → 분류/미분류.xlsx")
    for reason, n in bad["check"].value_counts().items():
        print(f"  - {reason}: {n}건")
    if n_new:
        print(f"신규 마켓 옵션 {n_new}건을 config/상품매칭.xlsx '마켓상품' 시트에 추가함")
    if bad["check"].str.contains("매칭없음|품명미매칭").any():
        print("→ 매칭이 필요한 상품: 매칭 화면(상품매칭 열기.cmd)에서 공급 상품 선택 후 다시 분류")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("사용법: python scripts/classify_orders.py YYYY-MM-DD")
    main(sys.argv[1])
