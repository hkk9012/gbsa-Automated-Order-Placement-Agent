"""업체별 발주 파일 교차 검증 — 작성된 파일을 원본 주문·분류 결과·매칭표·업체 상품목록과 다시 대조

사용: python scripts/verify_upload.py YYYY-MM-DD
출력: upload/{업체}/DATE/_검증.json, 화면 요약 (주문번호·항목명만, 고객 정보 값은 출력하지 않음)
"""
import hashlib
import json
import re
import sys
from pathlib import Path

import pandas as pd
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import matching as M  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
LEDGER = ROOT / "done" / "_발주완료목록.csv"
KEY = ["market", "order_no", "product_code", "option"]
PLACEHOLDER = re.compile(r"홍길동|김판매|xxxx|ex\)|사과구 포도대로|0000-0000")


def norm(v):
    s = "" if v is None or (isinstance(v, float) and pd.isna(v)) else str(v).strip()
    return s[:-2] if re.fullmatch(r"-?\d+\.0", s) else s


def raw_order_count(date, markets):
    n = 0
    for m, cfg in markets.items():
        folder = ROOT / "orders" / date / "원본" / cfg["folder"]
        for f in sorted(folder.glob("*")) if folder.exists() else []:
            if f.suffix.lower() in (".xlsx", ".xls", ".csv") and not f.name.startswith("~$"):
                df = pd.read_excel(f, header=cfg.get("header_row", 0), dtype=str) if f.suffix != ".csv" else pd.read_csv(f, dtype=str)
                oc = cfg["columns"]["order_no"]
                n += int(df[oc].notna().sum()) if oc in df.columns else 0
    return n


def verify(date):
    vcfg = yaml.safe_load((ROOT / "config/vendors.yaml").read_text(encoding="utf-8"))
    vendors, sender = vcfg["vendors"], vcfg.get("sender", {})
    markets = yaml.safe_load((ROOT / "config/markets.yaml").read_text(encoding="utf-8"))
    cls_path = ROOT / "orders" / date / "분류" / "전체_분류결과.xlsx"
    if not cls_path.exists():
        return {"global": ["분류 결과 없음 (주문 0건이거나 분류 미실행)"], "vendors": {}}
    cls = pd.read_excel(cls_path, dtype=str).fillna("")
    led = pd.read_csv(LEDGER, dtype=str, encoding="utf-8-sig").fillna("") if LEDGER.exists() else pd.DataFrame(columns=KEY)
    done_keys = set(map(tuple, led[KEY].values.tolist()))
    cat = M._cat_df()
    cstat = {(v, n): s for v, n, s in zip(cat["발주처"], cat["발주처품명"], cat["판매상태"])}
    res = {"global": [], "vendors": {}}

    # ① 원본 → 분류 누락 확인
    raw_n = raw_order_count(date, markets)
    res["raw_rows"], res["classified_rows"] = raw_n, len(cls)
    if raw_n < len(cls):
        res["global"].append(f"원본 주문행 {raw_n} < 분류 결과 {len(cls)} (중복 의심)")
    elif raw_n > len(cls):
        res["global"].append(f"원본 주문행 {raw_n}행 → 분류 {len(cls)}행 ({raw_n - len(cls)}행은 같은 주문이 여러 파일에 있어 중복 제거됨) — 확인 권장")
    ok_rows = cls[cls["check"] == ""]
    bad_rows = cls[cls["check"] != ""]

    # 이전 날짜 업로드 대기 파일(미완료)에 이미 있던 주문
    prev = {}
    for sj in (ROOT / "upload").glob("*/*/_요약.json"):
        if sj.parent.name >= date:
            continue
        s = json.loads(sj.read_text(encoding="utf-8"))
        for k in s.get("keys", []):
            prev[tuple(k)] = f"{s['vendor']} {s['date']}"

    accounted = set()
    for vendor, v in vendors.items():
        d = ROOT / "upload" / vendor / date
        sj = d / "_요약.json"
        exp = ok_rows[ok_rows["vendor"] == vendor]
        exp = exp[~exp[KEY].apply(tuple, axis=1).isin(done_keys)] if len(exp) else exp
        if not sj.exists():
            if len(exp):
                res["vendors"][vendor] = {"status": "오류", "issues": [f"발주 대상 {len(exp)}건인데 업체 파일이 없음"]}
            continue
        s = json.loads(sj.read_text(encoding="utf-8"))
        f = d / s["file"]
        issues, checks = [], 0
        # ② 파일 변조
        checks += 1
        if hashlib.sha256(f.read_bytes()).hexdigest() != s["sha256"]:
            issues.append("파일이 생성 후 변경됨 (지문 불일치)")
        hr = int(v.get("header_row", 1))
        out = pd.read_excel(f, header=hr - 1, dtype=str)
        out = out.dropna(how="all")
        inv = {}
        for h, src in v["columns"].items():
            inv.setdefault(src, h)
        oc = inv.get("order_no")
        # ③ 건수·주문번호
        checks += 2
        if len(out) != len(exp):
            issues.append(f"행 수 불일치: 파일 {len(out)} / 발주 대상 {len(exp)}")
        fo, eo = sorted(out[oc].map(norm)) if oc else [], sorted(exp["order_no"].map(norm))
        if oc and fo != eo:
            miss, extra = sorted(set(eo) - set(fo)), sorted(set(fo) - set(eo))
            issues.append(f"주문번호 불일치: 파일에 없음 {miss} / 대상 아님 {extra}")
        # ④ 줄별 대조 (주문번호+상품으로 짝지음)
        label_col = inv.get("vendor_product")
        exp_l = exp.assign(_k=exp["order_no"].map(norm) + "|" + exp["vendor_product"].map(norm)).sort_values("_k")
        out_l = out.assign(_k=(out[oc].map(norm) if oc else "") + "|" + (out[label_col].map(norm) if label_col else "")).sort_values("_k")
        fields = [("receiver_name", "수령인"), ("receiver_phone", "연락처"), ("address", "주소"), ("zip", "우편번호"),
                  ("qty", "수량"), ("vendor_code", "업체상품코드"), ("buyer_name", "주문자"), ("memo", "배송메모")]
        for (_, e), (_, o) in zip(exp_l.iterrows(), out_l.iterrows()):
            on = norm(e["order_no"])
            if label_col and norm(o[label_col]) != norm(e["vendor_product"]):
                issues.append(f"주문 {on}: 업체 상품명이 매칭표와 다름")
            for std, nm in fields:
                h = inv.get(std)
                if not h:
                    continue
                checks += 1
                ev, ov = norm(e.get(std, "")), norm(o.get(h, ""))
                if std == "qty":
                    try:
                        ok = int(float(ov)) == int(float(ev))
                    except ValueError:
                        ok = False
                    if not ok or not (0 < int(float(ov or 0)) <= 50):
                        issues.append(f"주문 {on}: 수량 불일치 또는 이상")
                elif ev != ov:
                    issues.append(f"주문 {on}: {nm} 불일치")
            # ⑤ 상품명이 업체 목록에 있고 판매중인지
            if label_col:
                st = cstat.get((vendor, norm(o[label_col])))
                checks += 1
                if st is None:
                    issues.append(f"주문 {on}: 업체 상품 목록에 없는 상품명")
                elif re.search(r"품절|중지|종료", st):
                    issues.append(f"주문 {on}: 업체 목록상 {st}")
            k = tuple(norm(e[c]) for c in KEY)
            accounted.add(k)
            # ⑥ 중복
            checks += 1
            if k in done_keys:
                issues.append(f"주문 {on}: 이미 발주 완료 장부에 있음")
            if k in prev:
                issues.append(f"주문 {on}: 이전 날짜 파일({prev[k]})에도 있었음 — 그때 발주했는지 확인 (완료 처리 안 됨)")
        # ⑦ 양식: 필수 칸, 예시 문구, 보내는 사람
        for h in out.columns:
            if str(h).startswith("[필수]"):
                checks += 1
                if out[h].isna().any() or (out[h].astype(str).str.strip() == "").any():
                    issues.append(f"필수 칸 '{h}'에 빈칸")
        checks += 1
        if out.astype(str).apply(lambda c: c.str.contains(PLACEHOLDER)).any().any():
            issues.append("양식 예시 문구가 남아 있음")
        for std in ("sender:name", "sender:phone", "sender:address"):
            h = inv.get(std)
            if h:
                checks += 1
                if (out[h].astype(str).str.strip().isin(["", "nan"])).any():
                    issues.append(f"보내는 사람 '{h}' 빈칸")
        status = "통과" if not issues else ("확인 필요" if all("이전 날짜" in i for i in issues) else "오류")
        res["vendors"][vendor] = {"status": status, "checks": checks, "issues": issues, "orders": s["orders"],
                                  "qty": s["qty_total"], "file": f"upload/{vendor}/{date}/{s['file']}"}
        (d / "_검증.json").write_text(json.dumps(res["vendors"][vendor], ensure_ascii=False, indent=1), encoding="utf-8")

    # ⑧ 모든 주문이 업체 파일 또는 제외 목록 중 한 곳에
    not_acc = [norm(r["order_no"]) for _, r in ok_rows.iterrows()
               if tuple(norm(r[c]) for c in KEY) not in accounted and tuple(norm(r[c]) for c in KEY) not in done_keys]
    if not_acc:
        res["global"].append(f"발주 대상인데 어느 업체 파일에도 없는 주문: {not_acc}")
    res["excluded"] = [{"order_no": norm(r["order_no"]), "market": r["market"], "product": f"{r['product_name']} / {r['option']}",
                        "reason": r["check"]} for _, r in bad_rows.iterrows()]
    return res


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("사용법: python scripts/verify_upload.py YYYY-MM-DD")
    r = verify(sys.argv[1])
    for g in r["global"]:
        print("⚠", g)
    for v, x in r["vendors"].items():
        print(f"[{v}] {x['status']} (검사 {x.get('checks', 0)}항목)" + "".join("\n   - " + i for i in x["issues"]))
    print(f"제외된 주문: {len(r.get('excluded', []))}건")
