"""품목 매칭표(config/상품매칭.xlsx) 읽기·적용·신규 등록.

구조 (3단):
  [마켓상품]   마켓 + 마켓옵션ID  →  품목코드          (쿠팡·토스의 같은 상품은 같은 품목코드)
  [품목]       품목코드 → 우리 품목명
  [공급처매칭] 품목코드 + 우선순위 → 발주처, 발주처품명, 발주처상품코드, 발주수량배수, 사용(Y/N)
               → 사용=Y 중 우선순위가 가장 작은 발주처로 발주. 품절이면 사용=N 으로 바꾸면 다음 순위로 자동 전환

수동 매칭(한 번만 사람이 고르면 이후 자동):
  python scripts/matching.py catalog       catalogs/{업체}/ 최신 상품목록 → '발주처상품' 시트 (+ 업체별 드롭다운 목록)
  python scripts/matching.py work          매칭이 필요한 마켓 옵션 → '매칭작업' 시트 (발주처·품명 드롭다운 + 비슷한 후보 5개)
      → 엑셀에서 '매칭작업' 시트 채우고 저장·닫기
  python scripts/matching.py apply         '매칭작업' 입력 내용을 마켓상품·품목·공급처매칭에 반영 (반영된 줄은 작업 시트에서 빠짐)

단독 실행:
  python scripts/matching.py init          매칭표가 없으면 빈 양식 생성
  python scripts/matching.py check         매칭표 점검 (품목코드 누락, 발주처 오타, 사용 가능한 공급처 없는 품목)
"""
import difflib
import re
import sys
from datetime import date
from pathlib import Path

import pandas as pd
import yaml
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation

ROOT = Path(__file__).resolve().parent.parent
BOOK = Path(__import__("os").environ.get("MATCH_BOOK") or ROOT / "config" / "상품매칭.xlsx")  # MATCH_BOOK: 시험용 복사본 지정

S_MARKET, S_ITEM, S_SUPPLY, S_HELP = "마켓상품", "품목", "공급처매칭", "사용법"
S_CAT, S_WORK, S_REF = "발주처상품", "매칭작업", "[가림]매핑참고"
C_REF = ["마켓", "마켓옵션ID", "노출상품명", "옵션명", "[가림]활성화", "[가림]매핑상품", "[가림]공급가", "읽은날"]
CAT_DIR = ROOT / "catalogs"
C_CAT = ["발주처", "발주처품명", "발주처상품코드", "공급가", "판매상태", "발주마감", "목록일"]
C_WORK = ["마켓", "마켓옵션ID", "마켓상품명", "마켓옵션명", "품목코드",
          "1순위 발주처", "1순위 발주처품명", "후보선택(1~5)", "1순위 배수",
          "2순위 발주처", "2순위 발주처품명", "2순위 배수",
          "후보1", "후보2", "후보3", "후보4", "후보5", "상태"]
C_MARKET = ["마켓", "마켓옵션ID", "마켓상품명", "마켓옵션명", "품목코드", "비고", "등록일",
            "노출상품명", "판매가", "정상가", "재고", "판매상태", "상품ID", "가져온날"]
C_ITEM = ["품목코드", "품목명", "메모"]
# 공급가 = 매칭(또는 기준가 확정) 당시 공급가 = '기준 공급가'. 현재공급가·공급상태·점검일은 공급상품 점검(monitor)이 채움
C_SUPPLY = ["품목코드", "우선순위", "발주처", "발주처품명", "발주처상품코드", "발주수량배수", "공급가", "사용", "품절·변경메모", "변경일",
            "현재공급가", "공급상태", "점검일"]
S_ALERT = "공급변동알림"
C_ALERT = ["점검일", "유형", "마켓", "마켓옵션ID", "판매상품명", "옵션명", "품목코드", "우선순위", "발주처", "발주처품명",
           "기준공급가", "현재공급가", "공급가변동(배수반영)", "현재판매가", "제안판매가", "현재마진", "처리", "처리일"]
BAD_SUPPLY = re.compile(r"품절|중지|종료|목록에없음")
HELP = [
    "■ 품목 매칭표 사용법",
    "",
    "★ 새 상품 매칭은 '매칭작업' 시트에서 (한 번만 직접 고르면 이후 자동)",
    "   ① 노란 칸: 1순위 발주처(드롭다운) → 1순위 발주처품명(그 업체 상품목록 드롭다운에서 선택)",
    "      또는 오른쪽 후보1~5 중 맞는 것이 있으면 '후보선택'에 번호만 입력",
    "   ② 묶음이면 배수 입력(마켓 1개 = 업체 몇 개). 대체 업체가 있으면 2순위도 입력",
    "   ③ 저장하고 엑셀을 닫은 뒤 Claude에게 '매칭 반영' 요청 (python scripts/matching.py apply)",
    "   ※ '발주처상품' 시트 = 업체 상품목록 (python scripts/matching.py catalog 로 갱신). [가림]은 판매상태가 품절이면 자동으로 2순위로 발주",
    "",
    "1) 마켓상품: 쿠팡·토스 옵션 하나 = 한 줄. 새 옵션이 주문되면 분류 단계에서 자동으로 줄이 추가됩니다(품목코드 빈칸, 비고에 추천 발주처).",
    "   → 품목코드 칸만 채우면 됩니다. 쿠팡과 토스의 같은 상품은 같은 품목코드를 넣으세요.",
    "2) 품목: 품목코드별 우리 품목명 (예: P0001 = [가림] 진공 굴비 1호 20미).",
    "3) 공급처매칭: 품목코드마다 발주처를 우선순위로 여러 줄 등록.",
    "   - 발주처품명: 그 업체 발주 양식에 넣을 '업체 쪽' 상품명/옵션명 (업체 상품목록 표기 그대로). 비우면 마켓 상품명+옵션이 들어갑니다.",
    "   - 발주처상품코드: 업체 상품코드가 있으면 입력 ([가림] '상품코드' 칸 등).",
    "   - 발주수량배수: 마켓 1개 = 업체 몇 개인지 (보통 1, 2개 묶음 상품이면 2).",
    "   - 사용: Y = 발주 대상, N = 품절/중단. 1순위를 N 으로 바꾸면 다음 날부터 2순위 업체로 자동 발주됩니다.",
    "4) 발주처 이름은 config/vendors.yaml 의 업체명과 똑같이 ([가림], [가림], [가림], [가림]).",
    "5) 이 파일을 엑셀로 열어 둔 채로 분류를 돌리면 저장이 안 됩니다 → 편집 후 닫아 주세요.",
]


def vendor_names():
    return list(yaml.safe_load((ROOT / "config/vendors.yaml").read_text(encoding="utf-8"))["vendors"].keys())


def _sheet(wb, title, cols, widths):
    ws = wb.create_sheet(title)
    ws.append(cols)
    for i, c in enumerate(ws[1], 1):
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="2F5597")
        c.alignment = Alignment(horizontal="center")
        ws.column_dimensions[c.column_letter].width = widths[i - 1]
    ws.freeze_panes = "A2"
    return ws


def init_book():
    """빈 매칭표 생성 (이미 있으면 그대로 둠)."""
    if BOOK.exists():
        return False
    wb = Workbook()
    wb.remove(wb.active)
    _sheet(wb, S_MARKET, C_MARKET, [9, 18, 40, 30, 11, 30, 12])
    _sheet(wb, S_ITEM, C_ITEM, [11, 40, 30])
    ws = _sheet(wb, S_SUPPLY, C_SUPPLY, [11, 9, 11, 40, 15, 12, 10, 6, 30, 12])
    dv_v = DataValidation(type="list", formula1='"' + ",".join(vendor_names()) + '"', allow_blank=True)
    dv_yn = DataValidation(type="list", formula1='"Y,N"', allow_blank=True)
    ws.add_data_validation(dv_v); ws.add_data_validation(dv_yn)
    dv_v.add("C2:C2000"); dv_yn.add("H2:H2000")
    h = wb.create_sheet(S_HELP)
    for line in HELP:
        h.append([line])
    h.column_dimensions["A"].width = 130
    wb.move_sheet(S_HELP, offset=-3)
    wb.save(BOOK)
    return True


def _read(sheet, cols):
    df = pd.read_excel(BOOK, sheet_name=sheet, dtype=str).fillna("")
    for c in cols:
        if c not in df.columns:
            df[c] = ""
    return df[cols].apply(lambda s: s.str.strip())


def ensure_headers():
    """예전 매칭표에 새 열 머리글이 없으면 뒤에 추가."""
    wb = load_workbook(BOOK)
    changed = False
    for name, cols in ((S_MARKET, C_MARKET), (S_SUPPLY, C_SUPPLY)):
        ws = wb[name]
        have = [c.value for c in ws[1]]
        for col in cols:
            if col not in have:
                c = ws.cell(1, len(have) + 1, col)
                c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="2F5597")
                have.append(col); changed = True
    if changed:
        wb.save(BOOK)


def load():
    init_book()
    ensure_headers()
    return _read(S_MARKET, C_MARKET), _read(S_ITEM, C_ITEM), _read(S_SUPPLY, C_SUPPLY)


def _hdr(ws):
    return {c.value: i for i, c in enumerate(ws[1])}


def soldout_set():
    """'발주처상품' 시트(업체 상품목록)에서 품절·판매중지로 표시된 (발주처, 발주처품명)."""
    try:
        cat = pd.read_excel(BOOK, sheet_name=S_CAT, dtype=str).fillna("")
    except ValueError:
        return set()
    bad = cat[cat["판매상태"].str.contains("품절|중지|종료", regex=True)]
    return set(zip(bad["발주처"], bad["발주처품명"]))


def pick_supplier(supply, sku, soldout=frozenset()):
    """사용=Y 이고 업체 목록상 품절이 아닌 것 중 우선순위 최소 발주처. 없으면 None."""
    s = supply[(supply["품목코드"] == sku) & (supply["사용"].str.upper() == "Y") & (supply["발주처"] != "")]
    if "공급상태" in s.columns:  # 공급상품 점검에서 품절·목록에없음으로 확인된 것은 제외
        s = s[~s["공급상태"].str.contains(BAD_SUPPLY)]
    if soldout:
        s = s[[(v, n) not in soldout for v, n in zip(s["발주처"], s["발주처품명"])]]
    if s.empty:
        return None, int((supply["품목코드"] == sku).sum())
    s = s.assign(_p=pd.to_numeric(s["우선순위"], errors="coerce").fillna(999)).sort_values("_p")
    return s.iloc[0], int((supply["품목코드"] == sku).sum())


def apply(df, suggest=None):
    """주문 표준 DataFrame 에 매칭 결과 컬럼을 붙인다.

    추가 컬럼: sku, item_name, vendor, vendor_product, vendor_code, market_qty, qty(=발주수량), supply_rank, match_note
    suggest(df) → 추천 발주처 Series (키워드 규칙). 매칭표에 없는 옵션 신규 등록 시 비고에 사용.
    """
    market, item, supply = load()
    item_name = dict(zip(item["품목코드"], item["품목명"]))
    by_id = {(r["마켓"], r["마켓옵션ID"]): r["품목코드"] for _, r in market.iterrows() if r["마켓옵션ID"]}
    by_name = {(r["마켓"], r["마켓상품명"], r["마켓옵션명"]): r["품목코드"] for _, r in market.iterrows()}
    known_ids = {(r["마켓"], r["마켓옵션ID"]) for _, r in market.iterrows() if r["마켓옵션ID"]}
    known_names = set(by_name.keys())

    rec = suggest(df) if suggest else pd.Series("", index=df.index)
    soldout = soldout_set()
    out = {k: [] for k in ["sku", "item_name", "vendor", "vendor_product", "vendor_code", "market_qty", "qty", "supply_rank", "match_note"]}
    new_rows = []
    for idx, r in df.iterrows():
        key_id, key_nm = (r["market"], str(r["product_code"]).strip()), (r["market"], r["product_name"], r["option"])
        sku = by_id.get(key_id) or by_name.get(key_nm) or ""
        mq = r["qty"]
        v = vp = vc = rank = note = ""
        q = mq
        if not sku:
            note = "매칭없음"
            if key_id not in known_ids and key_nm not in known_names:
                new_rows.append([r["market"], key_id[1], r["product_name"], r["option"], "",
                                 f"추천: {rec.get(idx, '')}" if rec.get(idx, "") else "", date.today().isoformat()])
                known_ids.add(key_id); known_names.add(key_nm)
        else:
            sup, n_all = pick_supplier(supply, sku, soldout)
            if sup is None:
                note = "공급처없음" if n_all == 0 else "전체품절(사용 N)"
            elif not str(sup["발주처품명"]).strip():
                note = "품명미매칭"   # 업체 품명을 한 번도 고르지 않은 품목 → 발주 제외, '매칭작업'에서 선택
                v = sup["발주처"]
            else:
                v, vp, vc, rank = sup["발주처"], sup["발주처품명"], sup["발주처상품코드"], sup["우선순위"]
                mult = pd.to_numeric(sup["발주수량배수"], errors="coerce")
                try:
                    q = str(int(float(mq) * (1 if pd.isna(mult) or mult <= 0 else mult)))
                except ValueError:
                    q = mq
                first = supply[(supply["품목코드"] == sku)].assign(_p=lambda x: pd.to_numeric(x["우선순위"], errors="coerce").fillna(999)).sort_values("_p").iloc[0]
                if (first["발주처"], first["발주처품명"]) != (v, vp):
                    why = "업체목록 품절" if (first["발주처"], first["발주처품명"]) in soldout else "사용 N"
                    note = f"대체공급({rank}순위, 1순위 {first['발주처']} {why})"
        for k, val in zip(out, [sku, item_name.get(sku, ""), v, vp, vc, mq, q, rank, note]):
            out[k].append(val)
    res = df.copy()
    for k, vals in out.items():
        res[k] = vals
    if new_rows:
        add_market_rows(new_rows)
    return res, len(new_rows)


def add_market_rows(rows):
    try:
        wb = load_workbook(BOOK)
        ws = wb[S_MARKET]
        for row in rows:
            ws.append(row)
        wb.save(BOOK)
    except PermissionError:
        print(f"[경고] {BOOK.name} 이(가) 엑셀에서 열려 있어 신규 옵션 {len(rows)}건을 등록하지 못했습니다. 닫고 다시 실행하세요.")


def check():
    market, item, supply = load()
    vend = set(vendor_names())
    probs = []
    for _, r in market[market["품목코드"] == ""].iterrows():
        probs.append(f"[마켓상품] 품목코드 없음: {r['마켓']} {r['마켓상품명']} / {r['마켓옵션명']} ({r['비고']})")
    for sku in sorted(set(market["품목코드"]) - {""} - set(item["품목코드"])):
        probs.append(f"[품목] 품목 시트에 없는 품목코드: {sku}")
    for _, r in supply[(supply["발주처"] != "") & (~supply["발주처"].isin(vend))].iterrows():
        probs.append(f"[공급처매칭] 등록 안 된 발주처명: {r['품목코드']} → '{r['발주처']}' (가능: {', '.join(sorted(vend))})")
    for sku in sorted(set(market["품목코드"]) - {""}):
        sup, n = pick_supplier(supply, sku)
        if sup is None:
            probs.append(f"[공급처매칭] 발주 가능한 공급처 없음: {sku} ({'등록 없음' if n == 0 else '모두 사용 N'})")
        elif not sup["발주처품명"]:
            probs.append(f"[공급처매칭] 발주처품명 비어 있음(마켓 상품명으로 대체됨): {sku} → {sup['발주처']}")
    print("\n".join(probs) if probs else "문제 없음")
    return probs


# ───────────────────────── 업체 상품목록 (카탈로그) ─────────────────────────
def _latest(vendor):
    fs = sorted((CAT_DIR / vendor).glob("*.xls*"), key=lambda p: p.stat().st_mtime) if (CAT_DIR / vendor).exists() else []
    return fs[-1] if fs else None


def read_catalog(vendor, path):
    """업체 상품목록 엑셀 → 표준 컬럼(C_CAT). 헤더 이름으로 형식을 판별."""
    d = pd.read_excel(path, dtype=str).fillna("")
    d.columns = [str(c).strip() for c in d.columns]
    g = lambda c: d[c].str.strip() if c in d.columns else pd.Series("", index=d.index)
    if "그룹명" in d.columns and "현재가" in d.columns:          # [가림] '전체 데이터 엑셀'
        name, code = g("옵션명"), pd.Series("", index=d.index)
        price = g("이벤트가").where(g("이벤트가") != "", g("현재가"))
        status, deadline = pd.Series("", index=d.index), pd.Series("", index=d.index)
    elif "판매상태" in d.columns:                                 # [가림] '상품 엑셀'
        # 옵션명만으로는 상품을 알 수 없는 경우가 있어(예: '햇 2kg / 상') 상품명을 앞에 붙여 고유하게
        nm, op = g("상품명"), g("옵션명")
        name = pd.Series([o if (not o or n in o) and o else (f"{n} / {o}" if o else n) for n, o in zip(nm, op)], index=d.index)
        code, price, status, deadline = g("관리코드"), g("공급가"), g("판매상태"), g("발주마감시간")
    else:                                                          # adminplus ([가림]·[가림]) '전체제품 엑셀'
        name = g("상품명").where(g("옵션명") == "", g("상품명") + " / " + g("옵션명"))
        code, price, status, deadline = g("상품코드"), g("공급가"), pd.Series("", index=d.index), g("발주마감시간")
    out = pd.DataFrame({"발주처": vendor, "발주처품명": name, "발주처상품코드": code, "공급가": price,
                        "판매상태": status, "발주마감": deadline,
                        "목록일": date.fromtimestamp(path.stat().st_mtime).isoformat()})
    return out[out["발주처품명"] != ""].drop_duplicates(subset=["발주처품명"])


def catalog_cmd():
    """catalogs/ 최신 목록으로 '발주처상품' 시트를 다시 쓰고 업체별 드롭다운 이름(목록_업체)을 만든다."""
    from openpyxl.workbook.defined_name import DefinedName
    init_book()
    frames = []
    for v in vendor_names():
        p = _latest(v)
        if p is None:
            print(f"[건너뜀] {v}: catalogs/{v}/ 에 상품목록 없음")
            continue
        c = read_catalog(v, p)
        frames.append(c)
        print(f"[{v}] {len(c)}개 ← {p.relative_to(ROOT)}" + (f" (품절·중지 {int(c['판매상태'].str.contains('품절|중지|종료').sum())}개)" if c["판매상태"].any() else ""))
    if not frames:
        return
    cat = pd.concat(frames, ignore_index=True)
    wb = load_workbook(BOOK)
    if S_CAT in wb.sheetnames:
        del wb[S_CAT]
    ws = wb.create_sheet(S_CAT)
    ws.append(C_CAT)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="548235")
    for w, col in zip([10, 55, 32, 10, 10, 14, 12], "ABCDEFG"):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:G{len(cat) + 1}"
    for name in [n for n in list(wb.defined_names) if str(n).startswith("목록_")]:
        del wb.defined_names[name]
    r = 2
    for v, g in cat.groupby("발주처", sort=False):
        start = r
        for row in g[C_CAT].values.tolist():
            ws.append(row); r += 1
        wb.defined_names[f"목록_{v}"] = DefinedName(f"목록_{v}", attr_text=f"'{S_CAT}'!$B${start}:$B${r - 1}")
    wb.save(BOOK)
    print(f"'{S_CAT}' 시트 갱신: 총 {len(cat)}개")


# ───────────────────────── 수동 매칭 작업 시트 ─────────────────────────
_NUM = re.compile(r"\d+(?:\.\d+)?\s*(?:kg|g|미|과|입|개|팩|박스|L|ml|cm)?", re.I)


def _norm(s, vendor=""):
    s = str(s)
    for v in vendor_names():
        s = s.replace(v, "")
    s = re.sub(r"[\(\)\[\]/·,\-_]", " ", s)
    return re.sub(r"\s+", "", s).lower()


_STOP = re.compile(r"국내산|국산|1박스|박스|가정용|선물용|산지직송|무료배송")


def _bigrams(s):
    s = _norm(_STOP.sub("", str(s)))
    s = re.sub(r"\d+(?:\.\d+)?", "", s)  # 숫자는 따로 비교
    return {s[i:i + 2] for i in range(len(s) - 1)} or {s}


def _nums(s):
    return set(m.replace(" ", "").lower() for m in _NUM.findall(str(s)))


def candidates(text, cat, k=5):
    """마켓 상품명+옵션과 비슷한 업체 상품 k개.
    점수 = 글자쌍(2글자) 포함률 0.55 + 숫자·단위 일치 0.30 + 전체 유사도 0.15"""
    if cat.empty:
        return []
    tb, tn, t = _bigrams(text), _nums(text), _norm(text)
    # 1차: 글자쌍 겹침으로 30개로 좁힘 (빠름) → 2차: 정밀 점수
    if len(cat) > 30:
        pre = [len(tb & _bigrams(n)) for n in cat["발주처품명"]]
        cat = cat.assign(_pre=pre).sort_values("_pre", ascending=False).head(30)
    scores = []
    for n in cat["발주처품명"]:
        nb, nn = _bigrams(n), _nums(n)
        s = 0.55 * len(tb & nb) / max(len(tb), 1)
        s += 0.30 * (len(tn & nn) / len(tn) if tn else 0)
        s += 0.15 * difflib.SequenceMatcher(None, t, _norm(n)).ratio()
        scores.append(s)
    top = cat.assign(_s=scores).sort_values("_s", ascending=False).head(k)
    return [f"{v} | {n}" for v, n in zip(top["발주처"], top["발주처품명"])]


def _cat_df():
    try:
        return pd.read_excel(BOOK, sheet_name=S_CAT, dtype=str).fillna("")
    except ValueError:
        return pd.DataFrame(columns=C_CAT)


def work_cmd():
    """매칭이 필요한 마켓 옵션을 '매칭작업' 시트로 (드롭다운·후보 포함)."""
    market, item, supply = load()
    cat = _cat_df()
    vend = vendor_names()
    rows = []
    for _, m in market.iterrows():
        sku = m["품목코드"]
        sup = supply[supply["품목코드"] == sku].assign(_p=lambda x: pd.to_numeric(x["우선순위"], errors="coerce").fillna(999)).sort_values("_p") if sku else supply.iloc[0:0]
        s1 = sup.iloc[0] if len(sup) else None
        s2 = sup.iloc[1] if len(sup) > 1 else None
        if sku and s1 is not None and s1["발주처"] and s1["발주처품명"]:
            continue  # 이미 매칭 완료
        v1 = s1["발주처"] if s1 is not None and s1["발주처"] else next((v for v in vend if v in m["비고"] or m["마켓상품명"].startswith(v)), "")
        text = f"{m['마켓상품명']} {m['마켓옵션명']}"
        cands = candidates(text, cat[cat["발주처"] == v1] if v1 else cat)
        rows.append([m["마켓"], m["마켓옵션ID"], m["마켓상품명"], m["마켓옵션명"], sku,
                     v1, "", "", (s1["발주수량배수"] if s1 is not None and s1["발주수량배수"] else 1),
                     s2["발주처"] if s2 is not None else "", s2["발주처품명"] if s2 is not None else "",
                     (s2["발주수량배수"] if s2 is not None and s2["발주수량배수"] else ""),
                     *(cands + [""] * (5 - len(cands))), ""])
    wb = load_workbook(BOOK)
    if S_WORK in wb.sheetnames:
        del wb[S_WORK]
    ws = wb.create_sheet(S_WORK, 1)
    ws.append(C_WORK)
    fills = {"input": PatternFill("solid", fgColor="FFF2CC"), "head": PatternFill("solid", fgColor="C00000")}
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = fills["head"]; c.alignment = Alignment(wrap_text=True, vertical="center")
    for w, col in zip([8, 14, 30, 24, 9, 11, 42, 9, 7, 11, 42, 7, 40, 40, 40, 40, 40, 30], "ABCDEFGHIJKLMNOPQR"):
        ws.column_dimensions[col].width = w
    ws.row_dimensions[1].height = 32
    ws.freeze_panes = "F2"
    for r in rows:
        ws.append(r)
    n = max(len(rows) + 1, 2) + 200
    for i in range(2, len(rows) + 2):
        for col in "FGHIJKL":
            ws[f"{col}{i}"].fill = fills["input"]
    dv_v = DataValidation(type="list", formula1='"' + ",".join(vend) + '"', allow_blank=True)
    dv_p1 = DataValidation(type="list", formula1='INDIRECT("목록_"&$F2)', allow_blank=True, errorStyle="warning",
                           error="업체 상품목록에 없는 이름입니다. 그래도 쓰려면 '예'.", errorTitle="목록에 없음")
    dv_p2 = DataValidation(type="list", formula1='INDIRECT("목록_"&$J2)', allow_blank=True, errorStyle="warning",
                           error="업체 상품목록에 없는 이름입니다. 그래도 쓰려면 '예'.", errorTitle="목록에 없음")
    dv_n = DataValidation(type="list", formula1='"1,2,3,4,5"', allow_blank=True)
    for dv in (dv_v, dv_p1, dv_p2, dv_n):
        ws.add_data_validation(dv)
    dv_v.add(f"F2:F{n}"); dv_v.add(f"J2:J{n}"); dv_p1.add(f"G2:G{n}"); dv_p2.add(f"K2:K{n}"); dv_n.add(f"H2:H{n}")
    wb.save(BOOK)
    print(f"'{S_WORK}' 시트: 매칭 필요 {len(rows)}건 → config/상품매칭.xlsx 를 열어 노란 칸 입력 후 저장·닫고 'apply' 실행")
    return len(rows)


def apply_cmd():
    """'매칭작업' 시트 입력 → 마켓상품·품목·공급처매칭 반영."""
    work = pd.read_excel(BOOK, sheet_name=S_WORK, dtype=str).fillna("")
    cat = _cat_df()
    catmap = {(v, n): (c, p) for v, n, c, p in zip(cat["발주처"], cat["발주처품명"], cat["발주처상품코드"], cat["공급가"])}
    vend = set(vendor_names())
    wb = load_workbook(BOOK)
    wm, wi, wsu = wb[S_MARKET], wb[S_ITEM], wb[S_SUPPLY]
    hm = {c.value: i for i, c in enumerate(wm[1])}
    hs = {c.value: i for i, c in enumerate(wsu[1])}
    used = [str(r[0].value) for r in wi.iter_rows(min_row=2) if r[0].value] + [str(r[hm["품목코드"]].value) for r in wm.iter_rows(min_row=2) if r[hm["품목코드"]].value]
    nxt = max([int(x[1:]) for x in used if re.fullmatch(r"P\d+", x)] + [0]) + 1
    today = date.today().isoformat()
    done, keep, msgs = 0, [], []

    def set_supply(sku, rank, vendor, pname, mult):
        code, price = catmap.get((vendor, pname), ("", ""))
        vals = {"품목코드": sku, "우선순위": rank, "발주처": vendor, "발주처품명": pname, "발주처상품코드": code,
                "발주수량배수": int(float(mult)) if str(mult).strip() else 1, "공급가": price, "사용": "Y", "변경일": today}
        for r in wsu.iter_rows(min_row=2):
            if str(r[hs["품목코드"]].value) == sku and str(r[hs["우선순위"]].value) == str(rank):
                for k, v in vals.items():
                    r[hs[k]].value = v
                return code
        wsu.append([vals.get(c, "") for c in C_SUPPLY])
        return code

    for _, w in work.iterrows():
        v1, p1 = w["1순위 발주처"].strip(), w["1순위 발주처품명"].strip()
        pick = w["후보선택(1~5)"].strip()
        if not p1 and pick in list("12345"):
            cand = w[f"후보{pick}"]
            if " | " in cand:
                cv, p1 = cand.split(" | ", 1)
                v1 = v1 or cv
        if not (v1 and p1):
            keep.append(w); continue
        if v1 not in vend:
            msgs.append(f"[보류] {w['마켓상품명']} / {w['마켓옵션명']}: 발주처 '{v1}' 이(가) vendors.yaml 에 없음")
            keep.append(w); continue
        sku = w["품목코드"].strip()
        if not sku:
            sku = f"P{nxt:04d}"; nxt += 1
            prefix_re = "^(" + "|".join(vend) + r")\s*"
            name = (re.sub(prefix_re, "", w["마켓상품명"].strip()) + " " + w["마켓옵션명"]).strip()
            wi.append([sku, name, ""])
        for r in wm.iter_rows(min_row=2):
            if str(r[hm["마켓"]].value) == w["마켓"] and str(r[hm["마켓옵션ID"]].value or "") == w["마켓옵션ID"] \
                    and str(r[hm["마켓상품명"]].value) == w["마켓상품명"] and str(r[hm["마켓옵션명"]].value or "") == w["마켓옵션명"]:
                r[hm["품목코드"]].value = sku
        code = set_supply(sku, 1, v1, p1, w["1순위 배수"])
        note = "" if (v1, p1) in catmap else "  ⚠ 업체 상품목록에 없는 품명"
        v2, p2 = w["2순위 발주처"].strip(), w["2순위 발주처품명"].strip()
        if v2 and p2 and v2 in vend:
            set_supply(sku, 2, v2, p2, w["2순위 배수"])
            note += f"  (2순위 {v2} | {p2})"
        msgs.append(f"[반영] {w['마켓상품명']} / {w['마켓옵션명']} → {sku} : {v1} | {p1}{' [' + code + ']' if code else ''}{note}")
        done += 1

    # 작업 시트에는 남은 줄만 유지
    ws = wb[S_WORK]
    ws.delete_rows(2, ws.max_row)
    for w in keep:
        ws.append([w[c] for c in C_WORK])
    wb.save(BOOK)
    print("\n".join(msgs) if msgs else "입력된 매칭 없음")
    print(f"반영 {done}건 / 남은 작업 {len(keep)}건")


# ───────────────────────── [가림] 파트너스 매핑(참고용) 가져오기 ─────────────────────────
def import_[가림]_ref(json_path):
    """read_[가림]_mapping.js 가 출력한 표(JSON) → '[가림]매핑참고' 시트 + 마켓상품에 없는 쿠팡 옵션 등록(품목코드 비움).
    [가림] 매핑을 우리 매칭으로 자동 적용하지 않는다(참고 표시만)."""
    import json
    rows = json.loads(Path(json_path).read_text(encoding="utf-8"))
    today = date.today().isoformat()
    ref = []
    for r in rows:
        t = [c["t"] for c in r]
        mapped = t[6]
        price = re.sub(r"[^\d]", "", t[7]) if len(t) > 7 else ""
        ref.append(["coupang", t[2], t[1], t[3], t[4], mapped.split(" | ")[0] if mapped not in ("", "-") else "", price, today])
    wb = load_workbook(BOOK)
    if S_REF in wb.sheetnames:
        del wb[S_REF]
    ws = wb.create_sheet(S_REF)
    ws.append(C_REF)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="7F7F7F")
    for w, col in zip([9, 14, 45, 22, 10, 50, 10, 12], "ABCDEFGH"):
        ws.column_dimensions[col].width = w
    for r in ref:
        ws.append(r)
    wm = wb[S_MARKET]
    hm = {c.value: i for i, c in enumerate(wm[1])}
    have = {(str(r[hm["마켓"]].value), str(r[hm["마켓옵션ID"]].value)) for r in wm.iter_rows(min_row=2)}
    added = 0
    for r in ref:
        if (r[0], r[1]) not in have:
            wm.append([r[0], r[1], r[2], r[3], "", "[가림] 매핑 목록에서 가져옴", today]); added += 1
    wb.save(BOOK)
    print(f"'{S_REF}' {len(ref)}건 저장, 마켓상품 신규 옵션 {added}건 추가(품목코드 비움)")


# ───────────────────────── 매칭 화면(matching_app.py)용 저장 ─────────────────────────
def save_mapping(entries):
    """entries: [{market, optionId, productName, optionName,
                  suppliers:[{rank, vendor, vendorProduct, mult, use}]}]
    마켓 옵션 1개의 공급처 목록을 통째로 교체 저장. 반환: 메시지 목록"""
    cat = _cat_df()
    catmap = {(v, n): (c, p) for v, n, c, p in zip(cat["발주처"], cat["발주처품명"], cat["발주처상품코드"], cat["공급가"])}
    vend = set(vendor_names())
    wb = load_workbook(BOOK)
    wm, wi, wsu = wb[S_MARKET], wb[S_ITEM], wb[S_SUPPLY]
    hm = {c.value: i for i, c in enumerate(wm[1])}
    hs = {c.value: i for i, c in enumerate(wsu[1])}
    used = [str(r[0].value) for r in wi.iter_rows(min_row=2) if r[0].value] + \
           [str(r[hm["품목코드"]].value) for r in wm.iter_rows(min_row=2) if r[hm["품목코드"]].value]
    nxt = max([int(x[1:]) for x in used if re.fullmatch(r"P\d+", x)] + [0]) + 1
    today = date.today().isoformat()
    msgs = []
    prefix_re = "^(" + "|".join(vend) + r")\s*"
    for e in entries:
        mk, oid = str(e["market"]), str(e["optionId"])
        row = next((r for r in wm.iter_rows(min_row=2)
                    if str(r[hm["마켓"]].value) == mk and str(r[hm["마켓옵션ID"]].value) == oid), None)
        if row is None:
            wm.append([mk, oid, e.get("productName", ""), e.get("optionName", ""), "", "매칭 화면에서 등록", today])
            row = list(wm.iter_rows(min_row=wm.max_row, max_row=wm.max_row))[0]
        sku = str(row[hm["품목코드"]].value or "").strip()
        sups = [s for s in e.get("suppliers", []) if s.get("vendor") and s.get("vendorProduct")]
        bad = [s["vendor"] for s in sups if s["vendor"] not in vend]
        if bad:
            msgs.append(f"[보류] {oid}: 등록 안 된 발주처 {bad}"); continue
        if not sku:
            if not sups:
                continue
            sku = f"P{nxt:04d}"; nxt += 1
            row[hm["품목코드"]].value = sku
            wi.append([sku, (re.sub(prefix_re, "", str(row[hm["마켓상품명"]].value or "").strip()) + " " + str(row[hm["마켓옵션명"]].value or "")).strip(), ""])
        # 이 품목의 기존 공급처 줄 삭제 후 새로 기록 (뒤에서부터 삭제)
        for i in range(wsu.max_row, 1, -1):
            if str(wsu.cell(i, hs["품목코드"] + 1).value) == sku:
                wsu.delete_rows(i)
        for s in sorted(sups, key=lambda x: int(x.get("rank", 9))):
            code, price = catmap.get((s["vendor"], s["vendorProduct"]), ("", ""))
            mult = int(float(s.get("mult") or 1))
            wsu.append([sku, int(s.get("rank", 1)), s["vendor"], s["vendorProduct"], code, mult, price,
                        "Y" if s.get("use", True) else "N", s.get("memo", ""), today])
        msgs.append(f"[저장] {mk} {oid} → {sku} : " + " / ".join(f"{s['rank']}순위 {s['vendor']} | {s['vendorProduct']}{' ×' + str(s.get('mult')) if str(s.get('mult', 1)) not in ('1', '') else ''}{'' if s.get('use', True) else ' (사용N)'}" for s in sups) if sups else f"[저장] {mk} {oid} → {sku} : 공급처 없음")
    wb.save(BOOK)
    return msgs


def app_data():
    """매칭 화면에 보낼 데이터 (상품 정보만, 개인정보 없음)."""
    market, item, supply = load()
    cat = _cat_df()
    try:
        ref = pd.read_excel(BOOK, sheet_name=S_REF, dtype=str).fillna("")
    except ValueError:
        ref = pd.DataFrame(columns=C_REF)
    refmap = {(r["마켓"], r["마켓옵션ID"]): r for _, r in ref.iterrows()}
    rows = []
    for _, m in market.iterrows():
        sku = m["품목코드"]
        sup = supply[supply["품목코드"] == sku] if sku else supply.iloc[0:0]
        sups = [{"rank": int(float(s["우선순위"] or 9)), "vendor": s["발주처"], "vendorProduct": s["발주처품명"],
                 "mult": s["발주수량배수"] or "1", "use": s["사용"].upper() != "N", "memo": s["품절·변경메모"],
                 "basePrice": s["공급가"], "curPrice": s["현재공급가"], "supplyStatus": s["공급상태"], "checked": s["점검일"]}
                for _, s in sup.iterrows()]
        rf = refmap.get((m["마켓"], m["마켓옵션ID"]))
        rows.append({"market": m["마켓"], "optionId": m["마켓옵션ID"], "productName": m["마켓상품명"], "optionName": m["마켓옵션명"],
                     "sku": sku, "suppliers": sorted(sups, key=lambda x: x["rank"]), "note": m["비고"],
                     "displayName": rf["노출상품명"] if rf is not None else "",
                     "[가림]Ref": (f"{rf['[가림]매핑상품']} | {int(rf['[가림]공급가']):,}원" if rf is not None and rf["[가림]매핑상품"] and rf["[가림]공급가"] else (rf["[가림]매핑상품"] if rf is not None else "")),
                     "[가림]Active": rf["[가림]활성화"] if rf is not None else "",
                     "price": m["판매가"], "listPrice": m["정상가"], "stock": m["재고"], "saleStatus": m["판매상태"],
                     "fetched": m["가져온날"]})
    catalog = [{"v": r["발주처"], "n": r["발주처품명"], "p": r["공급가"], "s": r["판매상태"]} for _, r in cat.iterrows()]
    try:
        al = pd.read_excel(BOOK, sheet_name=S_ALERT, dtype=str).fillna("")
        al["행"] = range(2, len(al) + 2)
        alerts = al.to_dict("records")
    except ValueError:
        alerts = []
    # 같은 상품의 옵션끼리 붙어 보이도록: 마켓 → 상품명 → 옵션 숫자(2kg<5kg<10kg) → 옵션명
    def _okey(r):
        m = re.search(r"(\d+(?:\.\d+)?)\s*(kg|g)", r["optionName"] or "", re.I)
        w = float(m[1]) * (0.001 if m and m[2].lower() == "g" else 1) if m else 9e9
        return (r["market"], r["productName"], w, r["optionName"])
    rows.sort(key=_okey)
    return {"rows": rows, "catalog": catalog, "vendors": vendor_names(), "alerts": alerts,
            "catalogDates": cat.groupby("발주처")["목록일"].max().to_dict() if len(cat) else {}}


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    try:
        if cmd == "init":
            print("생성" if init_book() else "이미 있음", BOOK.relative_to(ROOT))
        elif cmd == "check":
            check()
        elif cmd == "catalog":
            catalog_cmd()
        elif cmd == "work":
            work_cmd()
        elif cmd == "apply":
            apply_cmd()
        elif cmd == "import-[가림]" and len(sys.argv) > 2:
            import_[가림]_ref(sys.argv[2])
        else:
            sys.exit(__doc__)
    except PermissionError:
        sys.exit(f"[오류] {BOOK.name} 이(가) 엑셀에서 열려 있습니다. 저장 후 닫고 다시 실행하세요.")
