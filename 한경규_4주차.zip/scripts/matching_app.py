"""상품 매칭 화면 ([가림] 파트너스 '상품 매핑 관리'와 같은 방식, 이 PC 안에서만 동작)

실행: python scripts/matching_app.py   →  브라우저에서 http://127.0.0.1:8765
- 판매 상품(쿠팡·토스 옵션) 한 줄마다 1순위·2순위 공급 상품을 검색해 직접 선택, 배수·사용(ON/OFF) 지정
- [가림] 파트너스 매핑은 '참고'로만 표시 (자동 적용 안 함)
- [변경사항 저장] → config/상품매칭.xlsx (마켓상품·품목·공급처매칭) 에 기록
- 상품 정보만 다룸(주문자·수취인 정보 없음). 외부 전송 없음 (127.0.0.1 전용)
"""
import json
import sys
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import contextlib  # noqa: E402
import io  # noqa: E402
import subprocess  # noqa: E402
import threading  # noqa: E402

import market_sync  # noqa: E402
import matching  # noqa: E402
import toss_api  # noqa: E402

LOCK = threading.Lock()          # 매칭표 동시 쓰기 방지
SCRIPTS = Path(__file__).resolve().parent
ROOT = SCRIPTS.parent


def capture(fn, *a):
    """함수의 print 출력을 문자열로 (SystemExit 메시지 포함)."""
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        try:
            fn(*a)
        except SystemExit as e:
            if e.code not in (None, 0):
                print(e.code)
    return buf.getvalue().strip()


def aside_download(js, dest, prelude):
    """어사이드로 사이트에서 파일 받기 (run_repl_files.ps1). 출력 중 저장/오류 줄만 반환."""
    p = subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(SCRIPTS / "aside" / "run_repl_files.ps1"),
                        "-Js", str(SCRIPTS / "aside" / js), "-Dest", str(ROOT / dest), "-Prelude", prelude],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600, cwd=str(ROOT))
    lines = [l for l in (p.stdout + "\n" + p.stderr).splitlines()
             if l.startswith("저장:") or l.startswith("PENDING=") or l.startswith("요청함") or "Error" in l or "실패" in l or "필요" in l]
    ok = p.returncode == 0 and any(l.startswith("저장:") for l in lines)
    return ok, "\n".join(dict.fromkeys(lines))


def run_task(task):
    """매칭 화면 버튼: 판매상품 가져오기 / 공급상품 점검."""
    log = []
    if task == "import-toss" and toss_api.configured():   # API 키가 있으면 API로 (몇 초)
        with LOCK:
            return capture(market_sync.import_market, "toss")
    if task in ("import-toss", "import-coupang"):
        mk = task.split("-")[1]
        ok, out = aside_download("get_market_products.js", f"market_products\\{mk}", f"globalThis.MP_MARKET='{mk}';")
        log.append(out)
        if not ok and "PENDING=" in out:   # 쿠팡: 엑셀 생성 대기 (요청됨)
            return out.replace("PENDING=", "⏳ ") + "\n몇 분 뒤 [쿠팡 상품 가져오기]를 다시 누르세요."
        if not ok:
            raise SystemExit(f"{'토스' if mk == 'toss' else '쿠팡'} 상품 목록을 받지 못했습니다 (로그인 확인)\n{out}")
        with LOCK:
            log.append(capture(market_sync.import_market, mk))
    elif task == "check-supply":
        for v in matching.vendor_names():
            ok, out = aside_download("get_catalogs.js", f"catalogs\\{v}", f"globalThis.GC_VENDOR='{v}';")
            log.append(f"[{v}] " + ("목록 받음" if ok else "목록 받기 실패 → 이전 목록 사용\n" + out))
        with LOCK:
            log.append(capture(matching.catalog_cmd))
            log.append(capture(market_sync.monitor))
    else:
        raise SystemExit("알 수 없는 작업")
    return "\n".join(l for l in log if l)

PORT = int(__import__("os").environ.get("MATCH_PORT", "8765"))

HTML = r"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>상품 매칭 관리</title>
<style>
:root{--bg:#f6f7f9;--card:#fff;--line:#e3e6ea;--text:#1f2328;--muted:#6b7280;--brand:#2f5597;--ok:#1a7f37;--warn:#b45309;--bad:#c0392b;--chg:#fff7e0}
*{box-sizing:border-box}body{margin:0;font:14px/1.45 -apple-system,"Malgun Gothic","Apple SD Gothic Neo",sans-serif;background:var(--bg);color:var(--text)}
header{background:var(--card);border-bottom:1px solid var(--line);padding:14px 20px;position:sticky;top:0;z-index:5}
h1{font-size:19px;margin:0 0 4px}.sub{color:var(--muted);font-size:12.5px}
.stats{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}.stat{background:var(--bg);border:1px solid var(--line);border-radius:8px;padding:4px 10px;font-size:12.5px}
.stat b{font-size:14px}.toolbar{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap;align-items:center}
input[type=search],select{border:1px solid var(--line);border-radius:6px;padding:7px 9px;font:inherit;background:#fff}
input[type=search]{min-width:280px}
button{font:inherit;border:1px solid var(--line);background:#fff;border-radius:6px;padding:6px 10px;cursor:pointer}
button.primary{background:var(--brand);color:#fff;border-color:var(--brand)}button.primary:disabled{opacity:.45;cursor:default}
main{padding:12px 20px 60px}table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:8px}
th{position:sticky;top:0;background:#eef1f5;font-size:12.5px;text-align:left;padding:8px;border-bottom:1px solid var(--line);white-space:nowrap}
td{padding:8px;border-bottom:1px solid var(--line);vertical-align:top}tr.changed td{background:var(--chg)}
td.prod{min-width:230px}.pname{font-weight:600}.disp{color:var(--muted);font-size:12px}.mono{font-family:Consolas,monospace;font-size:12.5px}
.mk{display:inline-block;font-size:11px;border-radius:4px;padding:1px 6px;background:#e8eefc;color:var(--brand)}.mk.toss{background:#e6f4ff;color:#0064ff}
.pick{display:flex;flex-direction:column;gap:4px;min-width:270px}
.sel{border:1px dashed #b8c0cc;border-radius:6px;padding:6px 8px;cursor:pointer;background:#fbfcfd;text-align:left}
.sel.set{border-style:solid;border-color:#9fb4dd;background:#f3f7ff}.sel.off{opacity:.55;text-decoration:line-through}
.vb{display:inline-block;font-size:11px;font-weight:600;border-radius:4px;padding:1px 6px;margin-right:4px;background:#eef1f5}
.price{color:var(--muted);font-size:12px}.so{color:var(--bad);font-weight:600;font-size:12px}
.row2{display:flex;gap:6px;align-items:center;font-size:12px;color:var(--muted)}.row2 input{width:48px;padding:3px 5px;border:1px solid var(--line);border-radius:4px}
.tg{padding:2px 8px;font-size:11.5px;border-radius:10px}.tg.on{background:#e7f6ec;color:var(--ok);border-color:#b7e1c3}.tg.off{background:#fdecea;color:var(--bad);border-color:#f3c1bb}
.st{font-size:12px;font-weight:600;white-space:nowrap}.st.ok{color:var(--ok)}.st.no{color:var(--bad)}.st.alt{color:var(--warn)}
.ref{font-size:12px;color:var(--muted);max-width:260px}.ref a{color:var(--brand);cursor:pointer;text-decoration:underline dotted}
#pop{position:fixed;inset:0;background:rgba(15,23,42,.35);display:none;align-items:flex-start;justify-content:center;padding-top:6vh;z-index:20}
#pop .box{background:#fff;width:min(820px,94vw);max-height:84vh;border-radius:10px;display:flex;flex-direction:column;box-shadow:0 10px 30px rgba(0,0,0,.2)}
#pop .hd{padding:12px 14px;border-bottom:1px solid var(--line)}#pop .hd .t{font-weight:600;margin-bottom:8px}
#pop .tabs{display:flex;gap:6px;margin-top:8px;flex-wrap:wrap}#pop .tabs button.on{background:var(--brand);color:#fff;border-color:var(--brand)}
#pop .list{overflow:auto;padding:6px}#pop .it{padding:7px 9px;border-radius:6px;cursor:pointer;display:flex;justify-content:space-between;gap:10px}
#pop .it:hover,#pop .it.k{background:#eef3ff}#pop .ft{padding:10px 14px;border-top:1px solid var(--line);display:flex;gap:8px;justify-content:space-between;flex-wrap:wrap}
#toast{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);background:#111827;color:#fff;padding:10px 16px;border-radius:8px;display:none;z-index:30;max-width:90vw;white-space:pre-line}
.hint{font-size:12px;color:var(--muted);margin-top:6px}
button.tab{border-radius:16px}button.tab.on{background:var(--text);color:#fff;border-color:var(--text)}button.tab b{color:var(--bad)}button.tab.on b{color:#ffd1cc}
.up{color:var(--bad);font-weight:600}.down{color:#0a66c2;font-weight:600}.mg{font-size:12px}.mg.neg{color:var(--bad);font-weight:600}
.atype{font-weight:600;font-size:12.5px}.atype.bad{color:var(--bad)}.atype.up{color:var(--bad)}.atype.down{color:#0a66c2}
.done{color:var(--muted);font-size:12px}
</style></head><body>
<header>
  <h1>상품 매칭 관리</h1>
  <div class="sub">판매 상품(쿠팡·토스 옵션)마다 실제로 발주할 공급 상품을 직접 고릅니다. 1순위가 품절(OFF)이면 2순위로 발주됩니다. 저장하면 <span class="mono">config/상품매칭.xlsx</span>에 기록됩니다.</div>
  <div class="toolbar" style="margin-top:8px">
    <button id="tabMatch" class="tab on">상품 매칭</button><button id="tabAlert" class="tab">공급 변동 알림 <b id="acnt">0</b></button>
    <span style="flex:1"></span>
    <button class="run" data-task="import-toss">⬇ 토스 상품 가져오기</button>
    <button class="run" data-task="import-coupang">⬇ 쿠팡 상품 가져오기</button>
    <button class="run" data-task="check-supply" title="업체 상품목록을 새로 받아 매칭된 공급 상품의 품절·가격 변동을 확인합니다 (몇 분 걸림)">🔍 공급상품 점검</button>
  </div>
  <div class="stats" id="stats"></div>
  <div class="toolbar" id="matchbar">
    <input type="search" id="q" placeholder="상품명 / 옵션명 / 옵션ID / 공급상품 검색">
    <select id="flt"><option value="all">전체</option><option value="todo" selected>미매칭만</option><option value="done">매칭완료</option><option value="alt">1순위 OFF·품절</option></select>
    <select id="mkt"><option value="">모든 마켓</option><option>coupang</option><option>toss</option></select>
    <button class="primary" id="save" disabled>변경사항 저장 (0개)</button>
    <button id="reload">새로고침</button>
  </div>
  <div class="hint" id="catinfo"></div>
</header>
<main><table id="mtable"><thead><tr><th>#</th><th>마켓</th><th>판매 상품명</th><th>옵션ID</th><th>옵션명</th><th>판매가 · 재고</th><th>1순위 공급 상품</th><th>2순위 공급 상품 (대체)</th><th>상태</th><th>[가림] 파트너스 매핑 (참고)</th></tr></thead><tbody id="tb"></tbody></table>
<section id="aview" style="display:none">
  <div class="toolbar" style="margin:0 0 10px"><select id="aflt"><option value="대기">처리 대기</option><option value="">전체</option><option value="승인">승인됨(파일 미생성)</option><option value="파일생성">수정파일 생성됨</option><option value="반영">토스 반영됨</option><option value="반영실패">반영 실패</option></select>
    <button class="primary" id="tapply">승인된 판매가 토스에 반영 (API)</button>
    <button id="pfile">토스 수정파일 만들기 (API 없을 때)</button>
    <button id="cfile">쿠팡 판매가 수정파일 만들기</button>
    <span class="hint">승인 = 제안판매가로 마켓 가격을 바꾸고 현재 공급가를 새 기준으로 · 기준만 확정 = 판매가는 그대로 두고 기준가만 갱신 · 무시 = 이번 알림 닫기</span></div>
  <table><thead><tr><th>점검일</th><th>유형</th><th>판매 상품 · 옵션</th><th>공급 상품</th><th>기준 → 현재 공급가</th><th>현재 판매가</th><th>제안 판매가</th><th>현재 마진</th><th>처리</th></tr></thead><tbody id="atb"></tbody></table>
</section></main>
<div id="busy" style="position:fixed;inset:0;background:rgba(255,255,255,.75);display:none;align-items:center;justify-content:center;z-index:40;flex-direction:column;gap:10px">
  <div style="font-size:16px;font-weight:600" id="busyt">작업 중…</div><div class="hint">어사이드 브라우저로 사이트에서 목록을 받는 중입니다. 몇 분 걸릴 수 있어요.</div></div>
<div id="pop"><div class="box">
  <div class="hd"><div class="t" id="ptitle"></div><input type="search" id="pq" placeholder="공급 상품 검색 (예: 감자 2kg 특)" style="width:100%">
    <div class="tabs" id="ptabs"></div></div>
  <div class="list" id="plist"></div>
  <div class="ft"><div><button id="pclear">선택 해제</button> <button id="pmanual">목록에 없는 품명 직접 입력</button></div><button id="pclose">닫기 (Esc)</button></div>
</div></div>
<div id="toast"></div>
<script>
let D=null, changed=new Set(), cur=null, ptab="", kIdx=-1;
const $=s=>document.querySelector(s), esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const won=p=>p&&!isNaN(+p)?(+p).toLocaleString()+"원":"";
const soldOut=(v,n)=>{const c=D.cmap[v+"\u0001"+n];return c&&/품절|중지|종료/.test(c.s)};
const norm=s=>String(s).replace(/[가림]|[가림]|[가림]|[가림]|국내산|국산|1박스|박스|가정용/g,"").replace(/[()\[\]\/·,\-_\s]/g,"").toLowerCase();
const bigr=s=>{s=norm(s).replace(/\d+(\.\d+)?/g,"");const b=new Set();for(let i=0;i<s.length-1;i++)b.add(s.slice(i,i+2));return b};
const nums=s=>new Set((String(s).match(/\d+(?:\.\d+)?\s*(?:kg|g|미|과|입|개|팩|cm)?/gi)||[]).map(x=>x.replace(/\s/g,"").toLowerCase()));
function score(q,n){const a=bigr(q),b=bigr(n);let h=0;a.forEach(x=>{if(b.has(x))h++});let s=.65*h/Math.max(a.size,1);const qn=nums(q),nn=nums(n);if(qn.size){let m=0;qn.forEach(x=>{if(nn.has(x))m++});s+=.35*m/qn.size}return s}
function toast(t,ms=3500){const e=$("#toast");e.textContent=t;e.style.display="block";clearTimeout(e._t);e._t=setTimeout(()=>e.style.display="none",ms)}
async function load(tries=0){let r;try{r=await fetch("/api/data");if(!r.ok){const j=await r.json().catch(()=>({}));throw new Error(j.error||r.status)}}
  catch(e){if(tries<5){setTimeout(()=>load(tries+1),1500);return}toast("데이터를 불러오지 못했습니다: "+e.message,8000);return}
  D=await r.json();D.cmap={};D.catalog.forEach(c=>D.cmap[c.v+"\u0001"+c.n]=c);D.rows.forEach((r,i)=>{r._i=i;r.s1=r.suppliers.find(s=>s.rank==1)||null;r.s2=r.suppliers.find(s=>s.rank==2)||null});changed.clear();
  $("#catinfo").textContent="공급 상품 목록: "+Object.entries(D.catalogDates).map(([v,d])=>v+" "+D.catalog.filter(c=>c.v==v).length+"개("+d+")").join(" · ");render()}
const supBad=s=>!s.use||soldOut(s.vendor,s.vendorProduct)||/품절|중지|종료|목록에없음/.test(s.supplyStatus||"");
function stateOf(r){const s1=r.s1,s2=r.s2;if(!s1||!s1.vendorProduct)return["no","미매칭"];
  if(supBad(s1)){if(s2&&s2.vendorProduct&&!supBad(s2))return["alt","2순위로 발주"];return["no","1순위 사용불가(OFF·품절·목록에없음), 대체 없음"]}
  return["ok","매칭완료"]}
function pickHtml(r,rank){const s=rank==1?r.s1:r.s2;if(!s||!s.vendorProduct)return`<div class="pick"><button class="sel" data-i="${r._i}" data-r="${rank}">${rank==1?"+ 공급 상품 선택":"+ 대체 상품 선택 (선택사항)"}</button></div>`;
  const c=D.cmap[s.vendor+"\u0001"+s.vendorProduct],so=soldOut(s.vendor,s.vendorProduct)||/품절|중지|종료|목록에없음/.test(s.supplyStatus||"");
  const bp=+s.basePrice||0,cp=c?+c.p:(+s.curPrice||0),chg=bp&&cp&&bp!=cp?`<span class="${cp>bp?"up":"down"}"> ${cp>bp?"▲":"▼"}${Math.abs(cp-bp).toLocaleString()}</span>`:"";
  return`<div class="pick"><button class="sel set ${s.use?"":"off"}" data-i="${r._i}" data-r="${rank}"><span class="vb">${esc(s.vendor)}</span>${esc(s.vendorProduct)} <span class="price">${c?won(c.p):"(목록에 없음)"}</span>${chg}${so?' <span class="so">'+esc(/목록에없음/.test(s.supplyStatus||"")?"목록에없음":"품절")+'</span>':""}</button>
  <div class="row2">배수 <input type="number" min="1" value="${esc(s.mult||1)}" data-i="${r._i}" data-r="${rank}" class="mult"> <button class="tg ${s.use?"on":"off"}" data-i="${r._i}" data-r="${rank}">${s.use?"사용 ON":"사용 OFF"}</button></div></div>`}
function render(){const q=$("#q").value.trim().toLowerCase(),f=$("#flt").value,mk=$("#mkt").value;let n={all:0,ok:0,no:0,alt:0};
  const html=D.rows.map(r=>{const[st,lab]=stateOf(r);n.all++;n[st]++;
    const keep=changed.has(r._i);  // 저장 전 바꾼 줄은 필터와 관계없이 계속 표시
    if(mk&&r.market!=mk)return"";if(!keep&&f=="todo"&&st!="no")return"";if(!keep&&f=="done"&&st=="no")return"";if(f=="alt"&&!(r.s1&&r.s1.vendorProduct&&supBad(r.s1)))return"";
    const hay=[r.productName,r.displayName,r.optionName,r.optionId,r.s1?.vendorProduct,r.s2?.vendorProduct,r.[가림]Ref].join(" ").toLowerCase();if(q&&!hay.includes(q))return"";
    return`<tr class="${changed.has(r._i)?"changed":""}"><td class="mono">${r._i+1}</td><td><span class="mk ${r.market}">${esc(r.market)}</span></td>
    <td class="prod"><div class="pname">${esc(r.productName)}</div>${r.displayName&&r.displayName!=r.productName?`<div class="disp">${esc(r.displayName)}</div>`:""}${r.sku?`<div class="disp mono">${esc(r.sku)}</div>`:""}</td>
    <td class="mono">${esc(r.optionId)}</td><td>${esc(r.optionName)}</td><td>${priceHtml(r)}</td><td>${pickHtml(r,1)}</td><td>${pickHtml(r,2)}</td>
    <td><span class="st ${st}">${lab}</span></td>
    <td class="ref">${r.[가림]Ref?`<a data-ref="${r._i}" title="클릭하면 이 이름으로 공급 상품을 검색합니다 (자동 적용 안 됨)">${esc(r.[가림]Ref)}</a>${r.[가림]Active?` <span class="disp">· [가림] ${esc(r.[가림]Active)}</span>`:""}`:'<span class="disp">-</span>'}</td></tr>`}).join("");
  $("#tb").innerHTML=html||`<tr><td colspan="10" style="text-align:center;color:#6b7280;padding:30px">조건에 맞는 상품이 없습니다</td></tr>`;
  const pend=(D.alerts||[]).filter(a=>a["처리"]=="대기").length;$("#acnt").textContent=pend;renderAlerts();
  $("#stats").innerHTML=`<span class="stat">전체 <b>${n.all}</b></span><span class="stat">매칭완료 <b style="color:var(--ok)">${n.ok}</b></span><span class="stat">2순위로 발주 <b style="color:var(--warn)">${n.alt}</b></span><span class="stat">미매칭·대체없음 <b style="color:var(--bad)">${n.no}</b></span>`;
  $("#save").disabled=!changed.size;$("#save").textContent=`변경사항 저장 (${changed.size}개)`}
function openPick(i,rank,query){cur={i:+i,rank:+rank};const r=D.rows[cur.i],s=rank==1?r.s1:r.s2;ptab=(s&&s.vendor)||(rank==1?(D.vendors.find(v=>r.productName.startsWith(v))||""):"");
  $("#ptitle").innerHTML=`${rank}순위 공급 상품 선택 — <span class="pname">${esc(r.productName)}</span> / ${esc(r.optionName)} <span class="mono disp">${esc(r.optionId)}</span>`;
  $("#pq").value=query||"";$("#ptabs").innerHTML=["",...D.vendors].map(v=>`<button data-v="${esc(v)}" class="${v==ptab?"on":""}">${v||"전체 업체"}</button>`).join("");
  $("#pop").style.display="flex";$("#pq").focus();plist()}
function plist(){const r=D.rows[cur.i],q=$("#pq").value.trim(),base=q||(r.productName+" "+r.optionName);
  let items=D.catalog.filter(c=>!ptab||c.v==ptab);
  if(q){const ws=q.toLowerCase().split(/\s+/);items=items.filter(c=>ws.every(w=>c.n.toLowerCase().includes(w)))}
  items=items.map(c=>({c,s:score(base,c.n)})).sort((a,b)=>b.s-a.s).slice(0,80);kIdx=-1;
  $("#plist").innerHTML=(q?"":`<div class="hint" style="padding:4px 9px">판매 상품명과 비슷한 순서로 표시 (검색어를 입력하면 그 단어가 모두 들어간 상품만)</div>`)+
   (items.map((x,k)=>`<div class="it" data-k="${k}" data-v="${esc(x.c.v)}" data-n="${esc(x.c.n)}"><span><span class="vb">${esc(x.c.v)}</span>${esc(x.c.n)}</span><span class="price">${won(x.c.p)} ${/품절|중지|종료/.test(x.c.s)?'<span class="so">'+esc(x.c.s)+'</span>':""}</span></div>`).join("")||'<div class="hint" style="padding:12px">검색 결과 없음 — 업체 탭을 "전체 업체"로 바꾸거나 "직접 입력"을 사용하세요</div>')}
function setSup(vendor,name){const r=D.rows[cur.i],key=cur.rank==1?"s1":"s2",old=r[key];
  r[key]=name?{rank:cur.rank,vendor,vendorProduct:name,mult:(old&&old.mult)||"1",use:old?old.use:true,memo:old?old.memo:""}:null;changed.add(cur.i);closePick();render()}
function closePick(){$("#pop").style.display="none";cur=null}
document.addEventListener("click",e=>{const t=e.target.closest("button,a,.it");if(!t)return;
  if(t.classList.contains("sel"))openPick(t.dataset.i,t.dataset.r);
  else if(t.classList.contains("tg")){const r=D.rows[+t.dataset.i],s=t.dataset.r==1?r.s1:r.s2;s.use=!s.use;changed.add(r._i);render()}
  else if(t.dataset.ref!==undefined){const r=D.rows[+t.dataset.ref];openPick(r._i,1,"");ptab="";$("#ptabs").querySelectorAll("button").forEach(b=>b.classList.toggle("on",b.dataset.v==""));
     $("#pq").value=r.[가림]Ref.split(" | ")[0].replace(/^\([^)]*\)/,"").replace(/[\/()]/g," ").trim().split(/\s+/).slice(0,2).join(" ");plist()}
  else if(t.classList.contains("it"))setSup(t.dataset.v,t.dataset.n);
  else if(t.dataset.v!==undefined&&t.closest("#ptabs")){ptab=t.dataset.v;$("#ptabs").querySelectorAll("button").forEach(b=>b.classList.toggle("on",b==t));plist()}
  else if(t.id=="pclear")setSup("","");else if(t.id=="pclose")closePick();
  else if(t.id=="pmanual"){const v=ptab||prompt("발주처 (업체명): "+D.vendors.join(", "));if(!v||!D.vendors.includes(v)){toast("발주처는 "+D.vendors.join(", ")+" 중 하나");return}
     const n=prompt(v+" 발주 양식에 넣을 품명을 입력하세요 (업체 표기 그대로)",$("#pq").value);if(n)setSup(v,n.trim())}
  else if(t.id=="reload"){if(!changed.size||confirm("저장 안 한 변경사항이 사라집니다. 새로고침할까요?"))load()}
  else if(t.id=="save")save()});
document.addEventListener("change",e=>{if(e.target.classList.contains("mult")){const r=D.rows[+e.target.dataset.i],s=e.target.dataset.r==1?r.s1:r.s2;s.mult=String(Math.max(1,parseInt(e.target.value)||1));changed.add(r._i);render()}});
$("#pop").addEventListener("click",e=>{if(e.target.id=="pop")closePick()});
$("#pq").addEventListener("input",plist);
document.addEventListener("keydown",e=>{if(!cur)return;const its=[...document.querySelectorAll("#plist .it")];
  if(e.key=="Escape")closePick();else if(e.key=="ArrowDown"||e.key=="ArrowUp"){e.preventDefault();kIdx=Math.max(0,Math.min(its.length-1,kIdx+(e.key=="ArrowDown"?1:-1)));its.forEach((x,k)=>x.classList.toggle("k",k==kIdx));its[kIdx]?.scrollIntoView({block:"nearest"})}
  else if(e.key=="Enter"&&its[kIdx>=0?kIdx:0]){const x=its[kIdx>=0?kIdx:0];setSup(x.dataset.v,x.dataset.n)}});
["q","flt","mkt"].forEach(id=>$("#"+id).addEventListener("input",render));
window.addEventListener("beforeunload",e=>{if(changed.size){e.preventDefault();e.returnValue=""}});
async function save(){const entries=[...changed].map(i=>{const r=D.rows[i];return{market:r.market,optionId:r.optionId,productName:r.productName,optionName:r.optionName,suppliers:[r.s1,r.s2].filter(s=>s&&s.vendorProduct)}});
  $("#save").disabled=true;const res=await fetch("/api/save",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(entries)});const j=await res.json();
  if(!res.ok){toast("저장 실패: "+j.error,6000);$("#save").disabled=false;return}toast("저장했습니다 ("+j.messages.length+"건)\n"+j.messages.slice(0,5).join("\n"),5000);await load()}
// 판매가·재고·마진 (마진 = 판매가 - 발주할 공급상품 현재가 × 배수)
function activeSup(r){for(const s of [r.s1,r.s2]){if(s&&s.vendorProduct&&!supBad(s))return s}return null}
function priceHtml(r){if(!r.price)return'<span class="disp">-</span>';const s=activeSup(r);let mg="";
  if(s){const c=D.cmap[s.vendor+"\u0001"+s.vendorProduct],cp=c?+c.p:+s.curPrice;if(cp){const m=+r.price-cp*(+s.mult||1);mg=`<div class="mg ${m<0?"neg":""}">마진 ${m.toLocaleString()}원</div>`}}
  const st=r.saleStatus&&r.saleStatus!="판매중"?`<div class="so">${esc(r.saleStatus)}</div>`:"";
  return`<div>${won(r.price)}</div><div class="disp">재고 ${esc(r.stock||"-")}</div>${mg}${st}`}
// 공급 변동 알림
function renderAlerts(){const f=$("#aflt").value,list=(D.alerts||[]).filter(a=>!f||a["처리"]==f);
  $("#atb").innerHTML=list.map(a=>{const t=a["유형"],cls=/인상/.test(t)?"up":/인하/.test(t)?"down":"bad",bp=+a["기준공급가"],cp=+a["현재공급가"];
    return`<tr><td class="mono">${esc(a["점검일"])}</td><td><span class="atype ${cls}">${esc(t)}</span></td>
    <td><span class="mk ${esc(a["마켓"])}">${esc(a["마켓"]||"-")}</span> <span class="pname">${esc(a["판매상품명"])}</span><div class="disp">${esc(a["옵션명"])} <span class="mono">${esc(a["마켓옵션ID"])}</span></div></td>
    <td><span class="vb">${esc(a["발주처"])}</span>${esc(a["발주처품명"])} <span class="disp">${esc(a["우선순위"])}순위</span></td>
    <td>${bp?won(bp):"-"} → ${cp?won(cp):"-"} ${a["공급가변동(배수반영)"]?`<span class="${+a["공급가변동(배수반영)"]>0?"up":"down"}">(${(+a["공급가변동(배수반영)"]>0?"+":"")+(+a["공급가변동(배수반영)"]).toLocaleString()})</span>`:""}</td>
    <td>${won(a["현재판매가"])||"-"}</td><td><b>${won(a["제안판매가"])||"-"}</b></td><td>${a["현재마진"]?(+a["현재마진"]).toLocaleString()+"원":"-"}</td>
    <td>${a["처리"]=="대기"?`${a["제안판매가"]?`<button data-dec="승인" data-row="${a["행"]}">제안가 승인</button> `:""}${cp?`<button data-dec="기준확정" data-row="${a["행"]}">기준만 확정</button> `:""}<button data-dec="무시" data-row="${a["행"]}">무시</button>`:`<span class="done">${esc(a["처리"])} ${esc(a["처리일"])}</span>`}</td></tr>`}).join("")
   ||`<tr><td colspan="9" style="text-align:center;color:#6b7280;padding:30px">알림이 없습니다. [🔍 공급상품 점검]으로 확인하세요.</td></tr>`}
function showTab(a){$("#tabMatch").classList.toggle("on",!a);$("#tabAlert").classList.toggle("on",a);$("#mtable").style.display=a?"none":"";$("#matchbar").style.display=a?"none":"";$("#aview").style.display=a?"":"none"}
$("#tabMatch").onclick=()=>showTab(false);$("#tabAlert").onclick=()=>showTab(true);$("#aflt").addEventListener("input",renderAlerts);
async function post(url,body){const r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const j=await r.json().catch(()=>({error:"응답 오류"}));if(!r.ok)throw new Error(j.error||r.status);return j}
document.addEventListener("click",async e=>{const b=e.target.closest("button.run,button[data-dec],#pfile,#cfile,#tapply");if(!b)return;
  if(b.id=="tapply"){try{const pv=await post("/api/toss-prices",{apply:false});
      if(!/\[예정\]/.test(pv.log)){toast(pv.log||"반영할 승인 건 없음",8000);return}
      if(!confirm("아래 판매가를 토스에 실제로 반영합니다. 진행할까요?\n\n"+pv.log))return;
      const j=await post("/api/toss-prices",{apply:true});toast(j.log,10000);await load();showTab(true)}catch(err){toast("실패: "+err.message,9000)}return}
  try{
    if(b.classList.contains("run")){if(changed.size&&!confirm("저장 안 한 매칭 변경이 있습니다. 먼저 저장하지 않으면 사라집니다. 계속할까요?"))return;
      $("#busyt").textContent=b.textContent.trim()+" 중…";$("#busy").style.display="flex";const j=await post("/api/run",{task:b.dataset.task});$("#busy").style.display="none";toast(j.log||"완료",9000);await load();if(b.dataset.task=="check-supply")showTab(true)}
    else if(b.dataset.dec){const j=await post("/api/decide",{row:+b.dataset.row,action:b.dataset.dec});toast(j.message);await load();showTab(true)}
    else if(b.id=="pfile"||b.id=="cfile"){const j=await post("/api/price-file",{market:b.id=="cfile"?"coupang":"toss"});toast(j.log,9000);await load();showTab(true)}
  }catch(err){$("#busy").style.display="none";toast("실패: "+err.message,9000)}});
load();
</script></body></html>"""


class H(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        b = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            return self._send(200, HTML, "text/html; charset=utf-8")
        if self.path == "/api/data":
            try:
                return self._send(200, json.dumps(matching.app_data(), ensure_ascii=False))
            except PermissionError:
                return self._send(409, json.dumps({"error": "상품매칭.xlsx 가 엑셀에서 열려 있습니다. 닫고 새로고침하세요."}, ensure_ascii=False))
        self._send(404, "{}")

    def do_POST(self):
        if self.path not in ("/api/save", "/api/run", "/api/decide", "/api/price-file", "/api/toss-prices"):
            return self._send(404, "{}")
        # 같은 PC의 이 화면에서 온 요청만 허용
        if self.headers.get("Origin") not in (None, f"http://127.0.0.1:{PORT}", f"http://localhost:{PORT}"):
            return self._send(403, json.dumps({"error": "허용되지 않은 요청"}, ensure_ascii=False))
        try:
            n = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(n).decode("utf-8") or "null")
            if self.path == "/api/run":
                return self._send(200, json.dumps({"log": run_task(body["task"])}, ensure_ascii=False))
            if self.path == "/api/decide":
                with LOCK:
                    msg = market_sync.decide(int(body["row"]), body["action"])
                return self._send(200, json.dumps({"message": msg}, ensure_ascii=False))
            if self.path == "/api/toss-prices":   # apply=false: 반영 예정 목록만, apply=true: 실제 반영
                if not toss_api.configured():
                    raise SystemExit("토스 API 키가 없습니다 (config/secrets.env)")
                with LOCK:
                    log = capture(toss_api.apply_prices, bool(body.get("apply")))
                return self._send(200, json.dumps({"log": log}, ensure_ascii=False))
            if self.path == "/api/price-file":
                fn = market_sync.price_file_coupang if body.get("market") == "coupang" else market_sync.price_file_toss
                with LOCK:
                    log = capture(fn)
                return self._send(200, json.dumps({"log": log}, ensure_ascii=False))
            with LOCK:
                msgs = matching.save_mapping(body)
            print("\n".join(msgs))
            return self._send(200, json.dumps({"messages": msgs}, ensure_ascii=False))
        except SystemExit as e:
            return self._send(400, json.dumps({"error": str(e)}, ensure_ascii=False))
        except PermissionError:
            return self._send(409, json.dumps({"error": "상품매칭.xlsx 가 엑셀에서 열려 있습니다. 닫고 다시 저장하세요."}, ensure_ascii=False))
        except Exception as e:  # noqa: BLE001
            return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False))

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    a = sys.argv
    if "--book" in a:   # 시험용: 다른 매칭표 파일
        matching.BOOK = Path(a[a.index("--book") + 1])
    if "--port" in a:
        PORT = int(a[a.index("--port") + 1])
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    url = f"http://127.0.0.1:{PORT}"
    print(f"상품 매칭 화면: {url}  (종료: Ctrl+C)")
    if "--no-browser" not in sys.argv:
        webbrowser.open(url)
    srv.serve_forever()
