"""마켓 판매상품 가져오기 · 공급상품 점검(품절/가격변동) · 판매가 제안/반영 파일

  python scripts/market_sync.py import toss [파일]     토스 '상품 전체 정보' 엑셀 → 매칭표 '마켓상품' (새 옵션 추가, 가격·재고 갱신)
  python scripts/market_sync.py import coupang [파일]  쿠팡 상품 엑셀 → 매칭표 '마켓상품'  (형식 확정 후)
  python scripts/market_sync.py monitor                '발주처상품'(업체 목록) 기준으로 매칭된 공급상품 점검 → '공급변동알림' 시트
  python scripts/market_sync.py decide 행번호 승인|무시|기준확정   알림 처리 (매칭 화면에서도 가능)
  python scripts/market_sync.py price-file toss        '승인'된 판매가 변경만 담은 토스 일괄수정 파일 생성 → price_updates/

- 파일을 생략하면 market_products/{마켓}/ 의 가장 최근 파일 사용
- 상품 정보만 다룸 (주문자·수취인 정보 없음)
"""
import math
import sys

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
from datetime import date
from pathlib import Path

import pandas as pd
import yaml
from openpyxl import load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parent))
import matching as M  # noqa: E402

ROOT = M.ROOT
MP_DIR = ROOT / "market_products"
PU_DIR = ROOT / "price_updates"


def _latest(market):
    fs = sorted((MP_DIR / market).glob("*.xls*"), key=lambda p: p.stat().st_mtime) if (MP_DIR / market).exists() else []
    if not fs:
        sys.exit(f"[오류] market_products/{market}/ 에 상품 파일 없음 → 먼저 다운로드")
    return fs[-1]


def _num(s):
    try:
        return float(str(s).replace(",", ""))
    except ValueError:
        return None


# ───────────────────────── 1. 판매상품 가져오기 ─────────────────────────
def read_toss(path):
    """토스 '상품 전체 정보' → [{optionId, productId, productName(관리코드 우선), displayName, optionName, price, listPrice, stock}]"""
    opt = pd.read_excel(path, sheet_name="상품 옵션 정보 수정", header=1, dtype=str).fillna("")
    opt = opt[opt["옵션 ID"].str.fullmatch(r"\d+")]
    base = pd.read_excel(path, sheet_name="상품 기본 정보 수정", header=1, dtype=str).fillna("")
    base = base[base["상품 ID"].str.fullmatch(r"\d+")]
    code = dict(zip(base["상품 ID"], base["상품관리코드"].str.strip()))
    oname_cols = [c for c in opt.columns if str(c).startswith("옵션명")]
    rows = []
    for _, r in opt.iterrows():
        oname = " / ".join(v for v in (r[c].strip() for c in oname_cols) if v)
        rows.append({"optionId": r["옵션 ID"], "productId": r["상품 ID"],
                     "productName": code.get(r["상품 ID"]) or r["상품명"], "displayName": r["상품명"],
                     "optionName": oname, "price": r["판매가"], "listPrice": r["정상가"], "stock": r["재고수량"]})
    return rows


def read_coupang(path):
    """쿠팡 Wing '엑셀 대량 수정 > 가격/재고/판매상태' 파일 (시트 data, 3행 헤더, 4행부터 데이터, 앞 15열 = 현재값)
    옵션 ID = 주문서 옵션ID(vendorItemId). 뒤 4열(P~S)은 '변경/수정 요청' 칸"""
    from openpyxl import load_workbook as _lw
    ws = _lw(path).worksheets[0]   # read_only 모드는 이 파일의 크기 정보가 틀려 3행에서 멈춤 → 일반 모드
    hdr = [str(c.value or "").strip() for c in ws[3]][:15]
    col = {h: i for i, h in enumerate(hdr)}
    need = ["업체상품 ID", "옵션 ID", "쿠팡 노출 상품명", "업체 등록 상품명", "등록 옵션명", "판매가격", "할인율기준가", "판매상태", "잔여수량(재고)"]
    miss = [n for n in need if n not in col]
    if miss:
        raise SystemExit(f"[오류] 쿠팡 파일 헤더가 예상과 다름: {miss}")
    rows = []
    for r in ws.iter_rows(min_row=4, values_only=True):
        v = lambda n: "" if r[col[n]] is None else str(r[col[n]]).strip()
        if not v("옵션 ID"):
            continue
        rows.append({"optionId": v("옵션 ID"), "productId": v("업체상품 ID"), "productName": v("업체 등록 상품명"),
                     "displayName": v("쿠팡 노출 상품명"), "optionName": v("등록 옵션명"), "price": v("판매가격"),
                     "listPrice": v("할인율기준가"), "stock": v("잔여수량(재고)"), "saleStatus": v("판매상태")})
    return rows


def import_market(market, path=None):
    """토스는 API 키가 있으면 API로, 없으면 엑셀 파일로."""
    if market == "toss" and path is None:
        import toss_api
        if toss_api.configured():
            return import_items("toss", toss_api.product_items(), "토스 API")
    path = Path(path) if path else _latest(market)
    items = read_toss(path) if market == "toss" else read_coupang(path)
    return import_items(market, items, path.name)


def import_items(market, items, source):
    """옵션 목록 [{optionId, productId, productName, displayName, optionName, price, listPrice, stock}] → '마켓상품'"""
    M.load()  # 머리글 보강
    wb = load_workbook(M.BOOK)
    ws = wb[M.S_MARKET]
    h = M._hdr(ws)
    today = date.today().isoformat()
    existing = {}
    for r in ws.iter_rows(min_row=2):
        if str(r[h["마켓"]].value) == market and r[h["마켓옵션ID"]].value:
            existing[str(r[h["마켓옵션ID"]].value)] = r
    seen, added, updated, price_chg, renamed = set(), 0, 0, [], 0
    for it in items:
        seen.add(it["optionId"])
        stock = it["stock"]
        status = "판매중" if (_num(stock) or 0) > 0 else "재고0"
        if it.get("saleStatus") and it["saleStatus"] != "판매중":   # 쿠팡: 판매중지 등 마켓 표기 우선
            status = it["saleStatus"]
        vals = {"노출상품명": it["displayName"], "판매가": it["price"], "정상가": it["listPrice"], "재고": stock,
                "판매상태": status, "상품ID": it["productId"], "가져온날": today}
        r = existing.get(it["optionId"])
        if r is None:
            row = [""] * len(h)
            base = {"마켓": market, "마켓옵션ID": it["optionId"], "마켓상품명": it["productName"], "마켓옵션명": it["optionName"],
                    "비고": "상품 가져오기", "등록일": today, **vals}
            for k, v in base.items():
                row[h[k]] = v
            ws.append(row); added += 1
        else:
            old = str(r[h["판매가"]].value or "")
            if old and old != str(it["price"]):
                price_chg.append(f"{it['productName']} / {it['optionName']}: {old} → {it['price']}")
            for k, v in vals.items():
                r[h[k]].value = v
            if not r[h["마켓옵션명"]].value:
                r[h["마켓옵션명"]].value = it["optionName"]
            # 상품명을 마켓의 등록상품명(쿠팡)/상품관리코드(토스)로 통일 — [가림] 목록 등에서 노출상품명으로 먼저 들어온 줄 정리
            # (토스 API에서 관리코드가 비어 노출명만 온 경우는 기존 이름 유지)
            if it["productName"] and it["productName"] != it["displayName"] and r[h["마켓상품명"]].value != it["productName"]:
                r[h["마켓상품명"]].value = it["productName"]
                renamed += 1
            updated += 1
    gone = 0
    for oid, r in existing.items():
        if oid not in seen and r[h["판매상태"]].value != "마켓에없음":
            r[h["판매상태"]].value = "마켓에없음"; r[h["가져온날"]].value = today; gone += 1
    wb.save(M.BOOK)
    print(f"[{market}] {source}: 옵션 {len(items)}개 → 새로 추가 {added} / 갱신 {updated} (상품명 통일 {renamed}) / 마켓에서 사라짐 {gone}")
    for c in price_chg:
        print("  마켓 판매가 변경 감지:", c)
    return {"added": added, "updated": updated, "gone": gone, "total": len(items)}


# ───────────────────────── 2. 공급상품 점검 + 판매가 제안 ─────────────────────────
def _rule():
    p = ROOT / "config" / "pricing.yaml"
    r = yaml.safe_load(p.read_text(encoding="utf-8")) if p.exists() else {}
    return {"mode": r.get("mode", "margin_amount"), "round_unit": int(r.get("round_unit", 100)),
            "only_increase": bool(r.get("only_increase", False)), "min_margin": float(r.get("min_margin", 0))}


def suggest_price(cur_price, base_cost, new_cost, mult, rule):
    if cur_price is None or base_cost in (None, 0) or new_cost is None:
        return None
    if rule["mode"] == "margin_rate":
        p = cur_price * (new_cost / base_cost)
    else:
        p = cur_price + (new_cost - base_cost) * mult
    u = rule["round_unit"] or 1
    return int(math.ceil(p / u) * u)


def monitor():
    """업체 목록('발주처상품' 시트) 기준으로 공급처매칭 각 줄의 현재공급가·공급상태 갱신, 변동을 '공급변동알림'에 기록."""
    market, item, supply = M.load()
    cat = M._cat_df()
    if cat.empty:
        sys.exit("[오류] '발주처상품' 시트 없음 → python scripts/matching.py catalog 먼저 실행")
    cmap = {(v, n): (p, s) for v, n, p, s in zip(cat["발주처"], cat["발주처품명"], cat["공급가"], cat["판매상태"])}
    listed = set(cat["발주처"])
    rule = _rule()
    today = date.today().isoformat()
    wb = load_workbook(M.BOOK)
    wsu = wb[M.S_SUPPLY]; hs = M._hdr(wsu)
    # 판매상품: 품목코드 → 마켓 옵션들
    opts = {}
    for _, m in market.iterrows():
        if m["품목코드"]:
            opts.setdefault(m["품목코드"], []).append(m)
    if M.S_ALERT not in wb.sheetnames:
        wa = wb.create_sheet(M.S_ALERT); wa.append(M.C_ALERT)
    wa = wb[M.S_ALERT]; ha = M._hdr(wa)
    # 이미 올린 알림(대기·무시·승인 등 처리 상태와 무관)과 같은 내용(옵션·품명·유형·현재공급가)은 다시 올리지 않음
    open_keys = {(str(r[ha["마켓옵션ID"]].value or ""), str(r[ha["발주처품명"]].value or ""), str(r[ha["유형"]].value or ""), str(r[ha["현재공급가"]].value or ""))
                 for r in wa.iter_rows(min_row=2)}
    n_chk = n_alert = 0
    for r in wsu.iter_rows(min_row=2):
        sku, v, name = str(r[hs["품목코드"]].value or ""), str(r[hs["발주처"]].value or ""), str(r[hs["발주처품명"]].value or "")
        if not (sku and v and name) or v not in listed:
            continue
        n_chk += 1
        hit = cmap.get((v, name))
        base = _num(r[hs["공급가"]].value)
        if hit is None:
            cur, status = None, "목록에없음"
        else:
            cur, status = _num(hit[0]), (hit[1] or "판매중")
        r[hs["현재공급가"]].value = int(cur) if cur is not None else ""
        r[hs["공급상태"]].value = status
        r[hs["점검일"]].value = today
        if base is None and cur is not None:   # 기준가가 없던 줄은 지금 값을 기준으로
            r[hs["공급가"]].value = int(cur); base = cur
        kinds = []
        if M.BAD_SUPPLY.search(status):
            kinds.append(status if status == "목록에없음" else "품절·판매중지")
        if cur is not None and base is not None and int(cur) != int(base):
            if not (rule["only_increase"] and cur < base):
                kinds.append("공급가인상" if cur > base else "공급가인하")
        mult = int(_num(r[hs["발주수량배수"]].value) or 1)
        rank = str(r[hs["우선순위"]].value or "")
        use = str(r[hs["사용"]].value or "Y").upper() != "N"
        for kind in kinds:
            for m in opts.get(sku, [{"마켓": "", "마켓옵션ID": "", "마켓상품명": "", "마켓옵션명": "", "판매가": ""}]):
                cp = _num(m["판매가"])
                sug = suggest_price(cp, base, cur, mult, rule) if kind.startswith("공급가") and rank == "1" and use else None
                margin = (cp - (cur or base or 0) * mult) if cp is not None else None
                key = (str(m["마켓옵션ID"]), name, kind, str(int(cur) if cur is not None else ""))
                if key in open_keys:
                    continue
                row = {"점검일": today, "유형": kind, "마켓": m["마켓"], "마켓옵션ID": m["마켓옵션ID"], "판매상품명": m["마켓상품명"],
                       "옵션명": m["마켓옵션명"], "품목코드": sku, "우선순위": rank, "발주처": v, "발주처품명": name,
                       "기준공급가": int(base) if base is not None else "", "현재공급가": int(cur) if cur is not None else "",
                       "공급가변동(배수반영)": int((cur - base) * mult) if (cur is not None and base is not None) else "",
                       "현재판매가": int(cp) if cp is not None else "", "제안판매가": sug if sug is not None else "",
                       "현재마진": int(margin) if margin is not None else "", "처리": "대기", "처리일": ""}
                wa.append([row[c] for c in M.C_ALERT]); open_keys.add(key); n_alert += 1
    wb.save(M.BOOK)
    print(f"공급상품 점검: {n_chk}줄 확인, 새 알림 {n_alert}건 → 매칭표 '{M.S_ALERT}' 시트 / 매칭 화면 '공급 변동 알림'")
    return {"checked": n_chk, "alerts": n_alert}


def decide(rownum, action):
    """알림 처리: 승인(제안판매가로 마켓 반영 예정) / 무시 / 기준확정(현재공급가를 새 기준공급가로)."""
    wb = load_workbook(M.BOOK)
    wa = wb[M.S_ALERT]; ha = M._hdr(wa)
    r = list(wa.iter_rows(min_row=rownum, max_row=rownum))[0]
    r[ha["처리"]].value = action
    r[ha["처리일"]].value = date.today().isoformat()
    if action in ("승인", "기준확정") and r[ha["현재공급가"]].value not in (None, ""):
        wsu = wb[M.S_SUPPLY]; hs = M._hdr(wsu)
        for s in wsu.iter_rows(min_row=2):
            if str(s[hs["품목코드"]].value) == str(r[ha["품목코드"]].value) and str(s[hs["발주처품명"]].value) == str(r[ha["발주처품명"]].value):
                s[hs["공급가"]].value = r[ha["현재공급가"]].value  # 새 기준
    wb.save(M.BOOK)
    return f"{rownum}행 → {action}"


def alerts():
    try:
        a = pd.read_excel(M.BOOK, sheet_name=M.S_ALERT, dtype=str).fillna("")
    except ValueError:
        return []
    a["행"] = range(2, len(a) + 2)
    return a.to_dict("records")


# ───────────────────────── 3. 승인된 판매가 → 토스 일괄수정 파일 ─────────────────────────
def price_file_toss():
    a = pd.DataFrame(alerts())
    if a.empty:
        sys.exit("알림 없음")
    ok = a[(a["처리"] == "승인") & (a["마켓"] == "toss") & (a["제안판매가"] != "")]
    if ok.empty:
        sys.exit("승인된 토스 판매가 변경 없음")
    newp = dict(zip(ok["마켓옵션ID"], ok["제안판매가"]))
    src = _latest("toss")
    wb = load_workbook(src)
    ws = wb["상품 옵션 정보 수정"]
    hdr = {str(c.value).strip(): i for i, c in enumerate(ws[2])}
    # 바뀐 옵션이 속한 상품은 다른 옵션도 원래 값 그대로 함께 둔다 (옵션 누락으로 오해될 위험 방지)
    keep_products = set()
    for i in range(5, ws.max_row + 1):     # 5행부터 데이터
        oid = str(ws.cell(i, hdr["옵션 ID"] + 1).value or "")
        if oid in newp:
            ws.cell(i, hdr["판매가"] + 1).value = int(float(newp[oid]))
            keep_products.add(str(ws.cell(i, hdr["상품 ID"] + 1).value))
    for i in range(ws.max_row, 4, -1):     # 뒤에서부터 지우기
        if str(ws.cell(i, hdr["상품 ID"] + 1).value or "") not in keep_products:
            ws.delete_rows(i)
    wsb = wb["상품 기본 정보 수정"]
    hb = {str(c.value).strip(): i for i, c in enumerate(wsb[2])}
    for i in range(wsb.max_row, 4, -1):
        if str(wsb.cell(i, hb["상품 ID"] + 1).value or "") not in keep_products:
            wsb.delete_rows(i)
    PU_DIR.mkdir(exist_ok=True)
    out = PU_DIR / f"toss_판매가수정_{date.today().isoformat()}.xlsx"
    wb.save(out)
    # 파일에 담은 승인 건은 '파일생성' 으로 (다음 파일에 중복 포함 방지). 업로드 확인 후 '반영' 으로 바꾼다
    wba = load_workbook(M.BOOK)
    wa = wba[M.S_ALERT]; ha = M._hdr(wa)
    for i in ok["행"]:
        r = list(wa.iter_rows(min_row=int(i), max_row=int(i)))[0]
        r[ha["처리"]].value = "파일생성"; r[ha["처리일"]].value = date.today().isoformat()
    wba.save(M.BOOK)
    print(f"토스 일괄수정 파일: {out.relative_to(ROOT)}  (옵션 {len(newp)}개 판매가 변경)")
    for oid, p in newp.items():
        print(f"  옵션 {oid} → {p}원")
    print("※ 토스쇼핑 파트너스 > 내 상품 > 상품 일괄 수정 에 업로드 (첫 회는 사용자와 함께 확인)")
    return out


def price_file_coupang():
    """승인된 쿠팡 판매가 변경 → Wing '엑셀 대량 수정 > Step 2' 업로드용 파일 (승인 옵션 행만, '판매가격(변경)' 칸만 채움)"""
    a = pd.DataFrame(alerts())
    if a.empty:
        sys.exit("알림 없음")
    ok = a[(a["처리"] == "승인") & (a["마켓"] == "coupang") & (a["제안판매가"] != "")]
    if ok.empty:
        sys.exit("승인된 쿠팡 판매가 변경 없음")
    newp = dict(zip(ok["마켓옵션ID"], ok["제안판매가"]))
    src = _latest("coupang")
    wb = load_workbook(src)
    ws = wb.worksheets[0]
    hdr = [str(c.value or "").strip() for c in ws[3]]
    i_opt, i_base = hdr.index("옵션 ID"), hdr.index("할인율기준가")
    i_newprice = hdr.index("판매가격", hdr.index("판매가격") + 1)   # 뒤쪽 '변경/수정 요청' 판매가격 칸
    done, held = [], []
    for i in range(ws.max_row, 3, -1):
        oid = str(ws.cell(i, i_opt + 1).value or "").strip()
        if oid in newp:
            p = int(float(newp[oid]))
            base = _num(ws.cell(i, i_base + 1).value)
            if base and p > base:
                held.append(f"옵션 {oid}: 제안 {p}원 > 할인율기준가 {int(base)}원 → 보류"); ws.delete_rows(i); continue
            ws.cell(i, i_newprice + 1).value = p
            done.append(f"옵션 {oid} → {p}원")
        else:
            ws.delete_rows(i)
    if not done:
        print("\n".join(held)); sys.exit("파일에 넣을 변경 없음")
    PU_DIR.mkdir(exist_ok=True)
    out = PU_DIR / f"coupang_판매가수정_{date.today().isoformat()}.xlsx"
    wb.save(out)
    wba = load_workbook(M.BOOK); wa = wba[M.S_ALERT]; ha = M._hdr(wa)
    for _, r0 in ok.iterrows():
        if any(r0["마켓옵션ID"] in d for d in done):
            r = list(wa.iter_rows(min_row=int(r0["행"]), max_row=int(r0["행"])))[0]
            r[ha["처리"]].value = "파일생성"; r[ha["처리일"]].value = date.today().isoformat()
    wba.save(M.BOOK)
    print(f"쿠팡 수정파일: {out.relative_to(ROOT)} (옵션 {len(done)}개)")
    print("\n".join("  " + d for d in done + held))
    print("※ Wing > 상품 조회/수정 > 엑셀 대량 수정 > Step 2 ) 수정한 엑셀 파일 업로드 (첫 회는 사용자와 함께 확인)")
    return out


if __name__ == "__main__":
    a = sys.argv[1:]
    try:
        if len(a) >= 2 and a[0] == "import":
            import_market(a[1], a[2] if len(a) > 2 else None)
        elif a[:1] == ["monitor"]:
            monitor()
        elif len(a) == 3 and a[0] == "decide":
            print(decide(int(a[1]), a[2]))
        elif a[:2] == ["price-file", "toss"]:
            price_file_toss()
        elif a[:2] == ["price-file", "coupang"]:
            price_file_coupang()
        else:
            sys.exit(__doc__)
    except PermissionError:
        sys.exit("[오류] 상품매칭.xlsx 가 엑셀에서 열려 있습니다. 닫고 다시 실행하세요.")
