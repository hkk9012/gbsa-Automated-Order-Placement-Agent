"""토스쇼핑 오픈 API 연동 (공식 문서: https://shopping-docs.toss.im/dev)

  python scripts/toss_api.py check                 키·토큰·연결 확인 (키 값은 출력하지 않음)
  python scripts/toss_api.py probe                 응답 '구조'만 출력 (필드 이름 확인용, 값은 출력 안 함)
  python scripts/toss_api.py products              판매상품(옵션별 판매가·정상가·재고) → 매칭표 '마켓상품' 반영
  python scripts/toss_api.py orders [YYYY-MM-DD]   결제완료·상품준비중 주문 → orders/날짜/원본/toss/toss_api_날짜.xlsx
  python scripts/toss_api.py prices                공급변동알림 중 '승인'된 토스 판매가 목록 (반영 전 확인)
  python scripts/toss_api.py prices --apply        위 목록을 토스에 실제 반영 (사용자 승인 후에만 실행)

- 키: config/secrets.env (TOSS_ACCESS_KEY / TOSS_SECRET_KEY). 토큰 캐시: config/.toss_token.json  — 둘 다 출력·전송 금지
- 모든 응답은 HTTP 200 + {resultType: SUCCESS|FAIL, success | error}
- 판매가는 정상가(originPrice) 이하만 가능 → 넘으면 반영하지 않고 보고
"""
import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SECRETS = ROOT / "config" / "secrets.env"
TOKEN_CACHE = ROOT / "config" / ".toss_token.json"
TOKEN_URL = "https://oauth2.cert.toss.im/token"
BASE = "https://shopping-fep.toss.im/api/v3/shopping-fep"


class TossError(Exception):
    pass


def _secrets():
    if not SECRETS.exists():
        raise TossError("config/secrets.env 없음")
    kv = {}
    for line in SECRETS.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            kv[k.strip()] = v.strip()
    a, s = kv.get("TOSS_ACCESS_KEY", ""), kv.get("TOSS_SECRET_KEY", "")
    if not (a and s):
        raise TossError("토스 API 키가 비어 있음 → config/secrets.env 에 TOSS_ACCESS_KEY / TOSS_SECRET_KEY 입력 필요")
    return a, s


def configured():
    try:
        _secrets()
        return True
    except TossError:
        return False


def _http(method, url, headers=None, data=None, timeout=30):
    req = urllib.request.Request(url, data=data, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


def token(force=False):
    if not force and TOKEN_CACHE.exists():
        c = json.loads(TOKEN_CACHE.read_text(encoding="utf-8"))
        if c.get("expires_at", 0) > time.time() + 86400:
            return c["access_token"]
    a, s = _secrets()
    last = ""
    # 문서의 표(clientId)와 예시(client_id) 표기가 달라 예시 표기를 먼저 시도
    for fields in (("client_id", "client_secret"), ("clientId", "clientSecret")):
        body = urllib.parse.urlencode({"grant_type": "client_credentials", fields[0]: a, fields[1]: s,
                                       "scope": "toss-shopping-fep:write"}).encode()
        code, txt = _http("POST", TOKEN_URL, {"Content-Type": "application/x-www-form-urlencoded",
                                              "Accept": "application/json; charset=UTF-8"}, body)
        if code == 200:
            j = json.loads(txt)
            if j.get("access_token"):
                TOKEN_CACHE.write_text(json.dumps({"access_token": j["access_token"],
                                                   "expires_at": time.time() + int(j.get("expires_in", 3600))}), encoding="utf-8")
                return j["access_token"]
        last = f"HTTP {code}: {txt[:200]}"
    raise TossError("토큰 발급 실패 (키 값·등록 IP 확인) " + last)


def call(method, path, params=None, body=None, _retry=True):
    url = BASE + path + ("?" + urllib.parse.urlencode(params, doseq=True) if params else "")
    h = {"Authorization": f"Bearer {token()}", "Accept": "application/json"}
    data = None
    if body is not None:
        h["Content-Type"] = "application/json"
        data = json.dumps(body).encode()
    code, txt = _http(method, url, h, data)
    if code == 401 and _retry:
        token(force=True)
        return call(method, path, params, body, _retry=False)
    if code != 200:
        raise TossError(f"{method} {path} → HTTP {code}: {txt[:300]}")
    j = json.loads(txt)
    if j.get("resultType") != "SUCCESS":
        e = j.get("error") or {}
        raise TossError(f"{method} {path} → {e.get('errorCode')}: {e.get('reason')}")
    return j.get("success")


def _shape(o, depth=0):
    """값 없이 구조(키·타입)만 — 개인정보 노출 없이 필드 이름 확인용"""
    if depth > 4:
        return "…"
    if isinstance(o, dict):
        return {k: _shape(v, depth + 1) for k, v in o.items()}
    if isinstance(o, list):
        return [_shape(o[0], depth + 1)] if o else []
    return type(o).__name__


# ───────────────────────── 상품 ─────────────────────────
def list_product_ids():
    ids, nxt = [], None
    for _ in range(100):
        p = {"size": 100}
        if nxt:
            p["nextToken"] = nxt
        s = call("GET", "/products/v2", p)
        prods = s.get("products") or s.get("results") or []
        ids += [x.get("id") or x.get("productId") for x in prods]
        nxt = s.get("nextToken") or s.get("nextCursor")
        if not nxt or not (s.get("hasNext", True)):
            break
    return [i for i in ids if i]


def product_items():
    """판매상품을 옵션 단위로: read_toss() 와 같은 형식"""
    rows = []
    for pid in list_product_ids():
        d = call("GET", f"/products/{pid}/v3")
        for it in d.get("items", []):
            opt = " / ".join(str(o.get("value", "")) for o in it.get("salesOptions") or [])
            rows.append({"optionId": str(it.get("productItemId")), "productId": str(d.get("id") or pid),
                         "productName": d.get("productManagementCode") or d.get("productName", ""),
                         "displayName": d.get("productName", ""), "optionName": opt,
                         "price": str(it.get("regularSalePrice", "")), "listPrice": str(it.get("originPrice", "")),
                         "stock": str(it.get("quantity", ""))})
        time.sleep(0.05)
    return rows


# ───────────────────────── 주문 ─────────────────────────
ORDER_HEADERS = ["주문번호", "주문상품번호", "주문상태", "발송기한", "상품명", "옵션명", "주문건수", "상품ID", "옵션 ID",
                 "구매자명", "구매자 연락처", "수령인명", "수령인 연락처", "우편번호", "배송지", "주문요청사항", "주문일시"]


def orders(day=None, statuses=("PAID", "PREPARING_PRODUCT")):
    """결제완료·상품준비중 주문(최근 31일) → 토스 엑셀과 같은 열 이름의 파일 (classify_orders.py 가 그대로 읽음)"""
    from openpyxl import Workbook
    day = day or date.today().isoformat()
    end = datetime.strptime(day, "%Y-%m-%d").date()
    start = end - timedelta(days=30)
    rows = []
    for st in statuses:
        nxt = None
        for _ in range(200):
            p = {"startDate": start.isoformat(), "endDate": end.isoformat(), "status": st, "limit": 50}
            if nxt:
                p["nextCursor"] = nxt
            s = call("GET", "/orders/v2", p)
            for o in s.get("results", []):
                rows.append([o.get("orderId"), o.get("orderProductId"), o.get("orderProductStatus"), o.get("shippingDeadlineAt"),
                             o.get("productName"), o.get("optionName"), o.get("quantity"), o.get("productId"),
                             o.get("productItemId") or o.get("stockId"),
                             o.get("ordererName"), o.get("ordererPhone"), o.get("receiverName"), o.get("receiverPhone"),
                             o.get("zipCode"), f"{o.get('address') or ''} {o.get('detailAddress') or ''}".strip(),
                             o.get("shippingNote"), o.get("orderedAt")])
            nxt = s.get("nextCursor")
            if not nxt:
                break
    by = {}
    for r in rows:
        by[r[2]] = by.get(r[2], 0) + 1
    print("토스 주문(API): " + (", ".join(f"{k} {v}건" for k, v in by.items()) or "0건"))
    if not rows:
        return None
    out_dir = ROOT / "orders" / day / "원본" / "toss"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"toss_api_{day}.xlsx"
    wb = Workbook(); ws = wb.active
    ws.append(["토스쇼핑 API로 수집 (2행이 헤더, markets.yaml toss header_row: 1)"])
    ws.append(ORDER_HEADERS)
    for r in rows:
        ws.append([str(v) if v is not None else "" for v in r])
    wb.save(out)
    print(f"저장: {out.relative_to(ROOT)} ({len(rows)}행)")
    return out


# ───────────────────────── 판매가 반영 (승인된 것만) ─────────────────────────
def approved_prices():
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import matching as M
    import market_sync as S
    import pandas as pd
    a = pd.DataFrame(S.alerts())
    if a.empty:
        return []
    ok = a[(a["처리"] == "승인") & (a["마켓"] == "toss") & (a["제안판매가"] != "")]
    mk = pd.read_excel(M.BOOK, sheet_name=M.S_MARKET, dtype=str).fillna("")
    mk = mk[mk["마켓"] == "toss"].set_index("마켓옵션ID")
    out = []
    for _, r in ok.iterrows():
        m = mk.loc[r["마켓옵션ID"]] if r["마켓옵션ID"] in mk.index else None
        out.append({"row": int(r["행"]), "optionId": r["마켓옵션ID"], "productId": (m["상품ID"] if m is not None else ""),
                    "name": f"{r['판매상품명']} / {r['옵션명']}", "cur": r["현재판매가"], "new": int(float(r["제안판매가"])),
                    "origin": (m["정상가"] if m is not None else "")})
    return out


def apply_prices(do_apply=False):
    from openpyxl import load_workbook
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import matching as M
    items = approved_prices()
    if not items:
        print("반영할 승인 건 없음")
        return []
    res = []
    for it in items:
        line = f"{it['name']} (옵션 {it['optionId']}): {it['cur']} → {it['new']}원"
        if not it["productId"]:
            res.append((it, False, "상품ID 없음 → 먼저 상품 가져오기")); print("[보류]", line, "- 상품ID 없음"); continue
        if it["origin"] and it["new"] > int(float(it["origin"])):
            res.append((it, False, f"정상가 {it['origin']}원 초과")); print("[보류]", line, f"- 정상가 {it['origin']}원보다 높음 (정상가 먼저 조정 필요)"); continue
        if not do_apply:
            print("[예정]", line); continue
        try:
            call("PUT", f"/product-items/{it['optionId']}/sale-price", body={"productId": int(it["productId"]), "salePrice": it["new"]})
            res.append((it, True, "")); print("[반영]", line)
        except TossError as e:
            res.append((it, False, str(e))); print("[실패]", line, "-", e)
        time.sleep(0.1)
    if do_apply:
        wb = load_workbook(M.BOOK)
        wa, wm = wb[M.S_ALERT], wb[M.S_MARKET]
        ha, hm = M._hdr(wa), M._hdr(wm)
        today = date.today().isoformat()
        for it, ok, why in res:
            r = list(wa.iter_rows(min_row=it["row"], max_row=it["row"]))[0]
            r[ha["처리"]].value = "반영" if ok else "반영실패"
            r[ha["처리일"]].value = today
            if ok:
                for m in wm.iter_rows(min_row=2):
                    if str(m[hm["마켓"]].value) == "toss" and str(m[hm["마켓옵션ID"]].value) == it["optionId"]:
                        m[hm["판매가"]].value = str(it["new"])
        wb.save(M.BOOK)
        print(f"반영 {sum(1 for _, ok, _ in res if ok)}건 / 실패·보류 {sum(1 for _, ok, _ in res if not ok)}건")
    return res


if __name__ == "__main__":
    a = sys.argv[1:]
    try:
        if a[:1] == ["check"]:
            token(force=True)
            s = call("GET", "/orders/delivery-companies")
            print("토스 API 연결 정상 (토큰 발급·호출 성공, 택배사 목록", len((s or {}).get("deliveryCompanies", [])), "개)")
        elif a[:1] == ["probe"]:
            s = call("GET", "/products/v2", {"size": 1})
            print("products/v2 구조:", json.dumps(_shape(s), ensure_ascii=False))
            pid = ((s.get("products") or s.get("results") or [{}])[0]).get("id")
            if pid:
                print("products/{id}/v3 구조:", json.dumps(_shape(call("GET", f"/products/{pid}/v3")), ensure_ascii=False))
            today = date.today()
            o = call("GET", "/orders/v2", {"startDate": (today - timedelta(days=30)).isoformat(), "endDate": today.isoformat(), "limit": 1})
            print("orders/v2 구조:", json.dumps(_shape(o), ensure_ascii=False))
        elif a[:1] == ["products"]:
            sys.path.insert(0, str(Path(__file__).resolve().parent))
            import market_sync as S
            S.import_items("toss", product_items(), "토스 API")
        elif a[:1] == ["orders"]:
            orders(a[1] if len(a) > 1 else None)
        elif a[:1] == ["prices"]:
            apply_prices(do_apply="--apply" in a)
        else:
            sys.exit(__doc__)
    except TossError as e:
        sys.exit(f"[토스 API] {e}")
