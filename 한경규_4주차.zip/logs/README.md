일자별 작업 로그 (YYYY-MM-DD.md)
